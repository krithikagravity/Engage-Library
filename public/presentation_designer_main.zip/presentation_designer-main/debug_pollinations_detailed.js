
const { exec } = require('child_process');

const base = "https://image.pollinations.ai/prompt/";
const altBase = "https://pollinations.ai/p/";

const scenarios = [
    { name: "One Word", url: `${base}isometric` },
    { name: "Two Words", url: `${base}isometric%20city` },
    { name: "Three Words", url: `${base}isometric%20city%20building` },
    { name: "With Model Flux", url: `${base}isometric?model=flux` },
    { name: "With Model Turbo", url: `${base}isometric?model=turbo` },
    { name: "With NoLogo", url: `${base}isometric?nologo=true` },
    { name: "Alt Endpoint One Word", url: `${altBase}isometric` },
    { name: "Alt Endpoint Complex", url: `${altBase}isometric%20city%20view` },
];

const checkUrl = (scenario) => {
    return new Promise(resolve => {
        // -I for headers, -L to follow redirects
        exec(`curl -I -L --user-agent "Mozilla/5.0" "${scenario.url}"`, (err, stdout, stderr) => {
            const status = stdout.match(/HTTP\/\d(?:\.\d)?\s+(\d{3})/);
            const contentType = stdout.match(/content-type:\s+(.*)/i);
            resolve({
                name: scenario.name,
                url: scenario.url,
                status: status ? status[1] : 'ERR',
                type: contentType ? contentType[1].trim() : 'unknown'
            });
        });
    });
};

async function run() {
    console.log("Debugging Pollinations API...");
    for (const s of scenarios) {
        const res = await checkUrl(s);
        console.log(`[${res.status}] ${res.name.padEnd(20)} Type: ${res.type}`);
        if (res.status !== '200') console.log(`      URL: ${res.url}`);
    }
}

run();
