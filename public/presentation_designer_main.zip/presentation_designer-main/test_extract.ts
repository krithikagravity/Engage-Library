import fs from "fs";
import JSZip from "jszip";

async function run() {
  const data = fs.readFileSync("test.pptx"); // Let's check what presentations we have
  const zip = await JSZip.loadAsync(data);
  const slide1 = await zip.file("ppt/slides/slide1.xml")?.async("string");
  if (!slide1) {
    console.log("no slide1"); return;
  }
  const { DOMParser } = globalThis as any; // Need DOMParser or jsdom in Node? 
  // Wait, the project runs in browser or worker?
  // Let's see package.json
}
run();
