
try {
    const pdfjsLib = require("pdfjs-dist/legacy/build/pdf.js");
    console.log("Legacy main keys:", Object.keys(pdfjsLib));
} catch (e) {
    console.log("Legacy main failed");
}

try {
    // Try to find where SVGGraphics is located by listing files in the package if possible, or just guessing common paths.
    // In many versions it is not exported by top level.
    // It's often in 'pdfjs-dist/lib/display/svg.js'
    const svgPath = "pdfjs-dist/lib/display/svg.js";
    try {
        const svgLib = require(svgPath);
        console.log("Found at " + svgPath, Object.keys(svgLib));
    } catch (e) {
        console.log("Not found at " + svgPath);
    }
} catch (e) {
    console.error(e);
}
