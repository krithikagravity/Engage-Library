
const { exec } = require('child_process');

const prompt = "isometric";
const targetUrl = `https://image.pollinations.ai/prompt/${prompt}?width=1280&height=720&nologo=true`;
const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`;

console.log("Testing Proxy URL:", proxyUrl);

exec(`curl -v "${proxyUrl}"`, (err, stdout, stderr) => {
    console.log("--- STDERR (Headers) ---");
    console.log(stderr);
    console.log("--- STDOUT (Body excerpt) ---");
    console.log(stdout.substring(0, 500));
});
