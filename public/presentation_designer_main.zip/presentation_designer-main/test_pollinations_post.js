
const https = require('https');

async function testPollinationsPost() {
    const prompt = "Create a JSON object for a presentation slide about 'Future of AI'. Returning ONLY raw JSON. Fields: title, thesis, summary.";
    // Using POST to avoid URL length limits
    const data = JSON.stringify({
        messages: [
            { role: 'system', content: 'You are a helpful assistant.' },
            { role: 'user', content: prompt }
        ],
        model: 'openai'
    });

    const options = {
        hostname: 'text.pollinations.ai',
        port: 443,
        path: '/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    };

    console.log("Testing POST to text.pollinations.ai...");

    const req = https.request(options, (res) => {
        console.log(`STATUS: ${res.statusCode}`);
        let body = '';
        res.on('data', (chunk) => { body += chunk; });
        res.on('end', () => {
            console.log('BODY:', body);
        });
    });

    req.on('error', (e) => {
        console.error(`problem with request: ${e.message}`);
    });

    req.write(data);
    req.end();
}

testPollinationsPost();
