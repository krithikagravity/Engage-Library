
const { exec } = require('child_process');

const prompt = "AI-driven national healthcare ecosystem";
const urlBase = "https://image.pollinations.ai/prompt/";

const configs = [
    { name: "Simple Test", url: `${urlBase}test` },
    { name: "Short Prompt", url: `${urlBase}${encodeURIComponent(prompt)}` },
    { name: "Short Prompt + Flux", url: `${urlBase}${encodeURIComponent(prompt)}?model=flux` },
    { name: "Complex Prompt + Flux", url: `${urlBase}${encodeURIComponent("Al-driven national healthcare ecosystem connecting hospitals, insurers, regulators, and citizens, isometric style")}?model=flux` },
    { name: "Complex Prompt + No Model", url: `${urlBase}${encodeURIComponent("Al-driven national healthcare ecosystem connecting hospitals, insurers, regulators, and citizens, isometric style")}` },
];

const runCurl = (config) => {
    return new Promise((resolve) => {
        // Use -I to get headers only, -L to follow redirects, --user-agent to mimic browser
        const cmd = `curl -I -L --user-agent "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" "${config.url}"`;
        exec(cmd, (error, stdout, stderr) => {
            const statusMatch = stdout.match(/HTTP\/[122\.]+\s+(\d{3})/);
            const status = statusMatch ? statusMatch[1] : "UNKNOWN";
            resolve({ name: config.name, status, url: config.url });
        });
    });
};

async function run() {
    console.log("Starting connectivity tests...");
    for (const config of configs) {
        const result = await runCurl(config);
        console.log(`[${result.status}] ${result.name}`);
        if (result.status !== '200') {
            console.log(`   FAIL URL: ${result.url}`);
        }
    }
}

run();
