
const https = require('https');

const prompt = "Al-driven national healthcare ecosystem connecting hospitals, insurers, regulators, and citizens";
const selectedStyle = "isometric";
const enhancedPrompt = `${prompt}, ${selectedStyle} style, high quality, 4k, detailed`;

// Test Cases
const urls = [
    { name: "Original (flux)", url: `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?width=1280&height=720&model=flux` },
    { name: "Short (flux)", url: `https://image.pollinations.ai/prompt/${encodeURIComponent("National healthcare ecosystem, isometric style")}?width=1280&height=720&model=flux` },
    { name: "Original (default model)", url: `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?width=1280&height=720` },
    { name: "Original (flux + nologo)", url: `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?width=1280&height=720&model=flux&nologo=true` }
];

const testUrl = (item) => {
    console.log(`Testing: ${item.name}`);
    console.log(`URL: ${item.url}`);

    https.get(item.url, (res) => {
        console.log(`[${item.name}] Status: ${res.statusCode}`);
        if (res.statusCode === 200) {
            console.log(`[${item.name}] SUCCESS`);
        } else {
            console.log(`[${item.name}] FAILED`);
        }
        res.resume(); // Consume/discard data
    }).on('error', (e) => {
        console.error(`[${item.name}] Error:`, e.message);
    });
};

urls.forEach(u => testUrl(u));
