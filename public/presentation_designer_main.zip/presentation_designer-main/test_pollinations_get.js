
const https = require('https');

async function testPollinations() {
    const prompt = "test slide";
    // Simulating the full system prompt used in the app
    const systemPrompt = "Create a JSON object for a 'Gravity' presentation slide. Fields: title, thesis, summary, pillars (array of strings). Return ONLY raw JSON.";
    const fullPrompt = `${systemPrompt} \n\n User Content: ${prompt}`;

    const url = `https://text.pollinations.ai/${encodeURIComponent(fullPrompt)}`;

    console.log("Testing URL length:", url.length);
    console.log("URL:", url);

    https.get(url, (res) => {
        let data = '';
        console.log("Status Code:", res.statusCode);

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log("Response Body:", data);
        });

    }).on("error", (err) => {
        console.log("Error: " + err.message);
    });
}

testPollinations();
