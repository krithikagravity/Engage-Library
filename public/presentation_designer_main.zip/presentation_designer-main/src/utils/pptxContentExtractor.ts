/**
 * pptxContentExtractor.ts
 *
 * Deep PPTX content extraction specialist.
 * Receives a JSZip instance of an unpacked PPTX and returns a structured
 * JSON array where each object represents one slide with rich semantic metadata.
 *
 * This module does NOT summarise — it extracts, classifies, and structures.
 */

import JSZip from "jszip";

// ─── Output Schema ───────────────────────────────────────────────────────────

export type SlideType =
  | "title"
  | "stat"
  | "problem"
  | "solution"
  | "process"
  | "comparison"
  | "team"
  | "quote"
  | "closing"
  | "generic";

export type ContentDensity = "light" | "medium" | "heavy";

export interface ExtractedStat {
  value: string;
  label: string;
  context: string | null;
}

export interface ExtractedPillar {
  heading: string;
  body: string;
  iconHint: string | null;
}

export interface ExtractedImage {
  refId: string;
  dataUrl: string | null;
  altText: string | null;
  prominenceRank: number;
}

export interface ExtractedSlide {
  slideIndex: number;
  slideType: SlideType;
  title: string | null;
  subtitle: string | null;
  bodyText: string | null;
  thesis: string | null;
  stats: ExtractedStat[];
  pillars: ExtractedPillar[];
  images: ExtractedImage[];
  layoutIntent: string;
  contentDensity: ContentDensity;
  brandSignals: string[];
}

// ─── Internal Parse Models ───────────────────────────────────────────────────

interface TextRun {
  text: string;
  fontSize: number | null;       // in points
  fontFamily: string | null;
  bold: boolean;
  italic: boolean;
  color: string | null;          // hex, e.g. "FF0000"
}

interface Paragraph {
  runs: TextRun[];
  level: number;                  // indentation level (0 = top)
  alignment: string | null;       // "ctr", "l", "r", "just"
}

interface ShapeNode {
  shapeType: string | null;       // e.g. "rect", "roundRect", "ellipse", "pic"
  name: string | null;            // sp name attribute
  paragraphs: Paragraph[];
  imageRefId: string | null;      // r:embed from a:blipFill
  imageAltText: string | null;    // descr attribute
  width: number;                  // EMUs
  height: number;                 // EMUs
  left: number;                   // EMUs
  top: number;                    // EMUs
  isPlaceholder: boolean;
  placeholderType: string | null; // "title", "subTitle", "body", "ctrTitle", "dt", "ftr", "sldNum"
}

interface SlideRawData {
  slideIndex: number;
  shapes: ShapeNode[];
  slideLayoutName: string | null;
  slideMasterName: string | null;
  noteText: string | null;
}

// ─── Constants ───────────────────────────────────────────────────────────────

const EMU_PER_INCH = 914400;
const EMU_PER_PT = 12700;

// Font-size thresholds (in points) for classification
const STAT_FONT_SIZE_THRESHOLD = 36;  // text >= 36pt treated as a stat candidate
const TITLE_FONT_SIZE_THRESHOLD = 24;
const BODY_FONT_SIZE_MAX = 18;

// Common brand/product keyword patterns
const BRAND_PATTERNS = [
  /gravityONE|gravity\s*one/i,
  /dubai\s*holding/i,
  /DHRE/i,
  /GravityONE/i,
  /commercial\s*in\s*confidence/i,
  /proprietary/i,
  /confidential/i,
];

// Stat-like patterns
const STAT_REGEX = /^[\s]*([+\-]?\s*\$?\s*[\d,.]+\s*[%xXkKmMbBtT]?\s*\+?\s*)$/;
const PERCENTAGE_REGEX = /\d+(\.\d+)?\s*%/;
const LARGE_NUMBER_REGEX = /[\d,]+(\.\d+)?\s*[kKmMbBtT]?\b/;
const CURRENCY_REGEX = /\$\s*[\d,.]+/;

// Quote signals
const QUOTE_SIGNALS = [/^[""\u201C]/, /[""\u201D]$/, /^—\s/, /\bsaid\b/i];

// Closing / CTA signals
const CLOSING_SIGNALS = [
  /thank\s*you/i, /questions\s*\?/i, /next\s*steps/i, /contact\s*us/i,
  /get\s*in\s*touch/i, /let['']s\s*connect/i, /summary/i, /recap/i
];

// Problem signals
const PROBLEM_SIGNALS = [
  /challenge/i, /problem/i, /pain\s*point/i, /obstacle/i, /issue/i,
  /gap/i, /risk/i, /threat/i, /barrier/i, /bottleneck/i
];

// Solution signals
const SOLUTION_SIGNALS = [
  /solution/i, /approach/i, /our\s*answer/i, /how\s*we/i, /introducing/i,
  /proposal/i, /recommendation/i, /strategy/i
];

// Team signals
const TEAM_SIGNALS = [
  /team/i, /leadership/i, /management/i, /our\s*people/i, /co-?founder/i,
  /ceo/i, /cto/i, /coo/i, /director/i, /advisor/i, /board/i
];

// Process signals
const PROCESS_SIGNALS = [
  /step\s*\d/i, /phase\s*\d/i, /stage\s*\d/i, /process/i, /workflow/i,
  /timeline/i, /roadmap/i, /milestone/i, /how\s*it\s*works/i
];

// ─── XML Helpers ─────────────────────────────────────────────────────────────

const aNS = "http://schemas.openxmlformats.org/drawingml/2006/main";
const pNS = "http://schemas.openxmlformats.org/presentationml/2006/main";
const rNS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const relNS = "http://schemas.openxmlformats.org/package/2006/relationships";

// ─── Shape Parsing ───────────────────────────────────────────────────────────

function parseShapeDOM(node: Element): ShapeNode {
  // name: <p:nvSpPr><p:cNvPr name="..." descr="...">
  const cNvPr = node.getElementsByTagName("p:cNvPr")[0] || node.getElementsByTagName("a:cNvPr")[0] || node.getElementsByTagNameNS(pNS, "cNvPr")[0] || node.getElementsByTagNameNS(aNS, "cNvPr")[0];
  const name = cNvPr ? cNvPr.getAttribute("name") : null;
  const imageAltText = cNvPr ? cNvPr.getAttribute("descr") : null;

  // shapeType
  const prstGeom = node.getElementsByTagName("a:prstGeom")[0] || node.getElementsByTagNameNS(aNS, "prstGeom")[0];
  let shapeType = prstGeom ? prstGeom.getAttribute("prst") : null;
  if (node.localName === "pic" || node.tagName.endsWith("pic")) shapeType = "pic";

  // position & size
  const off = node.getElementsByTagName("a:off")[0] || node.getElementsByTagNameNS(aNS, "off")[0];
  const ext = node.getElementsByTagName("a:ext")[0] || node.getElementsByTagNameNS(aNS, "ext")[0];
  const left = off ? parseInt(off.getAttribute("x") || "0", 10) : 0;
  const top = off ? parseInt(off.getAttribute("y") || "0", 10) : 0;
  const width = ext ? parseInt(ext.getAttribute("cx") || "0", 10) : 0;
  const height = ext ? parseInt(ext.getAttribute("cy") || "0", 10) : 0;

  // images
  const blip = node.getElementsByTagName("a:blip")[0] || 
               node.getElementsByTagNameNS(aNS, "blip")[0] || 
               node.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing", "blip")[0] || 
               node.getElementsByTagNameNS(aNS, "blipFill")[0];
  let imageRefId = null;
  if (blip) {
    imageRefId = blip.getAttributeNS(rNS, "embed") || blip.getAttribute("r:embed") || blip.getAttribute("relationships:embed");
  }

  // placeholder
  const ph = node.getElementsByTagName("p:ph")[0] || node.getElementsByTagNameNS(pNS, "ph")[0];
  const isPlaceholder = !!ph;
  let placeholderType = ph ? ph.getAttribute("type") : null;
  if (isPlaceholder && !placeholderType) placeholderType = "body";

  // Paragraphs
  const paragraphs: Paragraph[] = [];
  const pNodes = Array.from(node.getElementsByTagName("a:p"));
  if (pNodes.length === 0) pNodes.push(...Array.from(node.getElementsByTagNameNS(aNS, "p")));
  
  for (let i = 0; i < pNodes.length; i++) {
    const pNode = pNodes[i];
    const runs: TextRun[] = [];
    
    const pPr = pNode.getElementsByTagName("a:pPr")[0] || pNode.getElementsByTagNameNS(aNS, "pPr")[0];
    const level = pPr ? parseInt(pPr.getAttribute("lvl") || "0", 10) : 0;
    const alignment = pPr ? pPr.getAttribute("algn") : null;

    const rNodes = Array.from(pNode.getElementsByTagName("a:r"));
    if (rNodes.length === 0) rNodes.push(...Array.from(pNode.getElementsByTagNameNS(aNS, "r")));
    const fldNodes = Array.from(pNode.getElementsByTagName("a:fld"));
    if (fldNodes.length === 0) fldNodes.push(...Array.from(pNode.getElementsByTagNameNS(aNS, "fld")));
    const allRNodes = [...rNodes, ...fldNodes];

    for (const rNode of allRNodes) {
      const tNodes = Array.from(rNode.getElementsByTagName("a:t"));
      if (tNodes.length === 0) tNodes.push(...Array.from(rNode.getElementsByTagNameNS(aNS, "t")));
      let text = tNodes.map(n => n.textContent).join("");
      
      // Decode HTML entities and non-breaking spaces
      text = text.replace(/&amp;/g, "&").replace(/&apos;/g, "'").replace(/\xa0/g, " ");

      if (!text) continue;

      const rPrNode = rNode.getElementsByTagName("a:rPr")[0] || rNode.getElementsByTagNameNS(aNS, "rPr")[0] || 
                      rNode.getElementsByTagName("a:endParaRPr")[0] || rNode.getElementsByTagNameNS(aNS, "endParaRPr")[0];
      let fontSize = null, bold = false, italic = false, fontFamily = null, color = null;

      if (rPrNode) {
        const sz = rPrNode.getAttribute("sz");
        if (sz) fontSize = Math.round(parseInt(sz, 10) / 100);
        bold = rPrNode.getAttribute("b") === "1";
        italic = rPrNode.getAttribute("i") === "1";
        
        const latin = rPrNode.getElementsByTagName("a:latin")[0] || rPrNode.getElementsByTagNameNS(aNS, "latin")[0];
        if (latin) fontFamily = latin.getAttribute("typeface");

        const srgbClr = rPrNode.getElementsByTagName("a:srgbClr")[0] || rPrNode.getElementsByTagNameNS(aNS, "srgbClr")[0];
        if (srgbClr) color = srgbClr.getAttribute("val");
      }

      runs.push({ text, fontSize, fontFamily, bold, italic, color });
    }

    if (runs.length > 0) paragraphs.push({ runs, level, alignment });
  }

  return { shapeType, name, paragraphs, imageRefId, imageAltText, width, height, left, top, isPlaceholder, placeholderType };
}

// ─── Slide-Level Parsing ─────────────────────────────────────────────────────

async function parseSlideXml(
  zip: JSZip,
  slideFileName: string,
  slideIndex: number
): Promise<SlideRawData> {
  const content = await zip.file(slideFileName)?.async("string") ?? "";
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(content, "application/xml");

  const shapes: ShapeNode[] = [];

  const allSp = Array.from(xmlDoc.getElementsByTagName("p:sp"));
  if (allSp.length === 0) allSp.push(...Array.from(xmlDoc.getElementsByTagNameNS(pNS, "sp")));
  const allPic = Array.from(xmlDoc.getElementsByTagName("p:pic"));
  if (allPic.length === 0) allPic.push(...Array.from(xmlDoc.getElementsByTagNameNS(pNS, "pic")));
  const allGraphic = Array.from(xmlDoc.getElementsByTagName("p:graphicFrame"));
  if (allGraphic.length === 0) allGraphic.push(...Array.from(xmlDoc.getElementsByTagNameNS(pNS, "graphicFrame")));

  for (const node of [...Array.from(allSp), ...Array.from(allPic), ...Array.from(allGraphic)]) {
    shapes.push(parseShapeDOM(node));
  }

  // Slide layout reference (for debugging, not for classification)
  const slideLayoutName = null;

  // Notes
  const noteText = await (async () => {
    const slideNum = slideFileName.match(/slide(\d+)\.xml/)?.[1];
    if (!slideNum) return null;
    const notesPath = `ppt/notesSlides/notesSlide${slideNum}.xml`;
    const notesXml = await zip.file(notesPath)?.async("string");
    if (!notesXml) return null;
    
    const notesDoc = parser.parseFromString(notesXml, "application/xml");
    const tNodes = Array.from(notesDoc.getElementsByTagName("a:t"));
    if (tNodes.length === 0) tNodes.push(...Array.from(notesDoc.getElementsByTagNameNS(aNS, "t")));
    const text = tNodes.map(n => n.textContent).join(" ");
    return text.replace(/&amp;/g, "&").replace(/&apos;/g, "'").replace(/\xa0/g, " ").trim() || null;
    return text.trim() || null;
  })();

  return {
    slideIndex,
    shapes,
    slideLayoutName,
    slideMasterName: null,
    noteText,
  };
}

// ─── Image Relationship Resolution ──────────────────────────────────────────

async function resolveImageRels(
  zip: JSZip,
  slideFileName: string
): Promise<Map<string, string>> {
  // Map rId -> target path
  const relsMap = new Map<string, string>();
  const slideNum = slideFileName.match(/slide(\d+)\.xml/)?.[1];
  if (!slideNum) return relsMap;

  const relsPath = `ppt/slides/_rels/slide${slideNum}.xml.rels`;
  const relsXml = await zip.file(relsPath)?.async("string");
  if (!relsXml) return relsMap;

  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(relsXml, "application/xml");
  let relNodes = Array.from(xmlDoc.getElementsByTagName("Relationship"));
  if (relNodes.length === 0) relNodes = Array.from(xmlDoc.getElementsByTagNameNS(relNS, "Relationship"));
  
  for (let i = 0; i < relNodes.length; i++) {
    const rel = relNodes[i];
    const id = rel.getAttribute("Id");
    const target = rel.getAttribute("Target");
    const type = rel.getAttribute("Type") || "";
    if (id && target && (type.includes("image") || target.includes("media/"))) {
      let resolvedTarget = target.replace("../", "");
      if (!resolvedTarget.startsWith("ppt/")) resolvedTarget = "ppt/" + resolvedTarget;
      relsMap.set(id, resolvedTarget);
    }
  }

  return relsMap;
}

// ─── Content Classification ─────────────────────────────────────────────────

function getAllText(shape: ShapeNode): string {
  return shape.paragraphs
    .flatMap(p => p.runs.map(r => r.text))
    .join(" ")
    .trim();
}

function getAllTextFromShapes(shapes: ShapeNode[]): string {
  return shapes.map(getAllText).filter(t => t.length > 0).join(" ");
}

function getMaxFontSize(shape: ShapeNode): number {
  let max = 0;
  for (const p of shape.paragraphs) {
    for (const r of p.runs) {
      if (r.fontSize && r.fontSize > max) max = r.fontSize;
    }
  }
  return max;
}

function getMedianFontSize(shapes: ShapeNode[]): number {
  const sizes: number[] = [];
  for (const s of shapes) {
    for (const p of s.paragraphs) {
      for (const r of p.runs) {
        if (r.fontSize && r.fontSize > 0) sizes.push(r.fontSize);
      }
    }
  }
  if (sizes.length === 0) return 12;
  sizes.sort((a, b) => a - b);
  return sizes[Math.floor(sizes.length / 2)];
}

function shapeArea(s: ShapeNode): number {
  return (s.width / EMU_PER_INCH) * (s.height / EMU_PER_INCH);
}

function extractTitle(shapes: ShapeNode[]): string | null {
  // Priority 1: explicit title placeholder
  for (const s of shapes) {
    if (
      s.placeholderType === "title" ||
      s.placeholderType === "ctrTitle"
    ) {
      const text = getAllText(s);
      if (text) return text;
    }
  }

  // Priority 2: largest font-size text block that looks like a title
  let best: { text: string; size: number } | null = null;
  for (const s of shapes) {
    const maxFs = getMaxFontSize(s);
    const text = getAllText(s);
    if (maxFs >= TITLE_FONT_SIZE_THRESHOLD && text.length > 0 && text.length < 200) {
      if (!best || maxFs > best.size) {
        best = { text, size: maxFs };
      }
    }
  }
  return best?.text || null;
}

function extractSubtitle(shapes: ShapeNode[], title: string | null): string | null {
  // Priority 1: explicit subtitle placeholder
  for (const s of shapes) {
    if (s.placeholderType === "subTitle") {
      const text = getAllText(s);
      if (text) return text;
    }
  }

  // Priority 2: second-largest text that isn't the title
  const medianFs = getMedianFontSize(shapes);
  let best: { text: string; size: number } | null = null;
  for (const s of shapes) {
    if (s.placeholderType === "title" || s.placeholderType === "ctrTitle") continue;
    const text = getAllText(s);
    if (text === title) continue;
    const maxFs = getMaxFontSize(s);
    if (maxFs > medianFs && text.length > 0 && text.length < 300) {
      if (!best || (maxFs > best.size && maxFs < (getMaxFontSize(shapes.find(sh => getAllText(sh) === title) || shapes[0]) || 100))) {
        best = { text, size: maxFs };
      }
    }
  }
  return best?.text || null;
}

function extractBodyText(shapes: ShapeNode[], title: string | null, subtitle: string | null): string | null {
  const bodyParts: string[] = [];
  for (const s of shapes) {
    if (s.imageRefId) continue; // skip image shapes
    if (s.placeholderType === "title" || s.placeholderType === "ctrTitle") continue;
    if (s.placeholderType === "dt" || s.placeholderType === "ftr" || s.placeholderType === "sldNum") continue;

    const text = getAllText(s);
    if (!text) continue;
    if (text === title || text === subtitle) continue;

    // Skip very short decorator text
    if (text.length < 3) continue;

    bodyParts.push(text);
  }

  const body = bodyParts.join("\n\n").trim();
  return body || null;
}

function extractStats(shapes: ShapeNode[]): ExtractedStat[] {
  const stats: ExtractedStat[] = [];
  const medianFs = getMedianFontSize(shapes);

  for (const s of shapes) {
    for (const p of s.paragraphs) {
      for (const r of p.runs) {
        const text = r.text.trim();
        if (!text) continue;

        const isLargeFont = r.fontSize && r.fontSize >= Math.max(STAT_FONT_SIZE_THRESHOLD, medianFs * 1.8);
        const hasStatPattern = STAT_REGEX.test(text) || PERCENTAGE_REGEX.test(text) || CURRENCY_REGEX.test(text);

        if (isLargeFont && (hasStatPattern || /\d/.test(text))) {
          // Found a stat value — now find its label
          const label = findStatLabel(s, p, shapes);
          const context = findStatContext(s, shapes);

          stats.push({
            value: text,
            label,
            context,
          });
        }
      }
    }
  }

  return stats;
}

function findStatLabel(statShape: ShapeNode, statParagraph: Paragraph, allShapes: ShapeNode[]): string {
  // Check other paragraphs in the same shape (usually the label is right below)
  const otherParas = statShape.paragraphs.filter(p => p !== statParagraph);
  for (const op of otherParas) {
    const text = op.runs.map(r => r.text).join("").trim();
    if (text && text.length < 100 && !/^\d/.test(text)) {
      return text;
    }
  }

  // Check nearby shapes (spatially close)
  const statCenterY = statShape.top + statShape.height / 2;
  const statCenterX = statShape.left + statShape.width / 2;
  let closestLabel = "";
  let closestDist = Infinity;

  for (const s of allShapes) {
    if (s === statShape) continue;
    if (s.imageRefId) continue;
    const text = getAllText(s);
    if (!text || text.length > 100 || /^\d/.test(text)) continue;

    const sCenterX = s.left + s.width / 2;
    const sCenterY = s.top + s.height / 2;
    const dist = Math.sqrt(
      Math.pow((sCenterX - statCenterX) / EMU_PER_INCH, 2) +
      Math.pow((sCenterY - statCenterY) / EMU_PER_INCH, 2)
    );

    if (dist < closestDist && dist < 3) {
      closestDist = dist;
      closestLabel = text;
    }
  }

  return closestLabel || "Metric";
}

function findStatContext(statShape: ShapeNode, allShapes: ShapeNode[]): string | null {
  // Look for smaller supporting text near the stat
  for (const s of allShapes) {
    if (s === statShape) continue;
    if (s.imageRefId) continue;
    const text = getAllText(s);
    if (!text || text.length < 20 || text.length > 200) continue;

    const maxFs = getMaxFontSize(s);
    if (maxFs && maxFs <= BODY_FONT_SIZE_MAX) {
      // Check spatial proximity
      const dist = Math.abs(s.top - statShape.top) / EMU_PER_INCH;
      if (dist < 4) return text;
    }
  }
  return null;
}

function extractPillars(shapes: ShapeNode[], title: string | null): ExtractedPillar[] {
  const pillars: ExtractedPillar[] = [];

  // Strategy 1: Look for shapes arranged in a horizontal row (same Y position, different X)
  const textShapes = shapes.filter(
    s => !s.imageRefId &&
      s.placeholderType !== "title" &&
      s.placeholderType !== "ctrTitle" &&
      s.placeholderType !== "subTitle" &&
      s.placeholderType !== "dt" &&
      s.placeholderType !== "ftr" &&
      s.placeholderType !== "sldNum" &&
      getAllText(s).length > 0 &&
      getAllText(s) !== title
  );

  // Group by approximate Y position (within 0.5 inch tolerance)
  const yGroups = new Map<number, ShapeNode[]>();
  for (const s of textShapes) {
    const yBucket = Math.round(s.top / (EMU_PER_INCH * 0.5));
    if (!yGroups.has(yBucket)) yGroups.set(yBucket, []);
    yGroups.get(yBucket)!.push(s);
  }

  // Find groups with 3+ items at similar Y — these are likely pillars
  for (const group of Array.from(yGroups.values())) {
    if (group.length >= 3) {
      // Sort left-to-right
      group.sort((a: ShapeNode, b: ShapeNode) => a.left - b.left);

      for (const s of group) {
        const allParas = s.paragraphs;
        const heading = allParas.length > 0
          ? allParas[0].runs.map((r: TextRun) => r.text).join("").trim()
          : "";
        const body = allParas.length > 1
          ? allParas.slice(1).flatMap((p: Paragraph) => p.runs.map((r: TextRun) => r.text)).join(" ").trim()
          : "";

        if (heading) {
          pillars.push({
            heading,
            body,
            iconHint: guessIconHint(s, heading),
          });
        }
      }
    }
  }

  // Strategy 2: Look for bulleted/numbered lists in a single body shape
  if (pillars.length === 0) {
    for (const s of textShapes) {
      const numberedParas = s.paragraphs.filter(
        p => {
          const text = p.runs.map(r => r.text).join("").trim();
          return /^\d+[\.\)]\s/.test(text) || p.level > 0;
        }
      );

      if (numberedParas.length >= 3) {
        for (const p of numberedParas) {
          const text = p.runs.map(r => r.text).join("").trim();
          const cleaned = text.replace(/^\d+[\.\)]\s*/, "");
          const parts = cleaned.split(/[:\-–—]\s+/);

          pillars.push({
            heading: parts[0]?.trim() || cleaned,
            body: parts.slice(1).join(" ").trim(),
            iconHint: null,
          });
        }
      }
    }
  }

  return pillars;
}

function guessIconHint(shape: ShapeNode, heading: string): string | null {
  const lower = heading.toLowerCase();
  if (/design|creative|visual/i.test(lower)) return "monitor";
  if (/strategy|plan|roadmap/i.test(lower)) return "trending-up";
  if (/tech|develop|code|engineer/i.test(lower)) return "cpu";
  if (/market|growth|scale/i.test(lower)) return "bar-chart";
  if (/team|people|culture/i.test(lower)) return "users";
  if (/security|protect|safe/i.test(lower)) return "shield";
  if (/data|analy/i.test(lower)) return "database";
  if (/cloud|server|infra/i.test(lower)) return "cloud";
  if (/cost|revenue|money|financ/i.test(lower)) return "dollar-sign";
  if (/time|speed|fast/i.test(lower)) return "clock";
  if (/global|world|intern/i.test(lower)) return "globe";
  if (/innovat/i.test(lower)) return "lightbulb";

  // Check if nearby shapes are icons (very small shapes with no text)
  if (shape.shapeType && shape.shapeType !== "rect") return shape.shapeType;

  return null;
}

async function extractImages(zip: JSZip, shapes: ShapeNode[], imageRels: Map<string, string>): Promise<ExtractedImage[]> {
  const images: ExtractedImage[] = [];

  const imageShapes = shapes.filter(s => s.imageRefId);
  // Sort by area descending (largest = most prominent)
  imageShapes.sort((a, b) => shapeArea(b) - shapeArea(a));

  for (let i = 0; i < imageShapes.length; i++) {
    const s = imageShapes[i];
    const area = shapeArea(s);

    // Determine prominence
    let rank: number;
    if (area > 30) rank = 1;       // Full bleed / large background
    else if (area > 10) rank = 1;  // Major image
    else if (area > 3) rank = 2;   // Medium image
    else rank = 3;                 // Small icon/thumbnail

    if (!s.imageRefId) continue;
    
    const imagePath = imageRels.get(s.imageRefId);
    if (!imagePath || !zip.files[imagePath]) {
      continue;
    }

    let dataUrl: string | null = null;
    try {
      const imageData = await zip.files[imagePath].async("base64");
      const ext = imagePath.split('.').pop()?.toLowerCase();
      const mimeMap: Record<string, string> = {
        png: "image/png",
        jpg: "image/jpeg",
        jpeg: "image/jpeg",
        svg: "image/svg+xml",
        gif: "image/gif",
        wdp: "image/vnd.ms-photo"
      };
      const mime = mimeMap[ext || ""] || "image/png";
      dataUrl = `data:${mime};base64,${imageData}`;
    } catch (err) {
      console.warn(`Failed to extract image ${imagePath}`, err);
      continue;
    }

    images.push({
      refId: s.imageRefId,
      dataUrl: dataUrl,
      altText: s.imageAltText || null,
      prominenceRank: rank,
    });
  }

  return images;
}

function inferSlideType(
  title: string | null,
  subtitle: string | null,
  bodyText: string | null,
  stats: ExtractedStat[],
  pillars: ExtractedPillar[],
  images: ExtractedImage[],
  shapes: ShapeNode[],
  allTextContent: string,
  slideIndex: number
): SlideType {
  const textLower = allTextContent.toLowerCase();
  const titleLower = (title || "").toLowerCase();
  const totalTextLength = allTextContent.length;
  const shapeCount = shapes.filter(s => !s.imageRefId && getAllText(s).length > 0).length;

  // Title slide: first slide, or minimal content with large centered text
  if (slideIndex === 0 && totalTextLength < 200 && shapeCount <= 4) return "title";
  if (
    shapeCount <= 3 &&
    totalTextLength < 150 &&
    shapes.some(s => s.placeholderType === "ctrTitle")
  ) return "title";

  // Stat slide: has extracted stats
  if (stats.length > 0) return "stat";

  // Quote slide: has quotation marks or very little text with large font
  if (QUOTE_SIGNALS.some(re => re.test(allTextContent)) && totalTextLength < 300) return "quote";

  // Closing slide
  if (CLOSING_SIGNALS.some(re => re.test(textLower))) return "closing";

  // Team slide
  if (TEAM_SIGNALS.some(re => re.test(textLower)) || (images.length >= 3 && images.every(img => img.prominenceRank >= 2))) return "team";

  // Process slide
  if (PROCESS_SIGNALS.some(re => re.test(textLower)) || (pillars.length >= 3 && /step|phase|stage/i.test(allTextContent))) return "process";

  // Problem slide
  if (PROBLEM_SIGNALS.some(re => re.test(titleLower))) return "problem";

  // Solution slide
  if (SOLUTION_SIGNALS.some(re => re.test(titleLower))) return "solution";

  // Comparison slide
  if (/\bvs\.?\b/i.test(textLower) || /comparison|compare|versus|before.*after/i.test(textLower)) return "comparison";
  if (pillars.length >= 2 && pillars.length <= 4) return "comparison";

  return "generic";
}

function inferThesis(
  slideType: SlideType,
  title: string | null,
  subtitle: string | null,
  bodyText: string | null,
  stats: ExtractedStat[]
): string | null {
  // Title slide: thesis = subtitle
  if (slideType === "title") return subtitle;

  // Stat slide: thesis = stat value + label as sentence
  if (slideType === "stat" && stats.length > 0) {
    return `${stats[0].value} — ${stats[0].label}`;
  }

  // For other types: use the first substantial sentence from body
  if (bodyText) {
    const sentences = bodyText.split(/[.!?]+/).filter(s => s.trim().length > 15);
    if (sentences.length > 0) return sentences[0].trim() + ".";
  }

  // Fallback to title
  if (title) return title;

  return null;
}

function inferLayoutIntent(
  shapes: ShapeNode[],
  images: ExtractedImage[],
  pillars: ExtractedPillar[],
  stats: ExtractedStat[],
  slideType: SlideType
): string {
  const textShapes = shapes.filter(s => !s.imageRefId && getAllText(s).length > 0);
  const imageShapes = shapes.filter(s => s.imageRefId);

  // Determine spatial layout
  const slideWidthEmu = 12192000; // standard 16:9 slide width
  const slideMidX = slideWidthEmu / 2;

  const leftShapes = textShapes.filter(s => (s.left + s.width / 2) < slideMidX);
  const rightShapes = textShapes.filter(s => (s.left + s.width / 2) >= slideMidX);

  const parts: string[] = [];

  // Two-column detection
  if (leftShapes.length > 0 && rightShapes.length > 0 && Math.abs(leftShapes.length - rightShapes.length) <= 2) {
    parts.push("Two-column split.");

    const leftHasImage = imageShapes.some(s => (s.left + s.width / 2) < slideMidX);
    const rightHasImage = imageShapes.some(s => (s.left + s.width / 2) >= slideMidX);

    if (stats.length > 0) parts.push("Left: large stat with supporting text.");
    else parts.push(`Left: ${leftHasImage ? "image with" : ""} text content.`);

    if (rightHasImage) parts.push("Right: photograph/image.");
    else parts.push("Right: supporting text.");
  } else if (pillars.length >= 3) {
    parts.push(`${pillars.length}-column grid layout.`);
    parts.push(`Each column: heading with supporting body text.`);
  } else if (imageShapes.length > 0 && imageShapes[0] && shapeArea(imageShapes[0]) > 30) {
    parts.push("Full-bleed background image with text overlay.");
  } else if (slideType === "title") {
    parts.push("Centered title layout with optional subtitle below.");
  } else if (stats.length > 0) {
    parts.push(`Hero stat layout — large number (${stats[0].value}) as focal point.`);
    if (stats.length > 1) parts.push(`${stats.length} metrics displayed.`);
  } else {
    parts.push("Single-content layout with title and body text.");
  }

  if (imageShapes.length > 0 && parts.every(p => !p.includes("image"))) {
    parts.push(`${imageShapes.length} image(s) embedded.`);
  }

  return parts.join(" ");
}

function inferContentDensity(shapes: ShapeNode[]): ContentDensity {
  const totalChars = shapes.reduce((sum, s) => sum + getAllText(s).length, 0);
  const textShapeCount = shapes.filter(s => getAllText(s).length > 0).length;

  if (totalChars < 100 && textShapeCount <= 3) return "light";
  if (totalChars > 500 || textShapeCount > 8) return "heavy";
  return "medium";
}

function extractBrandSignals(allText: string, shapes: ShapeNode[]): string[] {
  const signals: string[] = [];
  const seen = new Set<string>();

  // Check brand patterns
  for (const pattern of BRAND_PATTERNS) {
    const match = allText.match(pattern);
    if (match && !seen.has(match[0].toLowerCase())) {
      seen.add(match[0].toLowerCase());
      signals.push(match[0]);
    }
  }

  // Check font families for brand typography signals
  const fonts = new Set<string>();
  for (const s of shapes) {
    for (const p of s.paragraphs) {
      for (const r of p.runs) {
        if (r.fontFamily && !r.fontFamily.startsWith("+") && r.fontFamily !== "Calibri") {
          fonts.add(r.fontFamily);
        }
      }
    }
  }
  if (fonts.size > 0) {
    for (const f of Array.from(fonts)) {
      if (!seen.has(f.toLowerCase())) {
        signals.push(`Font: ${f}`);
        seen.add(f.toLowerCase());
      }
    }
  }

  // Check for trademarked terms or proper nouns (capitalized multi-word phrases)
  const properNouns = allText.match(/(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)/g);
  if (properNouns) {
    for (const pn of properNouns.slice(0, 5)) {
      if (!seen.has(pn.toLowerCase()) && pn.length > 5) {
        seen.add(pn.toLowerCase());
        signals.push(pn);
      }
    }
  }

  return signals;
}

// ─── Main Entry Point ────────────────────────────────────────────────────────

/**
 * Extract structured content from a PPTX file.
 *
 * @param file - The PPTX File object uploaded by the user
 * @returns An array of ExtractedSlide objects, one per slide
 */
export async function extractPptxContent(file: File): Promise<ExtractedSlide[]> {
  console.log("Extracting from:", file.name, file.size);
  const arrayBuffer = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(arrayBuffer);

  // Find all slide XML files
  const slideFiles = Object.keys(zip.files)
    .filter(name => /^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a, b) => {
      const numA = parseInt(a.replace(/\D/g, "")) || 0;
      const numB = parseInt(b.replace(/\D/g, "")) || 0;
      return numA - numB;
    });

  console.log("Slides found:", slideFiles);

  const results: ExtractedSlide[] = [];

  for (let i = 0; i < slideFiles.length; i++) {
    const slideFile = slideFiles[i];

    // Log user requested simple paragraph extraction logic
    const xmlStr = await zip.file(slideFile)?.async("string") || "";
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlStr, "application/xml");
    
    const paragraphs = Array.from(doc.getElementsByTagName("a:p"));
    const allTexts = paragraphs.map(p => {
      const tNodes = Array.from(p.getElementsByTagName("a:t"));
      let text = tNodes.map(t => t.textContent || "").join("").trim();
      text = text.replace(/&amp;/g, "&").replace(/&apos;/g, "'").replace(/\xa0/g, " ");
      return text;
    }).filter(t => t.length > 0);

    console.log("Slide", i, "raw text nodes:", allTexts);

    // Parse raw slide data
    const raw = await parseSlideXml(zip, slideFile, i);

    // Resolve image relationships
    const imageRels = await resolveImageRels(zip, slideFile);

    // Extract semantic fields
    const title = extractTitle(raw.shapes);
    const subtitle = extractSubtitle(raw.shapes, title);
    const bodyText = extractBodyText(raw.shapes, title, subtitle);
    const stats = extractStats(raw.shapes);
    const pillars = extractPillars(raw.shapes, title);
    const images = await extractImages(zip, raw.shapes, imageRels);
    const allTextContent = getAllTextFromShapes(raw.shapes);

    // Classify
    const slideType = inferSlideType(
      title, subtitle, bodyText, stats, pillars, images,
      raw.shapes, allTextContent, i
    );
    const thesis = inferThesis(slideType, title, subtitle, bodyText, stats);
    const layoutIntent = inferLayoutIntent(raw.shapes, images, pillars, stats, slideType);
    const contentDensity = inferContentDensity(raw.shapes);
    const brandSignals = extractBrandSignals(allTextContent, raw.shapes);

    results.push({
      slideIndex: i,
      slideType,
      title,
      subtitle,
      bodyText,
      thesis,
      stats,
      pillars,
      images,
      layoutIntent,
      contentDensity,
      brandSignals,
    });
  }

  console.log("Slides found in ZIP:", slideFiles.length);
  console.log("Extracted slides array:", JSON.stringify(results, null, 2));

  return results;
}

/**
 * Convenience wrapper: extract and return as JSON string.
 */
export async function extractPptxContentAsJson(file: File): Promise<string> {
  const slides = await extractPptxContent(file);
  return JSON.stringify(slides, null, 2);
}
