import { extractPptxContent } from './pptxContentExtractor';
import { mapPresentationLayout, MappedSlide } from './layoutMapper';

/**
 * Orchestrates the full pipeline:
 * 1. Agent 1 (PPTX Extractor): Parses raw PowerPoint file into semantic JSON.
 * 2. Agent 2 (Layout Mapper): Maps semantic JSON into the target template slots (GravityOne via Claude).
 * 
 * @param file The uploaded .pptx file (File object from browser)
 * @param onProgress Optional callback to update the caller on pipeline status
 * @returns Fully populated JSON ready for rendering the new presentation
 */
export interface ProcessedPresentation {
  mappedSlides: MappedSlide[];
  imageRegistry: Record<string, string>;
}

export async function processAndMapPresentation(
  file: File, 
  onProgress?: (msg: string) => void
): Promise<ProcessedPresentation> {
  try {
    onProgress?.("Extracting content from PPTX...");
    
    // Step 1: Extract semantic content from raw PPTX
    const extractedSlides = await extractPptxContent(file);
    console.log("After extraction:", extractedSlides.length, "slides");
    
    if (extractedSlides.length === 0) {
      throw new Error("No readable content found in this file. The PPTX may be image-only or corrupted.");
    }
    
    // Build a refId -> dataUrl lookup from extraction output
    const imageRegistry: Record<string, string> = {};
    extractedSlides.forEach(slide => {
      slide.images?.forEach(img => {
        if (img.refId && img.dataUrl) {
          imageRegistry[img.refId] = img.dataUrl;
        }
      });
    });

    onProgress?.(`Extracted ${extractedSlides.length} slides. Mapping layouts...`);

    // Step 2: Map to target layout. Process in chunks to avoid API limits.
    const CHUNK_SIZE = 8;
    const chunks = [];
    for (let i = 0; i < extractedSlides.length; i += CHUNK_SIZE) {
      chunks.push(extractedSlides.slice(i, i + CHUNK_SIZE));
    }

    const finalSlides: MappedSlide[] = [];
    
    for (let c = 0; c < chunks.length; c++) {
      const start = c * CHUNK_SIZE + 1;
      const end = Math.min((c + 1) * CHUNK_SIZE, extractedSlides.length);
      onProgress?.(`Mapping slides ${start}–${end} of ${extractedSlides.length}...`);
      
      try {
        const chunkResult = await mapPresentationLayout("GravityOne", {}, chunks[c]);
        
        if (chunkResult && chunkResult.length === chunks[c].length) {
            finalSlides.push(...chunkResult);
        } else {
            console.warn(`Chunk mapping returned incomplete results (expected ${chunks[c].length}, got ${chunkResult?.length || 0}). Falling back to per-slide...`);
            throw new Error("Incomplete chunk result");
        }
      } catch (err) {
        console.error(`Batch chunk mapping failed (slides ${start}-${end}):`, err);
        // fall back per-slide for this chunk only
        for (let i = 0; i < chunks[c].length; i++) {
          const slideData = chunks[c][i];
          const absoluteIndex = start - 1 + i;
          try {
            const single = await mapPresentationLayout("GravityOne", {}, [slideData]);
            if (single && single.length > 0) {
              finalSlides.push(single[0]);
            } else {
              throw new Error("Empty mapping result from Claude");
            }
          } catch (singleErr) {
            console.error(`Failed mapping for slide ${absoluteIndex}:`, singleErr);
            finalSlides.push({
              slideIndex: slideData.slideIndex ?? absoluteIndex,
              chosenLayout: "BUILDER",
              layoutReason: "Fallback due to mapping error",
              slots: { title: "Slide could not be processed" },
              imageAssignment: [],
              droppedContent: null
            });
          }
        }
      }
    }

    const fallbackCount = finalSlides.filter(s => 
      s.layoutReason === "Fallback due to mapping error"
    ).length;
    
    onProgress?.(
      fallbackCount === 0
        ? `Done. All ${finalSlides.length} slides mapped successfully.`
        : `Done. ${finalSlides.length - fallbackCount} slides mapped, ${fallbackCount} could not be processed.`
    );
    console.log("After mapping:", finalSlides.length, "slides");
    return { mappedSlides: finalSlides, imageRegistry };
  } catch (error) {
    console.error("Presentation orchestration failed:", error);
    throw error;
  }
}
