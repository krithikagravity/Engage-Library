// import PptxGenJS from "pptxgenjs"; // Disabled due to Webpack 5 node:fs error
// Access global variable from CDN script in index.html
const PptxGenJS = (window as any).PptxGenJS;

import { GeneratedResult, GravityData, ArtsyData, DHREData } from "../types";

export const exportToPPT = (result: GeneratedResult) => {
    const pptx = new PptxGenJS();
    pptx.layout = "LAYOUT_16x9";

    // Define content to iterate over (normalize to array)
    let slidesData: (GravityData | ArtsyData | DHREData)[] = [];
    if (Array.isArray(result.content)) {
        slidesData = result.content;
    } else if (result.content && typeof result.content === 'object') {
        // Handle single object vs string
        if ('title' in result.content || 'headline' in result.content) {
            slidesData = [result.content as any];
        }
    }

    // If simple text or image, handle separately (basic fallback)
    if (result.type === 'text' && typeof result.content === 'string') {
        const slide = pptx.addSlide();
        slide.addText(result.content, { x: 1, y: 1, w: "80%", h: "80%", fontSize: 14 });
        pptx.writeFile({ fileName: "Design_Presentation.pptx" });
        return;
    }

    slidesData.forEach((slideData) => {
        if (result.type === "gravity-layout") {
            renderGravitySlide(pptx, slideData as GravityData);
        } else if (result.type === "artsy-layout") {
            renderArtsySlide(pptx, slideData as ArtsyData);
        } else if (result.type === "dhre-layout") {
            renderDHRESlide(pptx, slideData as DHREData);
        }
    });

    pptx.writeFile({ fileName: `Design_System_${new Date().toISOString().split('T')[0]}.pptx` });
};

const cleanHTML = (html?: string) => (html || "").replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ');

// --- GRAVITY LAYOUT RENDERER ---
const renderGravitySlide = (pptx: any, data: GravityData) => {
    const layout = data.layout || 'default';
    if (layout === 'dto') {
        renderDTOSlide(pptx, data);
    } else if (layout === 'landscape') {
        renderLandscapeSlide(pptx, data);
    } else if (layout === 'process') {
        renderProcessSlide(pptx, data);
    } else {
        renderDefaultGravitySlide(pptx, data);
    }
};

const renderDefaultGravitySlide = (pptx: any, data: GravityData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" }; // White bg

    // Title
    slide.addText(cleanHTML(data.title) || "GravityONE", {
        x: 0.5, y: 0.5, w: "90%", h: 1,
        fontSize: 32, bold: true, color: "0F172A", fontFace: "Arial"
    });

    // Thesis
    if (data.thesis) {
        slide.addText(cleanHTML(data.thesis), {
            x: 0.5, y: 1.5, w: "90%", h: 1,
            fontSize: 18, color: "475569", fontFace: "Arial"
        });
    }

    // Pillars (Grid Layout)
    if (data.pillars && data.pillars.length > 0) {
        const startY = 2.8;
        const gap = 0.2;
        const boxW = 2.2;

        data.pillars.forEach((pillar, index) => {
            const x = 0.5 + (index * (boxW + gap));

            // Pillar Title
            slide.addText(cleanHTML(pillar.title), {
                x: x, y: startY, w: boxW, h: 0.5,
                fontSize: 14, bold: true, color: "334155", fill: { color: "F1F5F9" }
            });

            // Pillar Description
            slide.addText(cleanHTML(pillar.description) || "", {
                x: x, y: startY + 0.6, w: boxW, h: 2,
                fontSize: 12, color: "64748B"
            });
        });
    }

    // Summary
    if (data.summary) {
        slide.addText(cleanHTML(data.summary), {
            x: 0.5, y: 6.5, w: "90%", h: 0.8,
            fontSize: 12, italic: true, color: "94A3B8"
        });
    }
};

const renderDTOSlide = (pptx: any, data: GravityData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" };

    // Sidebar
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: "33%", h: "100%", fill: { color: "F8FAFC" } });
    
    // Main Header Bg
    slide.addShape(pptx.ShapeType.rect, { x: "33%", y: 0, w: "67%", h: 1, fill: { color: "1E3A8A" } });
    
    // Main Header
    slide.addText(cleanHTML(data.mainHeader || data.title), { x: "36%", y: 0.1, w: "50%", h: 0.8, fontSize: 24, bold: true, color: "FFFFFF" });
    slide.addText("gravityone", { x: "85%", y: 0.1, w: "15%", h: 0.8, fontSize: 18, bold: true, color: "FFFFFF" });

    // Sidebar Content
    slide.addText(cleanHTML(data.sidebarTitle || data.title), { x: "2%", y: 0.3, w: "29%", h: 0.6, fontSize: 22, bold: true, color: "48A3C6" });
    
    let y = 1.2;
    slide.addText("Problem Addressed", { x: "2%", y, w: "29%", h: 0.3, fontSize: 14, bold: true, color: "1E40AF" });
    y += 0.3;
    slide.addText(cleanHTML(data.problemAddressed || data.thesis), { x: "2%", y, w: "29%", h: 1.0, fontSize: 11, color: "0F172A" });
    y += 1.1;

    slide.addText("Key Buyer:", { x: "2%", y, w: "29%", h: 0.3, fontSize: 12, bold: true, color: "1E40AF" });
    y += 0.3;
    slide.addText(cleanHTML(data.keyBuyer), { x: "2%", y, w: "29%", h: 0.3, fontSize: 11, color: "48A3C6" });
    y += 0.5;

    slide.addText("Qualifying Questions", { x: "2%", y, w: "29%", h: 0.3, fontSize: 12, bold: true, color: "1E40AF" });
    y += 0.4;
    (data.qualifyingQuestions || []).forEach((q: string) => {
        if (!q) return;
        slide.addText(`• ${cleanHTML(q)}`, { x: "3%", y, w: "28%", h: 0.3, fontSize: 10, color: "334155" });
        y += 0.35;
    });

    // Main Content
    slide.addText(cleanHTML(data.subHeader || data.summary), { x: "36%", y: 1.2, w: "60%", h: 0.6, fontSize: 14, color: "1E40AF", align: "center" });

    // Value To Customer
    slide.addShape(pptx.ShapeType.rect, { x: "35%", y: 3.5, w: "40%", h: 2, fill: { color: "F1F5F9" } });
    slide.addText("Value To Customer", { x: "35%", y: 3.5, w: "40%", h: 0.3, fontSize: 10, bold: true, color: "1E40AF" });
    if (data.valueToCustomer) {
        data.valueToCustomer.forEach((v, i) => {
            slide.addText(cleanHTML(v.title), { x: 3.6 + (i * 1.3), y: 3.9, w: 1.2, h: 0.4, fontSize: 9, bold: true, color: "0F172A" });
            slide.addText(cleanHTML(v.description), { x: 3.6 + (i * 1.3), y: 4.3, w: 1.2, h: 1.0, fontSize: 8, color: "475569" });
        });
    }

    // Key Use Cases
    slide.addShape(pptx.ShapeType.rect, { x: "77%", y: 3.5, w: "20%", h: 2, fill: { color: "F1F5F9" } });
    slide.addText("Key Use Cases", { x: "77%", y: 3.5, w: "20%", h: 0.3, fontSize: 10, bold: true, color: "1E40AF" });
    if (data.keyUseCases) {
        let ucy = 3.9;
        data.keyUseCases.forEach((uc: string) => {
            if (!uc) return;
            slide.addText(`• ${cleanHTML(uc)}`, { x: "78%", y: ucy, w: "18%", h: 0.3, fontSize: 8, color: "0F172A" });
            ucy += 0.3;
        });
    }
};

const renderLandscapeSlide = (pptx: any, data: GravityData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" };

    // Sidebar
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: "25%", h: "100%", fill: { color: "FEF9C3" } });
    
    // Main Header Bg
    slide.addShape(pptx.ShapeType.rect, { x: "25%", y: 0, w: "75%", h: 1, fill: { color: "1E3A8A" } });
    
    // Main Header
    slide.addText(cleanHTML(data.mainHeader || data.title), { x: "27%", y: 0.1, w: "50%", h: 0.8, fontSize: 24, bold: true, color: "FFFFFF" });
    
    // Sidebar Content
    slide.addText(cleanHTML(data.sidebarTitle || data.title), { x: "2%", y: 0.3, w: "21%", h: 0.6, fontSize: 22, bold: true, color: "A16207" });
    
    let y = 1.2;
    slide.addText("Problem Addressed", { x: "2%", y, w: "21%", h: 0.3, fontSize: 12, bold: true, color: "1E40AF" });
    y += 0.3;
    slide.addText(cleanHTML(data.problemAddressed || data.thesis), { x: "2%", y, w: "21%", h: 1.0, fontSize: 10, color: "0F172A" });
    y += 1.1;

    slide.addText("Key Buyer:", { x: "2%", y, w: "21%", h: 0.3, fontSize: 12, bold: true, color: "1E40AF" });
    y += 0.3;
    slide.addText(cleanHTML(data.keyBuyer), { x: "2%", y, w: "21%", h: 0.3, fontSize: 10, color: "1E40AF" });
    y += 0.5;

    slide.addText("Qualifying Questions", { x: "2%", y, w: "21%", h: 0.3, fontSize: 12, bold: true, color: "1E40AF" });
    y += 0.4;
    (data.qualifyingQuestions || []).forEach((q: string) => {
        if (!q) return;
        slide.addText(`• ${cleanHTML(q)}`, { x: "3%", y, w: "20%", h: 0.3, fontSize: 9, color: "334155" });
        y += 0.35;
    });

    // Main Content
    slide.addText(cleanHTML(data.subHeader || data.summary), { x: "27%", y: 1.2, w: "70%", h: 0.6, fontSize: 12, color: "1E40AF", align: "center" });

    // Value To Customer
    slide.addShape(pptx.ShapeType.rect, { x: "27%", y: 3.5, w: "48%", h: 2, fill: { color: "F1F5F9" } });
    slide.addText("Value To Customer", { x: "27%", y: 3.5, w: "48%", h: 0.3, fontSize: 10, bold: true, color: "1E40AF" });
    if (data.valueToCustomer) {
        data.valueToCustomer.forEach((v, i) => {
            slide.addText(cleanHTML(v.title), { x: 2.8 + (i * 1.5), y: 3.9, w: 1.4, h: 0.4, fontSize: 9, bold: true, color: "0F172A" });
            slide.addText(cleanHTML(v.description), { x: 2.8 + (i * 1.5), y: 4.3, w: 1.4, h: 1.0, fontSize: 8, color: "475569" });
        });
    }

    // Key Use Cases
    slide.addShape(pptx.ShapeType.rect, { x: "77%", y: 3.5, w: "20%", h: 2, fill: { color: "F1F5F9" } });
    slide.addText("Key Use Cases", { x: "77%", y: 3.5, w: "20%", h: 0.3, fontSize: 10, bold: true, color: "1E40AF" });
    if (data.keyUseCases) {
        let ucy = 3.9;
        data.keyUseCases.forEach((uc: string) => {
            if (!uc) return;
            slide.addText(`• ${cleanHTML(uc)}`, { x: "78%", y: ucy, w: "18%", h: 0.3, fontSize: 8, color: "0F172A" });
            ucy += 0.3;
        });
    }
};

const renderProcessSlide = (pptx: any, data: GravityData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" };

    // Header Bg
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: "100%", h: 1, fill: { color: "170B49" } });
    
    // Header
    slide.addText("Our approach", { x: "5%", y: 0.1, w: "20%", h: 0.3, fontSize: 10, color: "CBD5E1" });
    slide.addText(cleanHTML(data.mainHeader || data.title), { x: "5%", y: 0.4, w: "60%", h: 0.5, fontSize: 24, bold: true, color: "FFFFFF" });

    // Process Intro
    if (data.subHeader || data.thesis) {
        slide.addText(cleanHTML(data.subHeader || data.thesis), { x: "5%", y: 1.2, w: "90%", h: 0.8, fontSize: 14, color: "1E40AF", align: "center" });
    }

    if (data.processSteps && data.processSteps.length > 0) {
        const stepW = 9 / data.processSteps.length;
        data.processSteps.forEach((step, i) => {
            const x = 0.5 + (i * stepW);
            // Step Number
            slide.addText(`0${i + 1}`, { x, y: 2.2, w: stepW - 0.2, h: 0.5, fontSize: 16, bold: true, color: "64748B" });
            // Step Title
            slide.addText(cleanHTML(step.title), { x, y: 2.8, w: stepW - 0.2, h: 0.6, fontSize: 14, bold: true, color: "0F172A" });
            // Step Desc
            slide.addText(cleanHTML(step.description), { x, y: 3.5, w: stepW - 0.2, h: 2, fontSize: 10, color: "475569" });
        });
    }
}

// --- ARTSY LAYOUT RENDERER ---
const renderArtsySlide = (pptx: any, data: ArtsyData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "0F172A" }; // Slate 900

    // Headline (Left)
    slide.addText(data.headline || "Creative Concept", {
        x: 0.5, y: 1.5, w: "45%", h: 2,
        fontSize: 44, bold: true, color: "FFFFFF", fontFace: "Arial"
    });

    // Subheadline
    slide.addText(data.subheadline || "", {
        x: 0.5, y: 3.8, w: "40%", h: 2,
        fontSize: 16, color: "94A3B8"
    });

    // Items (Right list)
    if (data.items && data.items.length > 0) {
        const startY = 1.5;
        data.items.forEach((item, i) => {
            slide.addText(`• ${item.title}`, {
                x: 5.5, y: startY + (i * 0.8), w: "40%", h: 0.6,
                fontSize: 20, color: "E2E8F0"
            });
        });
    }

    // Footer
    if (data.footer) {
        slide.addText(data.footer, {
            x: 0.5, y: 6.8, w: "90%", h: 0.5,
            fontSize: 10, color: "475569"
        });
    }
};

// --- DHRE LAYOUT RENDERER ---
const renderDHRESlide = (pptx: any, data: DHREData) => {
    const slide = pptx.addSlide();
    slide.background = { color: "1e1e1e" }; // Dark Grey

    // Gold Accent Bar
    slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: "100%", h: 0.15, fill: { color: "D4AF37" } });

    // Headline
    slide.addText(data.headline || "Dubai Holding", {
        x: 0.5, y: 1.0, w: "90%", h: 1.5,
        fontSize: 36, bold: true, color: "FFFFFF", fontFace: "Georgia"
    });

    // Subheadline / Content
    slide.addText(data.subheadline || "", {
        x: 0.5, y: 2.8, w: "90%", h: 3.5,
        fontSize: 18, color: "E2E8F0", fontFace: "Arial"
    });

    // Items (if any)
    if (data.items && data.items.length > 0) {
        // Render detailed items if present
        // (Simple list for now as DHRE is text heavy in our prompts)
    }

    // Footer
    slide.addText("Dubai Holding Real Estate", {
        x: 0.5, y: 6.8, w: "40%", h: 0.5,
        fontSize: 10, color: "D4AF37" // Gold text
    });
};
