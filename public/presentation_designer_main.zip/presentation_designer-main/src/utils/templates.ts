import { GravityData, ArtsyData } from "../types";

export const GRAVITY_DEFAULT_DATA: GravityData = {
    title: "GravityONE",
    isHeading: "Is",
    isntHeading: "Isn't",
    antithesis: "another SaaS or BI tool",
    thesis:
        "an Intelligence Orchestration Fabric — a connective layer that brings together:",
    pillars: [
        {
            title: "Institutional Knowledge",
            description: "policies, frameworks, capabilities",
            icon: "settings",
        },
        {
            title: "Human Advisory Intelligence",
            description: "decision reasoning & simulation",
            icon: "user",
        },
        {
            title: "Organisational Data",
            description: "KPIs, risks, benefits",
            icon: "activity",
        },
        {
            title: "Immersive Visualisation",
            description: "that lets leaders see, sense, and steer complexity",
            icon: "eye",
        },
    ],
    summary:
        "Palantir for Strategy Execution — purpose-built for governments and large institutions.",
    positions: {},
};

export const ARTSY_DEFAULT_DATA: ArtsyData = {
    headline:
        "We're part storytellers, part problem-solvers, and full-time designers.",
    subheadline:
        "Our morning coffee blends design, illustration, strategy, and tech to craft experiences that don't just look good — they work smart.",
    footer:
        "Armed with design thinking and a love for experimentation, we help organizations turn challenges into opportunities and ideas into impact.",
    items: [
        { title: "DESIGN", icon: "monitor" },
        { title: "ILLUSTRATION", icon: "image" },
        { title: "STRATEGY", icon: "trending-up" },
        { title: "TECHNOLOGY", icon: "cpu" },
    ],
    positions: {},
};

export const DHRE_DEFAULT_DATA: ArtsyData = {
    headline: "Executive Workshop Brief",
    subheadline: "Understanding the strategic environment",
    footer: "",
    items: [],
};
