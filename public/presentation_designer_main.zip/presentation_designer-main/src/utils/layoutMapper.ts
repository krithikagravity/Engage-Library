import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.REACT_APP_GEMINI_API_KEY || "AIzaSyDST8Kds1S0KzrXrXfKR0d-5e-JjeSNmwg";
const ai = new GoogleGenAI({ apiKey });

export interface MappedSlide {
  slideIndex: number;
  chosenLayout: string;
  layoutReason: string;
  slots: Record<string, any>;
  imageAssignment: {
    slotName: string;
    imageRefId: string;
    reason: string;
  }[];
  droppedContent: string | null;
}

export async function mapPresentationLayout(
  templateName: string,
  templateSchema: Record<string, any>,
  extractionOutput: any[] | Record<string, any>
): Promise<MappedSlide[]> {
  const schemaString = JSON.stringify(templateSchema, null, 2);
  
  // Strip massive base64 dataUrls to avoid exceeding the 200k context or 30k token rate limit
  const cleanExtractionOutput = JSON.parse(JSON.stringify(extractionOutput));
  if (Array.isArray(cleanExtractionOutput)) {
    cleanExtractionOutput.forEach(slide => {
      if (slide.images && Array.isArray(slide.images)) {
        slide.images.forEach((img: any) => {
          if (img.dataUrl) img.dataUrl = "[BASE64_DATA_REMOVED]";
        });
      }
    });
  } else if (cleanExtractionOutput && cleanExtractionOutput.images && Array.isArray(cleanExtractionOutput.images)) {
    cleanExtractionOutput.images.forEach((img: any) => {
      if (img.dataUrl) img.dataUrl = "[BASE64_DATA_REMOVED]";
    });
  }
  const extractionString = JSON.stringify(cleanExtractionOutput, null, 2);

  const systemInstruction = `You are a presentation layout mapper for the GravityOne template. You receive a structured slide payload extracted from an original presentation.

Your job is to map each source slide to the best-fit target layout and fill every slot intelligently. Return a JSON array where each object is a fully populated slide ready for rendering.

The GravityOne template has exactly 4 layouts:

BUILDER — use for: title slides, section openers
  - title (required, max 10 words)
  - subtitle (optional, max 25 words)
  - thesis (optional, max 30 words)
  - image_1 (optional, 1 slot)

DTO — use for: stats, comparisons, problem/solution
  - title (required, max 10 words)
  - left_stat, left_label, right_stat, right_label (optional)
  - image_1 (optional, 1 slot)
  - pillar_1 through pillar_4 (optional)

LANDSCAPE — use for: big concepts, visual-heavy
  - title (required, max 8 words)
  - thesis (optional, max 40 words)
  - image_1 (required, 1 slot)

PROCESS — use for: steps, timelines, how-it-works
  - title (required, max 10 words)
  - step_1 through step_4 (required, each has heading + body)

For each source slide, return:
{
  "slideIndex": number,
  "chosenLayout": string,             // Must be one of the available layout names
  "layoutReason": string,             // One sentence explaining why you chose this layout
  "slots": {                          // Keys match the chosen layout's slot names exactly
    "title": string,
    // ... other slot keys as defined in the layout
  },
  "imageAssignment": [               // Which source images go into which image slots
    { "slotName": string, "imageRefId": string, "reason": string }
  ],
  "droppedContent": string | null    // Describe any content that didn't fit, so the user knows
}

Mapping rules:
- Match slideType to layout: "stat" slides → DTO layout. "process" slides → Process layout. "title" slides → Builder layout. "comparison" slides → DTO layout. When in doubt, prefer the layout that wastes the least content.
- If slideType is "generic" and content has no stats or pillars, default to BUILDER layout.
- If a slide has only 1-2 text nodes and slideType is 'closing' or title is 'Thank You', always assign BUILDER layout with only the title field populated. Never add DTO sidebar fields.
- Image mismatch: more images than slots → keep highest prominence images, drop rest, note in droppedContent. Fewer → leave null, never fabricate. NO images but layout needs one → set image slots to null, choose a different layout if possible.
- Pillar mismatch: more pillars than slots → summarise excess into last slot. Fewer → leave empty slots null.
- Preserve all stats. If the layout has no dedicated stat slot, embed the stat value prominently in the title or thesis field.
- Never truncate the thesis. If the thesis is long, it goes in full — shorten the body instead.
- Write in the same voice and terminology as the source. Do not rephrase into generic language.
- Return only the JSON array. No preamble, no explanation.`;

  try {
    const openaiKey = process.env.REACT_APP_OPENAI_API_KEY || "";
    if (!openaiKey) {
      throw new Error("OpenAI API key is missing. Please add it to your .env file.");
    }
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        temperature: 0.2,
        messages: [
          { role: "system", content: systemInstruction },
          { role: "user", content: `Source slides payload:\n${extractionString}` }
        ]
      })
    });

    console.log("API status:", response.status);
    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      console.error("API error body:", errBody);
      throw new Error(`OpenAI API Error: ${errBody.error?.message || response.statusText}`);
    }

    const data = await response.json();
    
    // Check if the API returned an error object inside a 200 response
    if (data.error && data.error.message) {
      console.error("OpenAI returned an error payload:", data.error.message);
      throw new Error(`OpenAI Error: ${data.error.message}`);
    }

    const text = data.choices?.[0]?.message?.content || "[]";
    console.log("OpenAI raw response:", text);
    const cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();
    
    const parsedData = JSON.parse(cleanedText);
    
    if (!Array.isArray(parsedData)) {
      if (typeof parsedData === 'object' && parsedData !== null) {
        return [parsedData as MappedSlide];
      }
      return [];
    }

    return parsedData as MappedSlide[];
  } catch (error) {
    console.error("Layout mapper error:", error);
    throw new Error("Failed to map presentation layout via AI");
  }
}

export async function reconcileSlideContent(
  originalSlideData: Record<string, any>,
  oldLayout: string,
  oldLayoutSchema: Record<string, any>,
  newLayout: string,
  newLayoutSchema: Record<string, any>
): Promise<MappedSlide> {
  const originalSlideString = JSON.stringify(originalSlideData, null, 2);
  const oldSchemaString = JSON.stringify(oldLayoutSchema, null, 2);
  const newSchemaString = JSON.stringify(newLayoutSchema, null, 2);

  const systemInstruction = `You are remapping a single slide from one layout to another within the GravityOne template.

OLD LAYOUT was: ${oldLayout}
NEW LAYOUT is: ${newLayout}

Here are the slot definitions for both:

${oldLayout} slots:
${oldSchemaString}

${newLayout} slots:
${newSchemaString}

Original slide data:
${originalSlideString}

Your job is to re-fit the slide content into the new layout's slots. Return a single slide JSON object (same schema as above) populated for the new layout.

Rules:
- If the new layout has MORE image slots than the old one, you may promote body images to visual slots if imageRefIds are available. Note this in imageAssignment.reason.
- If the new layout has FEWER image slots, drop by prominence rank as before.
- If the new layout has MORE text slots, split the body text into logical sub-sections to fill them. Do not repeat content.
- If the new layout has FEWER text slots, consolidate body + subtitle into the single available slot, prioritising thesis > title > body > subtitle in that order.
- If a stat existed in the old layout's stat slot but the new layout has no stat slot, embed it in the title as: "[value] — [label]".
- Preserve brand signals and terminology from the original at all costs.
- Return only the single slide JSON object. No preamble.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: "Reconcile the slide content based on the new layout.",
      config: {
        responseMimeType: "application/json",
        systemInstruction: systemInstruction,
        temperature: 0.2, // Low temperature for deterministic layout mapping
      },
    });

    const text = response.text || "{}";
    const cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();
    
    return JSON.parse(cleanedText) as MappedSlide;
  } catch (error) {
    console.error("Content Reconciliation API Error:", error);
    throw new Error("Failed to reconcile slide content via AI");
  }
}
