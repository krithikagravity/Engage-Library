import * as mammoth from "mammoth";
import * as pdfjsLib from "pdfjs-dist";
import JSZip from "jszip";

// Initialize PDF.js worker
// Use CDN for worker to avoid build system issues with worker-loader
// Hardcoding version to match package.json to ensure compatibility
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@2.10.377/build/pdf.worker.min.js`;

export interface DocumentAnalysisResult {
    text: string;
    pageCount: number;
    detectedFonts: string[];
    metadata?: any;
}

export const parseDocument = async (file: File): Promise<DocumentAnalysisResult> => {
    const fileType = file.type;
    const fileName = file.name.toLowerCase();

    if (fileName.endsWith(".docx") || fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
        return parseDocx(file);
    } else if (fileName.endsWith(".pdf") || fileType === "application/pdf") {
        return parsePdf(file);
    } else if (fileName.endsWith(".pptx") || fileType === "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
        return parsePptx(file);
    } else {
        throw new Error("Unsupported file type. Please upload a PDF, DOCX, or PPTX file.");
    }
};

const parsePptx = async (file: File): Promise<DocumentAnalysisResult> => {
    try {
        const arrayBuffer = await file.arrayBuffer();
        const zip = await JSZip.loadAsync(arrayBuffer);
        const slideFiles = Object.keys(zip.files).filter(name => name.startsWith("ppt/slides/slide") && name.endsWith(".xml"));

        let fullText = "";
        const detectedFonts: Set<string> = new Set();

        // Sort slides by number
        slideFiles.sort((a, b) => {
            const numA = parseInt(a.replace(/\D/g, '')) || 0;
            const numB = parseInt(b.replace(/\D/g, '')) || 0;
            return numA - numB;
        });

        for (const fileName of slideFiles) {
            const content = await zip.file(fileName)?.async("string");
            if (content) {
                // Parse PPTX XML structure to extract styles and paragraph breaks
                let slideHtml = "";
                const pMatches = content.match(/<a:p(>| [\s\S]*?>)[\s\S]*?<\/a:p>/g);
                if (pMatches) {
                    pMatches.forEach(p => {
                       let pText = "";
                       const rMatches = p.match(/<a:r(>| [\s\S]*?>)[\s\S]*?<\/a:r>/g);
                       if (rMatches) {
                           rMatches.forEach(r => {
                               const tMatch = r.match(/<a:t(>| [\s\S]*?>)([\s\S]*?)<\/a:t>/);
                               if (tMatch) {
                                   let text = tMatch[2];
                                   const szMatch = r.match(/sz="(\d+)"/);
                                   const fontMatch = r.match(/typeface="([^"]+)"/);
                                   let style = "";
                                   if (fontMatch) {
                                       style += `font-family: '${fontMatch[1]}'; `;
                                   }
                                   if (szMatch) {
                                       // PPT size is 100ths of a point
                                       style += `font-size: ${Math.round(parseInt(szMatch[1]) / 100)}pt; `;
                                   }
                                   
                                   if (style) {
                                       pText += `<span style="${style}">${text}</span>`;
                                   } else {
                                       pText += text;
                                   }
                               }
                           });
                       }
                       
                       if (pText) {
                           slideHtml += pText + "\n";
                       }
                    });
                }
                
                // Decode common XML entities
                let text = slideHtml.replace(/&apos;/g, "'")
                           .replace(/&quot;/g, '"')
                           .replace(/&lt;/g, "<")
                           .replace(/&gt;/g, ">")
                           .replace(/&amp;/g, "&")
                           .trim();

                if (text) {
                    fullText += `--- SLIDE BOUNDARY ---\n${text}\n\n`;
                }

                // Try to find fonts in the XML (typeface="FontName")
                const fontMatches = content.match(/typeface="([^"]+)"/g);
                if (fontMatches) {
                    fontMatches.forEach(m => {
                        const font = m.match(/typeface="([^"]+)"/)?.[1];
                        if (font) detectedFonts.add(font);
                    });
                }
            }
        }

        return {
            text: fullText,
            pageCount: slideFiles.length,
            detectedFonts: Array.from(detectedFonts)
        };
    } catch (error) {
        console.error("PPTX Parsing failed:", error);
        return {
            text: "",
            pageCount: 0,
            detectedFonts: []
        };
    }
};

const parseDocx = async (file: File): Promise<DocumentAnalysisResult> => {
    try {
        const arrayBuffer = await file.arrayBuffer();

        // 1. Get raw text using mammoth (still best for text extraction)
        const mammothResult = await mammoth.extractRawText({ arrayBuffer });
        const text = mammothResult.value;

        // 2. Get metadata using JSZip
        const zip = await JSZip.loadAsync(arrayBuffer);

        // Extract Fonts from word/fontTable.xml
        const detectedFonts: Set<string> = new Set();
        const fontTableXml = await zip.file("word/fontTable.xml")?.async("string");
        if (fontTableXml) {
            const fontMatches = fontTableXml.match(/w:name="([^"]+)"/g);
            if (fontMatches) {
                fontMatches.forEach(m => {
                    const font = m.match(/w:name="([^"]+)"/)?.[1];
                    if (font) detectedFonts.add(font);
                });
            }
        }

        // Extract Page Count from docProps/app.xml
        let pageCount = 0;
        const appXml = await zip.file("docProps/app.xml")?.async("string");
        if (appXml) {
            const pageMatch = appXml.match(/<Pages>(\d+)<\/Pages>/);
            if (pageMatch && pageMatch[1]) {
                pageCount = parseInt(pageMatch[1], 10);
            }
        }

        return {
            text,
            pageCount,
            detectedFonts: Array.from(detectedFonts)
        };
    } catch (error) {
        console.error("DOCX Parsing failed:", error);
        // Fallback if zip parsing fails
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        return {
            text: result.value,
            pageCount: 0,
            detectedFonts: []
        };
    }
};

const parsePdf = async (file: File): Promise<DocumentAnalysisResult> => {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    let fullText = "";
    const detectedFonts: Set<string> = new Set();

    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map((item: any) => {
            if (item.fontName) {
                // Try to resolve font name if possible, often it's an internal ID
                // Just collecting the string for now, logic can be improved if we have font map
                detectedFonts.add(item.fontName);
            }
            return item.str
        }).join(" ");
        fullText += `Page ${i}:\n${pageText}\n\n`;

        // Attempt to get common objects (fonts are often stored here)
        try {
            await page.getOperatorList(); // Ensure operators are loaded to populate commonObjs
            // @ts-ignore - commonObjs is internal but accessible
            const commonObjs = page.commonObjs;
            // @ts-ignore
            commonObjs.forEach((obj: any) => {
                if (obj && obj.name) {
                    detectedFonts.add(obj.name);
                }
            });
        } catch (e) {
            console.warn("Could not extract fonts from page", i, e);
        }
    }

    return {
        text: fullText,
        pageCount: pdf.numPages,
        detectedFonts: Array.from(detectedFonts)
    };
};

export const convertPdfToSvg = async (file: File): Promise<string[]> => {
    try {
        const arrayBuffer = await file.arrayBuffer();
        const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
        const pdf = await loadingTask.promise;
        const svgs: string[] = [];

        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const viewport = page.getViewport({ scale: 1 });

            const operatorList = await page.getOperatorList();

            // @ts-ignore
            const svgGfx = new pdfjsLib.SVGGraphics(page.commonObjs, page.objs);
            const svg = await svgGfx.getSVG(operatorList, viewport);

            if (svg) {
                svgs.push(svg.outerHTML);
            }
        }

        return svgs;
    } catch (error) {
        console.error("Error converting PDF/AI to SVG:", error);
        return [];
    }
};
