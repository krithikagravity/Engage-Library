
import { GoogleGenAI } from "@google/genai";
import { GeneratedResult, GravityData, ArtsyData, DHREData } from "./types";

const apiKey = process.env.REACT_APP_GEMINI_API_KEY || "AIzaSyDST8Kds1S0KzrXrXfKR0d-5e-JjeSNmwg";
const ai = new GoogleGenAI({ apiKey });

// --- Post-Processing: Force Split Long Content ---
// This ensures that even if the AI (Gemini or Pollinations) returns a single slide
// for a massive amount of text, we break it down.
function postProcessContent(result: GeneratedResult, originalPrompt: string, templateType: string): GeneratedResult {
  const isArtsy = templateType === "artsy";
  const isDHRE = templateType === "dhre";

  // Only intervene if it's a single slide layout
  if (result.type === "image" || result.type === "text") return result;

  // If it's already an array, we trust the AI did its job (or our previous logic did)
  if (Array.isArray(result.content)) {
    return result;
  }

  // It's a single slide object. Let's check the length of the "content" payload.
  // We use JSON.stringify to capture ALL text (titles, pillars, footers, etc)
  // instead of just checking specific fields like 'thesis' which might be empty while others are full.
  const contentText = JSON.stringify(result.content);

  const MAX_CHARS_PER_SLIDE = 30000; // Massively increased to support PPT inline HTML

  // If the AI's output is relatively short, return as is.
  if (contentText.length < MAX_CHARS_PER_SLIDE) {
    return result;
  }

  console.log("DEBUG: AI returned single slide but content is huge (" + contentText.length + " chars). Forcing split.");

  // If the content is huge, we ignore the AI's specific structure and re-split 
  // the ORIGINAL prompt (or the extracted text) using our manual logic.
  // This is safer than trying to split the ALREADY summarized AI output, 
  // because the AI might have dropped details we want to keep in subsequent slides.
  return generateManually(originalPrompt, templateType);
}

export const generateContent = async (
  prompt: string,
  forceImage: boolean = false,
  templateType?: "gravity" | "artsy" | "dhre"
): Promise<GeneratedResult> => {
  const lowerPrompt = prompt.toLowerCase();

  // Resolve template type
  let validTemplateType: "gravity" | "artsy" | "dhre" = templateType || "gravity";

  if (!templateType) {
    if (lowerPrompt.includes("artsy") || lowerPrompt.includes("dark mode")) validTemplateType = "artsy";
    else if (lowerPrompt.includes("dhre") || lowerPrompt.includes("dubai holding")) validTemplateType = "dhre";
  }

  const isArtsyRequest = validTemplateType === "artsy";
  const isGravityRequest = validTemplateType === "gravity";
  const isDhreRequest = validTemplateType === "dhre";


  // --- IMAGE GENERATION (ALWAYS POLLINATIONS) ---
  const isImageKeyword =
    /\b(image|picture|photo|template|layout|website|landing page|portfolio|design|ui|ux|mockup|architecture|dashboard|theme|style|slide|presentation)\b/i.test(
      prompt
    );

  const isImageRequest = forceImage || (isImageKeyword && prompt.length < 500);

  if (isImageRequest) {
    const generatedImageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1280&height=720&model=flux`;
    return { type: "image", content: generatedImageUrl };
  }

  let finalResult: GeneratedResult;

  // --- TEXT / JSON GENERATION ---
  try {
    // 1. ARTSY TEMPLATE GENERATION
    if (isArtsyRequest) {
      const systemInstruction = `You are a strict content parser for a design engine.
        Your goal is to map the USER'S INPUT TEXT directly into a JSON object (OR an ARRAY of objects) for a "Dark & Artsy" presentation.

        RULES:
        1. If the input is a long document, split it into multiple logical slides.
        2. USE THE USER'S EXACT WORDS for the "headline" and "subheadline" where possible.
        3. If the user provides unstructured text, intelligently split it into headline (short punchy) and subheadline (descriptive).
        4. Maintain the "Design", "Illustration", "Strategy", "Technology" items unless the user explicitly lists 4 distinct items to replace them.
        5. If the user input starts with "Title:" and/or "Content:", use the text AFTER these labels for the headline and subheadline respectively, stripping the labels themselves.

        The structure for a SINGLE SLIDE is:
        {
          "headline": "The main user text or title. Max 10 words.",
          "subheadline": "The user's description or secondary text.",
          "footer": "A concluding statement (use user text if available, else 'Commercial in Confidence').",
          "items": [
            { "title": "Design", "icon": "monitor" },
            { "title": "Illustration", "icon": "image" },
            { "title": "Strategy", "icon": "trending-up" },
            { "title": "Technology", "icon": "cpu" }
          ]
        }

        Return a JSON ARRAY if multiple slides are needed, or a SINGLE OBJECT if one is sufficient.
        Return ONLY raw JSON. No markdown blocks.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `User Input: "${prompt}". Map this content into the JSON structure (Object or Array).`,
        config: {
          responseMimeType: "application/json",
          systemInstruction: systemInstruction,
          temperature: 0.3,
        },
      });

      const text = response.text || "{}";
      const cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();
      let artsyData: ArtsyData | ArtsyData[] | null = null;

      try {
        artsyData = JSON.parse(cleanedText);
        if (!artsyData) throw new Error("Invalid JSON");
      } catch (e) {
        console.warn("JSON Parse failed, using manual mapping");
        // Fallback to manual if JSON fails
        finalResult = generateManually(prompt, "artsy");
        return postProcessContent(finalResult, prompt, "artsy");
      }

      finalResult = { type: "artsy-layout", content: artsyData! };
      return postProcessContent(finalResult, prompt, "artsy");
    }

    // 2. GRAVITY TEMPLATE GENERATION
    if (isGravityRequest) {
      const isPPT = prompt.includes("[SYSTEM: PPT PARSE INITIATED");
      let systemInstruction = `You are a strict content parser for "GravityONE". 
      Map the USER'S INPUT TEXT directly into a JSON object (OR ARRAY of objects) for the slide(s).
      
      RULES:
      1. If the input is long (like a document), generate MULTIPLE SLIDES (Json Array).
      2. Breakdown the content logically into sections.
      ${isPPT ? "CRITICAL: The text provided is from a PowerPoint presentation and contains IMPORTANT inline HTML `<span style=\"...\">` tags representing the original document's fonts and typography. You MUST strictly preserve these <span> tags explicitly when extracting text into the JSON properties, do not strip them! Map slides 1:1 using the \"--- SLIDE BOUNDARY ---\" markers. Do NOT summarize the text, and do NOT include any system directive text or boundary markers in your output JSON. If the slide contains an obvious 4-part process layout, ensure you use the `pillars` or `processSteps` array in JSON to retain the columns!" : ""}
      3. If the user input starts with "Title:" and/or "Content:", use the text AFTER these labels for the "title" and "thesis" respectively, stripping the labels themselves.
      4. For each slide:
         - "title": Main Subject/Section Title.
         - "isHeading": "Is" (optional)
         - "isntHeading": "Isn't" (optional)
         - "antithesis": What it is NOT (optional)
         - "thesis": What it IS / Main point.
         - "pillars": 4 key points/pillars for this section.
         - "summary": One sentence summary.
         - "metadata": { "type": "comparison" | "process" | "concept" | "details", "importance": "high" | "medium" | "low", "items": number }
      
      Return ONLY raw JSON.`;

      const cleanPrompt = prompt.replace(/\[SYSTEM: PPT PARSE INITIATED[^\]]*\]\n\n/g, "");

      const response = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        contents: `User Input: "${cleanPrompt}". Map this content into the JSON structure (Object or Array).`,
        config: {
          responseMimeType: "application/json",
          systemInstruction: systemInstruction,
          temperature: 0.3,
        },
      });

      const text = response.text || "{}";
      let cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();
      
      // Programmatically strip out any lingering structural markers the AI failed to ignore
      cleanedText = cleanedText.replace(/--- SLIDE BOUNDARY ---/g, "").trim();


      let gravityData: GravityData | GravityData[];
      try {
        gravityData = JSON.parse(cleanedText);
      } catch (e) {
        // Fallback to manual
        finalResult = generateManually(prompt, "gravity");
        return postProcessContent(finalResult, prompt, "gravity");
      }

      // Apply Layout Engine Heuristics based on AI metadata
      const processLayoutRules = (slide: GravityData) => {
        if (slide.metadata) {
          const type = slide.metadata.type?.toLowerCase();
          const items = slide.metadata.items || 0;
          
          if (items > 4) {
            slide.layout = "default";
          } else if (type === "comparison") {
            slide.layout = "dto"; // DTO is the 2-column comparison layout
          } else if (type === "process") {
            slide.layout = "process";
          } else if (type === "concept" || type === "landscape") {
            slide.layout = "landscape";
          }
        }
        
        if (!slide.pillars) slide.pillars = [];
        
        // --- COLUMN FIX ---
        // If the AI failed to map columns and dumped everything into thesis,
        // but the layout explicitly requires process columns, we forcefully distribute
        // the thesis lines into 4 pillars so the process layout doesn't break!
        if (slide.layout === "process" && slide.pillars.length === 0 && slide.thesis) {
            const lines = slide.thesis.split(/<br\s*\/?>|\n/).map(l => l.trim()).filter(l => l.length > 0);
            if (lines.length > 0) {
               const numColumns = 4;
               const chunk = Math.ceil(lines.length / numColumns);
               for (let i = 0; i < numColumns; i++) {
                   const block = lines.slice(i * chunk, (i + 1) * chunk);
                   if (block.length > 0) {
                       slide.pillars.push({
                           title: block[0],
                           description: block.slice(1).join('<br/>'),
                           icon: ""
                       });
                   } else {
                       slide.pillars.push({ title: "", description: "", icon: "" });
                   }
               }
               slide.thesis = ""; // clear thesis to avoid double printing
            }
        }

        if (!slide.title) slide.title = "GravityONE";
      };

      if (Array.isArray(gravityData)) {
        gravityData.forEach(processLayoutRules);
      } else {
        processLayoutRules(gravityData);
      }

      finalResult = { type: "gravity-layout", content: gravityData };
      return postProcessContent(finalResult, prompt, "gravity");
    }

    // 3. DHRE TEMPLATE GENERATION
    if (templateType === 'dhre') {
      const systemInstruction = `You are a strict content parser for the Dubai Holding Real Estate (DHRE) brand guidelines.
      Map the USER'S INPUT TEXT directly into a JSON object (OR ARRAY of objects) for the slide(s).
      
      RULES:
      1. If the input is long (like a document), generate MULTIPLE SLIDES (Json Array).
      2. Extract "headline" and "subheadline" for each slide.
      3. "headline": Main topic or title (max 10 words).
      4. "subheadline": Detailed description or content (can be slightly longer).
      5. If the user input starts with "Title:" and/or "Content:", use the text AFTER these labels for the headline and subheadline respectively, stripping the labels themselves.
      
      The structure for a SINGLE SLIDE is:
      {
        "headline": "...",
        "subheadline": "...",
        "footer": "",
        "items": []
      }
      
      Return ONLY raw JSON.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `User Input: "${prompt}". Map this content into the JSON structure (Object or Array).`,
        config: {
          responseMimeType: "application/json",
          systemInstruction: systemInstruction,
          temperature: 0.3,
        },
      });

      const text = response.text || "{}";
      const cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();

      let dhreData: DHREData | DHREData[];
      try {
        dhreData = JSON.parse(cleanedText);
      } catch (e) {
        // Fallback to manual
        finalResult = generateManually(prompt, "dhre");
        return postProcessContent(finalResult, prompt, "dhre");
      }

      finalResult = { type: "dhre-layout", content: dhreData };
      return postProcessContent(finalResult, prompt, "dhre");
    }

    // 4. STANDARD TEXT GENERATION
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `You are an expert UI/UX Designer. Create a design specification for: "${prompt}". Format in Markdown.`,
    });

    return {
      type: "text",
      content: response.text || "No response generated.",
    };

  } catch (error: any) {
    console.error("Gemini API Error:", error);

    const errorMsg = error.message || JSON.stringify(error) || "";

    // Check for ANY Google API error structure or explicit 404/429
    if (
      // Common Google API error structures
      errorMsg.includes("404") ||
      errorMsg.includes("429") ||
      errorMsg.includes("Quota") ||
      errorMsg.includes("not found") ||
      errorMsg.includes("NOT_FOUND") ||
      errorMsg.includes("Credit limit") ||
      // Or simply fallback if the user is adamant about it causing issues
      apiKey.startsWith("AIzaSy")
    ) {
      console.warn("Google API failed or restricted key used. Executing Pollinations Fallback...");
      try {
        const fallbackResult = await generateWithPollinations(prompt, validTemplateType);
        return postProcessContent(fallbackResult, prompt, validTemplateType);
      } catch (fallbackError: any) {
        console.error("AI Fallbacks Failed. Switching to manual parsing...");
        // 3. TERTIARY FALLBACK: Manual Parsing
        return generateManually(prompt, validTemplateType);
      }
    }

    throw new Error(
      error.message || "Failed to generate content. Please try again."
    );
  }
};

// --- Pollinations AI Fallback ---
async function generateWithPollinations(prompt: string, templateType: string): Promise<GeneratedResult> {
  console.log("DEBUG: generateWithPollinations called");
  const isArtsy = templateType === "artsy";
  const isDHRE = templateType === "dhre";

  let systemPrompt = "";
  if (isArtsy) {
    systemPrompt = "Create a JSON object OR ARRAY of objects for a 'Dark & Artsy' presentation slide. RULES: If content is long, return an ARRAY of objects. Fields per object: headline, subheadline, footer, items (array of {title, icon}). Return ONLY raw JSON.";
  } else if (isDHRE) {
    systemPrompt = "Create a JSON object OR ARRAY of objects for a 'DHRE' brand slide. RULES: If content is long, return an ARRAY of objects. Fields per object: headline, subheadline, footer, items. Return ONLY raw JSON.";
  } else {
    // Gravity default
    systemPrompt = "Create a JSON object OR ARRAY of objects for a 'Gravity' presentation slide. RULES: If content is long, return an ARRAY of objects. Fields per object: title, thesis, summary, pillars (array of strings). Return ONLY raw JSON.";
  }

  const fullPrompt = `${systemPrompt} \n\n User Content: ${prompt}`;
  // Using GET - User reported failures with POST likely CORS related.
  const url = `https://text.pollinations.ai/${encodeURIComponent(fullPrompt)}`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Pollinations HTTP ${response.status}`);

    const text = await response.text();
    const cleanedText = text.replace(/```json\s*|\s*```/g, "").trim();
    let data;

    try {
      data = JSON.parse(cleanedText);
    } catch (e) {
      console.warn("Pollinations JSON parse error, attempting loose parse");
      // Simple recovery attempt
      if (text.includes("{") || text.includes("[")) {
        const start = text.search(/[{}\[]/);
        const end = text.search(/[}\]](?!.*[}\]])/);
        if (start !== -1 && end !== -1) {
          data = JSON.parse(text.substring(start, end + 1));
        }
      }
      if (!data) throw e;
    }

    if (isArtsy) {
      return { type: "artsy-layout", content: data };
    } else if (isDHRE) {
      return { type: "dhre-layout", content: data };
    } else {
      // Ensure Gravity structure
      if (Array.isArray(data)) {
        data = data.map(d => {
          if (!d.title) d.title = "Generated Slide";
          if (!d.pillars) d.pillars = [];
          return d;
        });
      } else {
        if (!data.title) data.title = "Generated Slide";
        if (!data.pillars) data.pillars = [];
      }
      return { type: "gravity-layout", content: data };
    }
  } catch (e: any) {
    throw new Error(`Pollinations Fallback Failed: ${e.message}`);
  }
}

// --- Manual Fallback (No AI) ---
function generateManually(prompt: string, templateType: string): GeneratedResult {
  console.log("DEBUG: generateManually called");
  console.log("DEBUG: Prompt length:", prompt.length);
  const isArtsy = templateType === "artsy";
  const isDHRE = templateType === "dhre";

  // Helper to create a single slide object based on type
  const createSlide = (t: string, c: string) => {
    if (isArtsy) {
      return {
        headline: t,
        subheadline: c,
        footer: "",
        items: [
          { title: "Design", icon: "monitor" },
          { title: "Illustration", icon: "image" },
          { title: "Strategy", icon: "trending-up" },
          { title: "Technology", icon: "cpu" }
        ]
      } as ArtsyData;
    } else if (isDHRE) {
      return {
        headline: t,
        subheadline: c,
        footer: "",
        items: [],
        positions: {}
      } as DHREData;
    } else {
      return {
        title: t || "GravityONE",
        isHeading: "",
        isntHeading: "",
        antithesis: "",
        thesis: c,
        summary: "",
        pillars: [],
        positions: {}
      } as GravityData;
    }
  };

  // 1. Check for explicit markers (User Control - Single Slide)
  // User reported wanting to type "title: ... content: ..." and have it parsed exactly.
  const titleMatch = prompt.match(/title:\s*(.*?)(?=\s*content:|$)/i);
  const contentMatch = prompt.match(/content:\s*([\s\S]*?)(?=$)/i);

  let manualTitle = "Title";
  let manualContent = "";
  let hasManualMarkers = false;

  if (titleMatch || contentMatch) {
    hasManualMarkers = true;
    manualTitle = titleMatch ? titleMatch[1].trim() : "Generated Title";

    // If content match exists, use it. If not, but title exists, use the rest of string? 
    if (contentMatch) {
      manualContent = contentMatch[1].trim();
    } else if (titleMatch) {
      const titleEndIndex = titleMatch.index! + titleMatch[0].length;
      if (prompt.length > titleEndIndex) {
        manualContent = prompt.substring(titleEndIndex).trim();
      }
    }
  }

  // Use manual content if markers found, otherwise fallback to full prompt
  const contentToProcess = hasManualMarkers ? manualContent : prompt;

  if (!contentToProcess) {
    // Edge case: "Title: Foo" and no content. Return single slide.
    const slide = createSlide(manualTitle, "Generated content");
    if (isArtsy) return { type: "artsy-layout", content: slide };
    if (isDHRE) return { type: "dhre-layout", content: slide };
    return { type: "gravity-layout", content: slide };
  }

  // 2. Automatic Splitting for Long Content
  const MAX_CHARS = 300; // Threshold for splitting (VERY LOW FOR DEBUG)

  // Clean the prompt if no markers were found (legacy cleaning)
  // If markers were found, we use the extracted content directly.
  const cleanPrompt = hasManualMarkers
    ? contentToProcess
    : contentToProcess.replace(/^create a presentation based on this content:\s*/i, "").trim();

  if (cleanPrompt.length > MAX_CHARS) {
    const slides: (ArtsyData | DHREData | GravityData)[] = [];

    // First, try splitting by paragraphs (double newlines)
    let paragraphs = cleanPrompt.split(/\n\s*\n/);

    // If we only have 1 paragraph (massive block) but it's huge, split by sentences instead
    if (paragraphs.length === 1 && paragraphs[0].length > MAX_CHARS) {
      const splits = cleanPrompt.match(/[^.!?]+[.!?]+(\s+|$)/g);
      if (splits) paragraphs = splits;
    }

    // FAILSAFE: If still one chunk and it's huge (no punctuation?), force character split
    if (paragraphs.length === 1 && paragraphs[0].length > MAX_CHARS) {
      console.log("DEBUG: content has no punctuation, using hard character split");
      paragraphs = [];
      let remaining = cleanPrompt;
      while (remaining.length > 0) {
        let chunkSize = MAX_CHARS;
        if (remaining.length > MAX_CHARS) {
          const bestSpace = remaining.lastIndexOf(" ", MAX_CHARS);
          if (bestSpace !== -1 && bestSpace > MAX_CHARS / 2) {
            chunkSize = bestSpace;
          }
        }
        paragraphs.push(remaining.substring(0, chunkSize).trim());
        remaining = remaining.substring(chunkSize).trim();
      }
    }

    let currentChunk = "";
    // Use the manual title (if provided) for the first chunk
    let chunkTitle = hasManualMarkers ? manualTitle : "Title";

    for (const para of paragraphs) {
      if (!para.trim()) continue;

      if ((currentChunk + "\n\n" + para).length > MAX_CHARS) {
        if (currentChunk.trim().length > 0) {
          slides.push(createSlide(chunkTitle, currentChunk.trim()));
          currentChunk = "";
          chunkTitle = "Continued..."; // Subsequent slides get generic title
        }

        const p = para.trim();
        if (p.length > MAX_CHARS) {
          let remaining = p;
          while (remaining.length > MAX_CHARS) {
            let cutIndex = remaining.lastIndexOf(" ", MAX_CHARS);
            if (cutIndex === -1) cutIndex = MAX_CHARS;

            slides.push(createSlide(chunkTitle, remaining.substring(0, cutIndex).trim() + "..."));
            remaining = remaining.substring(cutIndex).trim();
            chunkTitle = "Continued...";
          }
          currentChunk = remaining;
        } else {
          currentChunk = p;
        }
      } else {
        currentChunk += (currentChunk ? "\n\n" : "") + para.trim();
      }
    }

    if (currentChunk.trim()) {
      slides.push(createSlide(chunkTitle, currentChunk.trim()));
    }

    // Return Array
    if (isArtsy) return { type: "artsy-layout", content: slides };
    if (isDHRE) return { type: "dhre-layout", content: slides };
    return { type: "gravity-layout", content: slides };
  }

  // 3. Simple Single Slide Fallback (Short content)
  // If markers were used, we already have title/content.
  if (hasManualMarkers) {
    const slide = createSlide(manualTitle, manualContent || "Generated content");
    if (isArtsy) return { type: "artsy-layout", content: slide };
    if (isDHRE) return { type: "dhre-layout", content: slide };
    return { type: "gravity-layout", content: slide };
  }

  const parts = prompt.split(/[\n\r.]+/);
  const title = parts[0].trim().substring(0, 50);
  const content = prompt.substring(title.length).trim() || "Generated content from user input.";

  const slide = createSlide(title || "Generated Title", content);

  if (isArtsy) return { type: "artsy-layout", content: slide };
  if (isDHRE) return { type: "dhre-layout", content: slide };
  return { type: "gravity-layout", content: slide };
}
