export interface Template {
  id: string;
  title: string;
  description: string;
  type: "modern" | "minimalistic" | "professional";
}

export enum GenerationStatus {
  IDLE = "IDLE",
  LOADING = "LOADING",
  SUCCESS = "SUCCESS",
  ERROR = "ERROR",
}

export interface GravityData {
  layout?: 'default' | 'dto' | 'landscape' | 'process';
  title: string;
  isHeading?: string;
  isntHeading?: string;
  antithesis?: string;
  thesis?: string;
  pillars?: {
    title: string;
    description: string;
    icon: string;
  }[];
  summary?: string;
  metadata?: {
    type?: string;
    importance?: string;
    items?: number;
  };
  positions?: Record<string, { x: number; y: number }>;
  
  // Fields for new layouts
  sidebarTitle?: string;
  problemAddressed?: string;
  keyBuyer?: string;
  qualifyingQuestions?: string[];
  mainHeader?: string;
  subHeader?: string;
  images?: { title: string, url: string }[];
  valueToCustomer?: { title: string, description: string }[];
  keyUseCases?: string[];
  processSteps?: { title: string, description: string }[];
  left_stat?: string;
  left_label?: string;
  right_stat?: string;
  right_label?: string;
  customLabels?: Record<string, string>;
}

export interface ArtsyData {
  headline: string;
  subheadline: string;
  footer: string;
  items: {
    title: string;
    icon: string;
  }[];
  positions?: Record<string, { x: number; y: number }>;
}

export type DHREData = ArtsyData;

export interface GeneratedResult {
  type: "text" | "image" | "gravity-layout" | "artsy-layout" | "dhre-layout";
  content: string | GravityData | ArtsyData | DHREData | (GravityData | ArtsyData | DHREData)[];
}

export type { MappedSlide } from "./utils/layoutMapper";
