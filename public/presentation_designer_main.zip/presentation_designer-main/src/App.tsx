import React, { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { MainContent } from "./components/MainContent";
import { RecentProjects } from "./components/RecentProjects";
import { Routes, Route, useLocation } from "react-router-dom";
import { EditorPage } from "./pages/EditorPage";

function App() {
  const [currentView, setCurrentView] = useState<"home" | "recent">("home");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const location = useLocation();

  const isEditor = location.pathname.startsWith("/editor");

  return (
    <div className="flex h-screen w-full bg-[#0D0D0D] overflow-hidden font-sans text-white">
      {!isEditor && (
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
          isCollapsed={isSidebarCollapsed}
          toggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
      )}

      <Routes>
        <Route path="/" element={
          currentView === "home" ? <MainContent /> : <RecentProjects onBack={() => setCurrentView("home")} />
        } />
        <Route path="/editor/:type" element={<EditorPage />} />
      </Routes>
    </div>
  );
}

export default App;
