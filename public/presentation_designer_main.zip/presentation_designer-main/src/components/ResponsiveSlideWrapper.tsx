import React, { useState, useRef, useEffect } from "react";

// --- Responsive Wrapper Component ---
// Scales the 1280x720 content to fit the parent container width
export const ResponsiveSlideWrapper: React.FC<{
    children: React.ReactNode;
    className?: string;
}> = ({ children, className = "" }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [scale, setScale] = useState(1);

    useEffect(() => {
        if (!containerRef.current) return;

        const updateScale = () => {
            if (containerRef.current) {
                const width = containerRef.current.offsetWidth;
                setScale(width / 1280);
            }
        };

        // Initial calculation
        updateScale();

        const observer = new ResizeObserver(updateScale);
        observer.observe(containerRef.current);

        return () => observer.disconnect();
    }, []);

    return (
        <div
            ref={containerRef}
            className={`w-full relative bg-white overflow-hidden ${className}`}
            style={{ aspectRatio: "16/9" }}
        >
            <div
                style={{
                    transform: `scale(${scale})`,
                    transformOrigin: "top left",
                    width: "1280px",
                    height: "720px",
                    position: "absolute",
                    top: 0,
                    left: 0,
                }}
            >
                {children}
            </div>
        </div>
    );
};
