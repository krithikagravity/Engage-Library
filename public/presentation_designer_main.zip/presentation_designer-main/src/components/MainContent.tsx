import React, { useState, useRef } from "react";
import {
  Plus,
  Sparkles,
  Upload,
  Image as ImageIcon,
  Link,
  FileText,
  Compass,
  Download,
  Layout,
  Palette,
  Monitor,
  ShieldCheck,
  ChevronLeft,
  Check,
  Trash2,
  HelpCircle,
  Search,
  Folder,
  ArrowRight,
  FileUp,
  Globe
} from "lucide-react";
import { TemplateCard } from "./TemplateCard";
import { ModeCard } from "./ModeCard";
import { generateContent } from "../gemini";
import { exportToPPT } from "../utils/pptExporter";

import {
  GenerationStatus,
  GeneratedResult,
  GravityData,
  ArtsyData,
} from "../types";
import { ResponsiveSlideWrapper } from "./ResponsiveSlideWrapper";
import { GravitySlide } from "./GravitySlide";
import { DarkArtsySlide } from "./DarkArtsySlide";
import { DHRESlide } from "./DHRESlide";
import { BrandConsistencyCheckMode } from "./BrandConsistencyCheckMode";
import { GRAVITY_DEFAULT_DATA, ARTSY_DEFAULT_DATA, DHRE_DEFAULT_DATA } from "../utils/templates";
import { parseDocument, convertPdfToSvg } from "../utils/documentParser";
import { processAndMapPresentation } from "../utils/presentationOrchestrator";
import { MappedSlide } from "../types";
import { useNavigate } from "react-router-dom";

export const MainContent: React.FC = () => {
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState("");
  const [processingStatus, setProcessingStatus] = useState<string | null>(null);
  const [status, setStatus] = useState<GenerationStatus>(GenerationStatus.IDLE);
  const [result, setResult] = useState<GeneratedResult | null>(null);
  const [svgs, setSvgs] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isImageMode, setIsImageMode] = useState(false);

  // 'convert-presentation' = Show Templates
  const [selectedMode, setSelectedMode] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; size?: string } | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<"gravity" | "artsy" | "dhre" | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async (forcedTemplate?: "gravity" | "artsy" | "dhre") => {
    if (!inputValue.trim() && !forcedTemplate) return;

    // If we have a forced template but no input, just navigate to it (default content)
    if (!inputValue.trim() && forcedTemplate) {
      navigate(`/editor/${forcedTemplate}`);
      return;
    }

    setStatus(GenerationStatus.LOADING);
    setResult(null);
    setErrorMessage(null);
    setIsDropdownOpen(false);

    try {
      let generatedContentResult: GeneratedResult;

         if (inputValue.startsWith("[SYSTEM: PPT PARSE INITIATED")) {
            const cleanInput = inputValue.replace(/\[SYSTEM: PPT PARSE INITIATED[^\]]*\]\n\n/g, "");
            const slidesData = cleanInput.split('--- SLIDE BOUNDARY ---').filter(s => s.trim().length > 0).map((slideText) => {
                const lines = slideText.trim().split('\n').filter(l => l.trim().length > 0);
                const title = lines.length > 0 ? lines[0] : "";
                const contentLines = lines.slice(1);
                const thesis = contentLines.join('<br/><br/>');

                // Explicitly construct 4 columns for layout engines:
                const pillars: any[] = [];
                if (contentLines.length > 0) {
                    const numCols = Math.min(4, Math.max(1, contentLines.length));
                    const chunk = Math.ceil(contentLines.length / numCols);
                    for (let i = 0; i < 4; i++) {
                        if (i < numCols) {
                            const block = contentLines.slice(i * chunk, (i + 1) * chunk);
                            pillars.push({
                                title: block[0] || "",
                                description: block.slice(1).join('<br/>'),
                                icon: ""
                            });
                        } else {
                            pillars.push({ title: "", description: "", icon: "" });
                        }
                    }
                }

                return {
                    title,
                    thesis,
                    pillars,
                    layout: "default" as any
                };
            });
            generatedContentResult = {
                type: forcedTemplate ? `${forcedTemplate}-layout` as any : "gravity-layout",
                content: slidesData
            };
            
         } else if (inputValue.startsWith("[SYSTEM: PPT MAPPED JSON READY")) {
            const cleanInput = inputValue.replace(/\[SYSTEM: PPT MAPPED JSON READY[^\]]*\]\n\n/g, "");
            const parsedData = JSON.parse(cleanInput);
            
            // Extract updated orchestrator return signature or fallback to legacy array
            const slidesData: MappedSlide[] = Array.isArray(parsedData) ? parsedData : parsedData.mappedSlides;
            const imageRegistry: Record<string, string> = Array.isArray(parsedData) ? {} : (parsedData.imageRegistry || {});
            
            generatedContentResult = {
                type: forcedTemplate ? `${forcedTemplate}-layout` as any : "gravity-layout",
                content: slidesData.map((s) => {
                   let layoutStr = s.chosenLayout?.toLowerCase() || "default";
                   if (layoutStr === "builder") layoutStr = "default";
                   
                   let slideData: any = {
                      layout: layoutStr as "default" | "dto" | "landscape" | "process",
                      summary: s.slots?.left_stat ? `${s.slots.left_stat} ${s.slots.left_label || ""}` : "",
                      images: s.imageAssignment?.map(img => ({
                        src: imageRegistry[img.imageRefId] || null,
                        label: img.slotName
                      })).filter(i => i.src) || []
                   };

                   if (layoutStr === "dto") {
                       slideData = {
                           ...slideData,
                           sidebarTitle: s.slots?.title || "",
                           problemAddressed: s.slots?.thesis || "",
                           keyBuyer: s.slots?.left_label || "",
                           mainHeader: s.slots?.title || "",
                           subHeader: s.slots?.subtitle || "",
                           valueToCustomer: s.slots?.left_stat 
                             ? `${s.slots.left_stat} — ${s.slots.left_label || ""}` 
                             : s.slots?.thesis || "",
                           qualifyingQuestions: s.slots?.pillar_1 
                             ? [
                                 s.slots?.pillar_1?.heading || s.slots?.pillar_1 || "",
                                 s.slots?.pillar_2?.heading || s.slots?.pillar_2 || "",
                                 s.slots?.pillar_3?.heading || s.slots?.pillar_3 || "",
                               ].filter(Boolean)
                             : []
                       };
                   } else if (layoutStr === "process") {
                       slideData = {
                           ...slideData,
                           title: s.slots?.title || "Untitled",
                           thesis: s.slots?.thesis || s.slots?.subtitle || "",
                           processSteps: [
                             { title: s.slots?.step_1?.heading || s.slots?.step_1 || "", description: s.slots?.step_1?.body || "" },
                             { title: s.slots?.step_2?.heading || s.slots?.step_2 || "", description: s.slots?.step_2?.body || "" },
                             { title: s.slots?.step_3?.heading || s.slots?.step_3 || "", description: s.slots?.step_3?.body || "" },
                             { title: s.slots?.step_4?.heading || s.slots?.step_4 || "", description: s.slots?.step_4?.body || "" },
                           ].filter(p => p.title !== "")
                       };
                   } else {
                       // BUILDER/DEFAULT/LANDSCAPE etc
                       slideData = {
                           ...slideData,
                           title: s.slots?.title || "Untitled",
                           thesis: s.slots?.thesis || s.slots?.subtitle || "",
                           pillars: [
                             { title: s.slots?.pillar_1?.heading || s.slots?.pillar_1 || "", description: s.slots?.pillar_1?.body || "", icon: "" },
                             { title: s.slots?.pillar_2?.heading || s.slots?.pillar_2 || "", description: s.slots?.pillar_2?.body || "", icon: "" },
                             { title: s.slots?.pillar_3?.heading || s.slots?.pillar_3 || "", description: s.slots?.pillar_3?.body || "", icon: "" },
                             { title: s.slots?.pillar_4?.heading || s.slots?.pillar_4 || "", description: s.slots?.pillar_4?.body || "", icon: "" },
                           ].filter(p => p.title !== "")
                       };
                   }

                   return slideData;
                })
            };
         } else if (inputValue.startsWith("[SYSTEM: PPT EXTRACTED JSON READY")) {
            const cleanInput = inputValue.replace(/\[SYSTEM: PPT EXTRACTED JSON READY[^\]]*\]\n\n/g, "");
            const slidesData = JSON.parse(cleanInput);
            
            generatedContentResult = {
                type: forcedTemplate ? `${forcedTemplate}-layout` as any : "gravity-layout",
                content: slidesData.map((s: any) => {
                   return {
                      title: s.title || "Generated Slide",
                      thesis: s.thesis || s.bodyText || "",
                      layout: forcedTemplate 
                               ? forcedTemplate 
                               : (s.layoutIntent?.toLowerCase().includes("two-column") ? "dto" : 
                                 s.slideType === "process" ? "process" : "default"),
                      pillars: (s.pillars || []).map((p: any) => ({
                         title: p.heading,
                         description: p.body,
                         icon: p.iconHint || ""
                      })),
                      summary: s.stats?.length > 0 ? `Key Metric: ${s.stats[0].value}` : ""
                   };
                })
            };
         } else {
            generatedContentResult = await generateContent(
              inputValue,
              isImageMode,
              forcedTemplate
            );
         }

      // If we forced a template, navigate to editor with the result
      if (forcedTemplate) {
        navigate(`/editor/${forcedTemplate}`, {
          state: { initialData: generatedContentResult.content }
        });
        setStatus(GenerationStatus.IDLE); // Reset status since we navigated away
      } else {
        // Default behavior (show result inline)
        setResult(generatedContentResult);
        setStatus(GenerationStatus.SUCCESS);
      }

    } catch (error: any) {
      console.error(error);
      setStatus(GenerationStatus.ERROR);
      const msg = error.message || "Something went wrong. Please check your API key and try again.";
      setErrorMessage(msg);
      // Force alert for critical config errors so user sees them immediately
      if (msg.includes("API Key") || msg.includes("Quota") || msg.includes("429")) {
        alert(msg);
      }
    } finally {
      if (status === GenerationStatus.LOADING) {
        setStatus(GenerationStatus.IDLE);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleGenerate();
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFile({ 
        name: file.name, 
        size: (file.size / 1024 / 1024).toFixed(1) + " MB" 
      });
      setInputValue(`Reading file: ${file.name}...`);
      setIsDropdownOpen(false);

      try {
        if (file.name.toLowerCase().endsWith(".pptx")) {
            try {
              setProcessingStatus("Starting extraction...");
              const mappedData = await processAndMapPresentation(file, (msg) => {
                setProcessingStatus(msg);
              });
              setProcessingStatus(null);
              setInputValue(`[SYSTEM: PPT MAPPED JSON READY]\n\n${JSON.stringify(mappedData, null, 2)}`);
            } catch (e) {
              setProcessingStatus(null);
              // Fallback to naive text parse if structured extraction fails
              const analysisResult = await parseDocument(file);
              setInputValue(`[SYSTEM: PPT PARSE INITIATED - MAINTAIN STRICT 1:1 SLIDE MAPPING]\n\n${analysisResult.text}`);
            }
        } else {
            const analysisResult = await parseDocument(file);
            setInputValue(`create a presentation based on this content:\n\n${analysisResult.text}`);
        }

        // Convert to SVG if it's a PDF or AI file
        if (file.name.toLowerCase().endsWith(".pdf") || file.name.toLowerCase().endsWith(".ai")) {
          const convertedSvgs = await convertPdfToSvg(file);
          setSvgs(convertedSvgs);
        } else {
          setSvgs([]);
        }

      } catch (error) {
        console.error("Error reading file:", error);
        setProcessingStatus(null);
        setInputValue(`Error reading file: ${file.name}`);
        setErrorMessage("Failed to read file. Please verify the file format (PDF, DOCX, PPTX, or AI).");
        setUploadedFile(null);
      }
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setInputValue(`Selected image: ${file.name}`);
      setIsDropdownOpen(false);
    }
  };

  const toggleImageMode = () => {
    setIsImageMode(!isImageMode);
  };

  const handleUpdate = (newData: GravityData | ArtsyData) => {
    if (result) {
      setResult({ ...result, content: newData });
    }
  };

  return (
    <div className="flex-1 relative overflow-hidden bg-[#F3F5F9]">
      {/* Hidden Inputs */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept=".pdf,.doc,.docx,.pptx,.ai"
        onChange={handleFileSelect}
      />
      <input
        type="file"
        ref={imageInputRef}
        className="hidden"
        accept="image/*"
        onChange={handleImageSelect}
      />

      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[5%] -left-[10%] w-[800px] h-[800px] bg-rose-400/30 rounded-full blur-[120px] mix-blend-multiply filter opacity-90 animate-pulse"></div>
        <div className="absolute -top-[10%] -right-[10%] w-[900px] h-[900px] bg-indigo-400/30 rounded-full blur-[120px] mix-blend-multiply filter opacity-90"></div>
        <div className="absolute bottom-0 left-[20%] w-[600px] h-[600px] bg-purple-400/30 rounded-full blur-[100px] mix-blend-multiply filter opacity-70"></div>
      </div>
      
      {/* Processing Status Banner */}
      {processingStatus && (
        <div className="absolute top-8 left-1/2 transform -translate-x-1/2 z-[100] animate-in slide-in-from-top-4 fade-in duration-300">
          <div className="bg-slate-900/90 backdrop-blur-xl text-white px-6 py-3 rounded-full flex items-center gap-3 shadow-2xl border border-slate-700/50">
             <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
             <span className="text-sm font-medium tracking-wide">{processingStatus}</span>
          </div>
        </div>
      )}

      <div className="relative z-10 flex flex-col h-full overflow-y-auto">
        {/* Added pb-24 for scrolling space */}
        <div className="flex-1 flex flex-col items-center justify-center max-w-6xl mx-auto w-full px-8 py-12 pb-24">
          {selectedMode === 'convert-presentation' && (
            <div className="w-full flex justify-start mb-8 fixed top-8 left-8 z-50">
              <button
                onClick={() => {
                  if (uploadedFile) {
                    setUploadedFile(null);
                    setSelectedTemplate(null);
                  } else {
                    setSelectedMode(null);
                  }
                }}
                className="flex items-center gap-2 bg-white/80 backdrop-blur-md px-4 py-2 rounded-full border border-slate-200 text-slate-700 hover:text-indigo-600 transition-all shadow-sm"
              >
                <ChevronLeft size={18} />
                <span className="text-sm font-semibold">Back</span>
              </button>
            </div>
          )}
          {/* Header - Hide for Brand Consistency Mode */}
          {/* Header - Depends on Mode */}
          {selectedMode === null ? (
            <div className="text-center mb-12 animate-fade-in-up">
              <h1 className="text-slate-900 tracking-tight mb-4 flex flex-col items-center">
                <span className="text-2xl font-light text-slate-500 mb-2">Improve your</span>
                <span className="text-7xl font-normal">Design System</span>
                <span className="text-2xl font-light text-slate-500 mt-2">with AI</span>
              </h1>
              <p className="mt-8 text-slate-600 max-w-2xl mx-auto font-light leading-relaxed text-lg">
                Tailored digital solutions for highly specialized design workflows that help boost your operations
              </p>
            </div>
          ) : null}

          {/* Input Area - Only visible when a mode is selected AND not Brand Consistency AND not Presentation Designer (since it has its own logic now) */}
          {selectedMode !== null && selectedMode !== 'brand-consistency' && selectedMode !== 'convert-presentation' && (
            <div className="w-full max-w-3xl mb-8 animate-fade-in-up delay-100 relative z-50">
              {/* Click backdrop to close dropdown */}
              {isDropdownOpen && (
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setIsDropdownOpen(false)}
                ></div>
              )}

              <div className="relative z-20 flex items-center bg-white/70 backdrop-blur-xl border border-white/50 rounded-full p-2 shadow-xl shadow-indigo-500/10 hover:shadow-indigo-500/20 transition-all duration-300">
                {/* Dropdown */}
                {isDropdownOpen && (
                  <div className="absolute top-full left-0 mt-4 ml-0 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 transform origin-top-left animate-in fade-in slide-in-from-top-2 duration-200 z-50">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center gap-4 px-4 py-3 hover:bg-slate-50 rounded-xl transition-all text-slate-700 text-sm font-medium group text-left"
                    >
                      <Upload
                        size={20}
                        className="text-blue-500 group-hover:scale-110 transition-transform"
                      />{" "}
                      Upload file
                    </button>
                    <button
                      onClick={() => imageInputRef.current?.click()}
                      className="w-full flex items-center gap-4 px-4 py-3 hover:bg-slate-50 rounded-xl transition-all text-slate-700 text-sm font-medium group text-left"
                    >
                      <ImageIcon
                        size={20}
                        className="text-green-500 group-hover:scale-110 transition-transform"
                      />{" "}
                      Upload image
                    </button>
                    <button className="w-full flex items-center gap-4 px-4 py-3 hover:bg-slate-50 rounded-xl transition-all text-slate-700 text-sm font-medium group text-left">
                      <Link
                        size={20}
                        className="text-purple-500 group-hover:scale-110 transition-transform"
                      />{" "}
                      Import from URL
                    </button>
                  </div>
                )}

                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className={`flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 ml-2 flex-shrink-0 cursor-pointer ${isDropdownOpen
                    ? "bg-slate-800 rotate-45"
                    : "bg-[#1A1D21] hover:bg-black"
                    }`}
                >
                  <Plus size={20} className="text-white" />
                </button>

                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={
                    isImageMode
                      ? "Describe the template..."
                      : "Describe the design system..."
                  }
                  className="flex-1 bg-transparent border-none outline-none px-4 text-slate-800 placeholder-slate-500 font-light text-lg h-12"
                  disabled={status === GenerationStatus.LOADING}
                />

                <button
                  onClick={toggleImageMode}
                  className={`flex items-center justify-center w-10 h-10 rounded-full transition-all duration-200 mr-2 ${isImageMode
                    ? "bg-indigo-100 text-indigo-600"
                    : "bg-transparent text-slate-400 hover:bg-slate-100"
                    }`}
                  title={
                    isImageMode ? "Switch to Text Mode" : "Switch to Visual Mode"
                  }
                >
                  {isImageMode ? <ImageIcon size={20} /> : <FileText size={20} />}
                </button>

                <button
                  onClick={() => handleGenerate()}
                  disabled={status === GenerationStatus.LOADING}
                  className={`bg-[#0F1115] text-white px-8 py-3 rounded-full font-medium hover:bg-blue-600 transition-all duration-200 shadow-lg ${status === GenerationStatus.LOADING
                    ? "opacity-70 cursor-wait"
                    : ""
                    }`}
                >
                  {status === GenerationStatus.LOADING
                    ? "Generating..."
                    : "Generate"}
                </button>
              </div>
            </div>
          )}

          {/* Result Area */}
          {status === GenerationStatus.SUCCESS && result && (
            <div className="mt-6 animate-fade-in w-full relative z-10 flex flex-col items-center">
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2 text-indigo-600 bg-white/50 backdrop-blur-md inline-flex px-4 py-1 rounded-full border border-white/60">
                  <Sparkles size={16} />
                  <span className="font-semibold text-xs uppercase tracking-wider">
                    {result.type === "gravity-layout"
                      ? "Generated Slide Deck"
                      : result.type === "artsy-layout"
                        ? "Creative Slide Deck"
                        : "AI Suggestion"}
                  </span>
                </div>
                {/* Top Export Button REMOVED */}
              </div>

              {result.type === "gravity-layout" ? (
                <div className="w-full max-w-5xl flex flex-col gap-8">
                  {Array.isArray(result.content) ? (
                    result.content.map((slideData, index) => (
                      <ResponsiveSlideWrapper key={index} className="shadow-2xl rounded-xl border border-slate-100">
                        <GravitySlide
                          data={slideData as GravityData}
                          onUpdate={handleUpdate}
                        />
                      </ResponsiveSlideWrapper>
                    ))
                  ) : (
                    <ResponsiveSlideWrapper className="shadow-2xl rounded-xl border border-slate-100">
                      <GravitySlide
                        data={result.content as GravityData}
                        onUpdate={handleUpdate}
                      />
                    </ResponsiveSlideWrapper>
                  )}
                </div>
              ) : result.type === "artsy-layout" ? (
                <div className="w-full max-w-5xl flex flex-col gap-8">
                  {Array.isArray(result.content) ? (
                    result.content.map((slideData, index) => (
                      <ResponsiveSlideWrapper key={index} className="shadow-2xl rounded-xl border border-slate-800">
                        <DarkArtsySlide
                          data={slideData as ArtsyData}
                          onUpdate={handleUpdate}
                        />
                      </ResponsiveSlideWrapper>
                    ))
                  ) : (
                    <ResponsiveSlideWrapper className="shadow-2xl rounded-xl border border-slate-800">
                      <DarkArtsySlide
                        data={result.content as ArtsyData}
                        onUpdate={handleUpdate}
                      />
                    </ResponsiveSlideWrapper>
                  )}
                </div>
              ) : result.type === "dhre-layout" ? (
                <div className="w-full max-w-5xl flex flex-col gap-8">
                  {Array.isArray(result.content) ? (
                    result.content.map((slideData, index) => (
                      <ResponsiveSlideWrapper key={index} className="shadow-2xl rounded-xl border border-slate-800">
                        <DHRESlide
                          data={slideData as ArtsyData}
                          onUpdate={handleUpdate}
                        />
                      </ResponsiveSlideWrapper>
                    ))
                  ) : (
                    <ResponsiveSlideWrapper className="shadow-2xl rounded-xl border border-slate-800">
                      <DHRESlide
                        data={result.content as ArtsyData}
                        onUpdate={handleUpdate}
                      />
                    </ResponsiveSlideWrapper>
                  )}
                </div>
              ) : result.type === "image" ? (
                <div className="flex justify-center bg-slate-50 rounded-xl p-2 border border-slate-100 overflow-hidden shadow-2xl">
                  <img
                    src={result.content as string}
                    alt="Generated AI Content"
                    className="rounded-lg w-full h-auto object-cover max-h-[600px]"
                  />
                </div>
              ) : (
                <div className="p-8 bg-white/80 backdrop-blur-xl rounded-2xl border border-white/60 shadow-xl text-left w-full">
                  <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed whitespace-pre-line">
                    {result.content as string}
                  </div>
                </div>
              )}

              {/* Bottom Inline Export Button (Can remove if FAB is enough, but keeping as backup/clearer intent if user scrolls) */}
              <div className="w-full flex justify-center mt-8 mb-4 relative z-20">
                <button
                  onClick={() => exportToPPT(result!)}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-full text-xs font-medium hover:bg-indigo-700 transition-all shadow-lg hover:shadow-indigo-500/30 animate-fade-in-up"
                  title="Export to PowerPoint"
                >
                  <Download size={14} />
                  Export to PPT
                </button>
              </div>
            </div>
          )}

          {status === GenerationStatus.ERROR && (
            <div className="mt-4 text-red-600 text-center bg-red-50 p-3 rounded-lg border border-red-100 relative z-10 font-medium">
              {errorMessage}
            </div>
          )}

          {/* SVG Display Area */}
          {svgs.length > 0 && (
            <div className="w-full max-w-6xl mb-12 animate-fade-in-up">
              <h2 className="text-2xl font-light text-slate-800 mb-6 text-center">Converted Vector Components</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {svgs.map((svg, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden flex flex-col">
                    <div className="p-4 bg-slate-50 flex items-center justify-between border-b border-slate-100">
                      <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Page {index + 1}</span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(svg);
                          alert("SVG copied to clipboard! You can now paste it into Figma.");
                        }}
                        className="text-xs bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full hover:bg-indigo-100 transition-colors font-medium"
                      >
                        Copy to Figma
                      </button>
                    </div>
                    <div className="p-4 flex items-center justify-center min-h-[200px] overflow-auto">
                      <div dangerouslySetInnerHTML={{ __html: svg }} className="w-full h-full max-h-[300px]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mode Selection Grid */}
          {selectedMode === null ? (
            <div className="w-full">
              <h2 className="text-sm font-medium text-slate-500 tracking-wider uppercase mb-6 pl-2">
                Select Mode
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <ModeCard
                  title="Create New Presentation"
                  description="Transform existing decks into GravityOne-branded strategy artefacts with executive clarity."
                  icon={Layout}
                  modeId="convert-presentation"
                  onClick={setSelectedMode}
                  badge="Mode 1"
                />
                <ModeCard
                  title="Brand Consistency Check"
                  description="Ensure content aligns with brand voice, terminology, and guidelines."
                  icon={ShieldCheck}
                  modeId="brand-consistency"
                  onClick={(id) => setSelectedMode(id)}
                  badge="Mode 2"
                />
                <ModeCard
                  title="Brochures & Collaterals"
                  description="Generate sales decks, capability overviews, and one-pagers with strategic positioning."
                  icon={Palette}
                  modeId="brochures"
                  onClick={() => alert("This mode is coming soon!")}
                  badge="Mode 3"
                  isLocked={true}
                />
              </div>
            </div>
          ) : selectedMode === 'brand-consistency' ? (
            <BrandConsistencyCheckMode onBack={() => setSelectedMode(null)} />
          ) : selectedMode === 'convert-presentation' ? (
            <div className="w-full flex-1 flex flex-col items-center animate-fade-in">
              {!uploadedFile ? (
                /* Stage 1: Image 1 equivalent */
                <div className="w-full flex flex-col items-center">
                  <div className="flex flex-col items-center mb-12 text-center">
                    <div className="relative mb-6">
                      <div className="w-16 h-16 bg-[#F1E9FF] rounded-2xl flex items-center justify-center transform rotate-3 shadow-lg border border-purple-100">
                        <FileText className="text-[#A78BFA]" size={32} />
                      </div>
                      <div className="absolute -bottom-1 -right-1 bg-white rounded-lg p-1.5 shadow-xl border border-purple-50 transform -rotate-6">
                        <Plus className="text-[#8B5CF6]" size={16} />
                      </div>
                    </div>
                    <h1 className="text-6xl font-normal text-[#1F2937] tracking-tight mb-4 flex items-center gap-4">
                      Presentation designer
                    </h1>
                    <p className="text-[#4B5563] text-base font-light max-w-xl">
                      Select the file you'd like to transform
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl mb-12">
                    {/* Upload Card */}
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="group bg-[#E8E8FF] rounded-[32px] p-8 cursor-pointer hover:shadow-2xl transition-all duration-500 border-2 border-transparent hover:border-indigo-200 flex flex-col h-[420px] relative overflow-hidden"
                    >
                      <div className="w-24 h-24 bg-[#C7C7FF]/40 rounded-3xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-500">
                        <Folder size={48} className="text-[#818CF8]" />
                      </div>
                      <h3 className="text-xl font-semibold text-[#1F2937] mb-4">Upload a file</h3>
                      <ul className="text-[#4B5563] space-y-3 text-left text-sm font-light">
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Powerpoint PPTX
                        </li>
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Word docs
                        </li>
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          PDFs
                        </li>
                      </ul>
                      <div className="absolute bottom-8 right-8 text-slate-400 group-hover:text-indigo-600 transition-colors duration-300">
                        <FileUp size={32} />
                      </div>
                    </div>

                    {/* Drive Card */}
                    <div className="group bg-[#D1E9FF] rounded-[32px] p-8 cursor-pointer hover:shadow-2xl transition-all duration-500 border-2 border-transparent hover:border-blue-200 flex flex-col h-[420px] relative overflow-hidden">
                      <div className="w-24 h-24 bg-[#A5CFFF]/40 rounded-3xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-500">
                        <div className="w-12 h-10 relative transform scale-110">
                          <div className="absolute top-0 left-2 w-8 h-8 border-t-[8px] border-r-[8px] border-[#60A5FA] border-transparent transform skew-x-12 opacity-80"></div>
                          <div className="absolute top-2 left-6 w-8 h-8 border-t-[8px] border-l-[8px] border-[#2563EB] border-transparent transform -skew-x-12"></div>
                        </div>
                      </div>
                      <h3 className="text-xl font-semibold text-[#1F2937] mb-4">Import from Drive</h3>
                      <ul className="text-[#4B5563] space-y-3 text-left text-sm font-light">
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Google Slides
                        </li>
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Google Docs
                        </li>
                      </ul>
                      <div className="absolute bottom-8 right-8 text-slate-400">
                        <Search size={32} />
                      </div>
                    </div>

                    {/* URL Card */}
                    <div className="group bg-[#CCFBF1] rounded-[32px] p-8 cursor-pointer hover:shadow-2xl transition-all duration-500 border-2 border-transparent hover:border-teal-200 flex flex-col h-[420px] relative overflow-hidden">
                      <div className="w-24 h-24 bg-[#AAF0E4]/40 rounded-3xl flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-500">
                        <Globe size={48} className="text-[#2DD4BF]" />
                      </div>
                      <h3 className="text-xl font-semibold text-[#1F2937] mb-4">Import from URL</h3>
                      <ul className="text-[#4B5563] space-y-3 text-left text-sm font-light">
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Webpages
                        </li>
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Blog posts or articles
                        </li>
                        <li className="flex items-center gap-3">
                          <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                          Notion docs (public only)
                        </li>
                      </ul>
                      <div className="absolute bottom-8 right-8 flex items-center gap-2 text-[#0D9488] font-bold text-lg">
                        Enter URL <Plus size={24} />
                      </div>
                    </div>
                  </div>

                  <p className="text-[#4B5563] text-lg mb-20 font-light">
                    If your file isn't supported, you can also <span className="text-slate-800 font-semibold underline cursor-pointer hover:text-indigo-600 transition-colors">paste in text</span>
                  </p>

                  <div className="w-full max-w-5xl mb-12">
                    <h2 className="text-sm font-medium text-slate-500 tracking-wider uppercase mb-10 text-center">Your recent prompts</h2>
                    <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 border border-white/50 shadow-xl shadow-indigo-100/50 hover:shadow-indigo-200/50 transition-all duration-300 flex items-center justify-between cursor-pointer group">
                      <div className="flex flex-col">
                        <span className="text-xl font-semibold text-[#1F2937] group-hover:text-indigo-600 transition-colors tracking-tight">MEET THE **TEAM:**</span>
                        <span className="text-[#9CA3AF] text-base font-light mt-1">Import PDF · 1 year ago</span>
                      </div>
                      <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                        <ChevronLeft size={28} className="text-slate-400 rotate-180 group-hover:text-indigo-500 transition-transform" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Stage 2: Image 2 equivalent */
                <div className="w-full flex flex-col items-center">
                  <div className="flex flex-col items-center mb-8 text-center">
                    <div className="relative mb-6">
                      <div className="w-16 h-16 bg-[#F1E9FF] rounded-2xl flex items-center justify-center transform rotate-3 shadow-lg border border-purple-100">
                        <FileText className="text-[#A78BFA]" size={32} />
                      </div>
                      <Link className="text-[#8B5CF6] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" size={20} />
                    </div>
                    <h1 className="text-6xl font-normal text-[#1F2937] tracking-tight mb-4 flex items-center gap-4">
                      Presentation designer
                    </h1>
                    <p className="text-[#4B5563] text-base font-light max-w-xl">
                      Select the file you'd like to transform
                    </p>
                  </div>

                  {/* Uploaded File Bar */}
                  <div className="w-full max-w-5xl bg-white rounded-2xl p-6 shadow-xl border border-slate-100 flex items-center justify-between mb-12 animate-in slide-in-from-top-4 duration-500">
                    <div className="flex items-center gap-6">
                      <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-200">
                        <Check size={20} className="text-white" />
                      </div>
                      <span className="text-xl font-medium text-slate-800 tracking-tight">{uploadedFile.name}</span>
                    </div>
                    <button 
                      onClick={() => {
                        setUploadedFile(null);
                        setInputValue("");
                        setSelectedTemplate(null);
                      }}
                      className="w-12 h-12 rounded-xl flex items-center justify-center hover:bg-red-50 text-slate-400 hover:text-red-500 transition-all group"
                    >
                      <Trash2 size={24} className="group-hover:scale-110 transition-transform" />
                    </button>
                  </div>

                  <h2 className="text-sm font-medium text-slate-500 tracking-wider uppercase mb-10 text-center">
                    QUICK START TEMPLATES
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl mb-16">
                    <div className={`relative transition-all duration-300 transform ${selectedTemplate === 'gravity' ? 'scale-105' : 'hover:scale-102'}`}>
                      <TemplateCard
                        title="Gravity themed collateral"
                        subtitle="Intelligence Orchestration Fabric presentation slides"
                        customPreview={
                          <ResponsiveSlideWrapper className={`h-full ${selectedTemplate === 'gravity' ? 'bg-blue-50/50' : 'bg-slate-50'}`}>
                            <GravitySlide data={GRAVITY_DEFAULT_DATA} />
                          </ResponsiveSlideWrapper>
                        }
                        tag="Collateral"
                        tagBg="bg-blue-50"
                        tagColor="text-blue-700"
                        onClick={() => setSelectedTemplate("gravity")}
                      />
                      {selectedTemplate === 'gravity' && (
                        <div className="absolute -top-3 -right-3 w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg border-2 border-white z-20">
                          <Check size={16} className="text-white" />
                        </div>
                      )}
                    </div>
                    
                    <div className={`relative transition-all duration-300 transform ${selectedTemplate === 'artsy' ? 'scale-105' : 'hover:scale-102'}`}>
                      <TemplateCard
                        title="Dark & Artsy"
                        subtitle="Modern storytelling layout"
                        customPreview={
                          <ResponsiveSlideWrapper className={`h-full ${selectedTemplate === 'artsy' ? 'bg-indigo-900/50' : 'bg-slate-900'}`}>
                            <DarkArtsySlide data={ARTSY_DEFAULT_DATA} />
                          </ResponsiveSlideWrapper>
                        }
                        tag="Creative"
                        tagBg="bg-indigo-50"
                        tagColor="text-indigo-700"
                        onClick={() => setSelectedTemplate("artsy")}
                      />
                      {selectedTemplate === 'artsy' && (
                        <div className="absolute -top-3 -right-3 w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg border-2 border-white z-20">
                          <Check size={16} className="text-white" />
                        </div>
                      )}
                    </div>

                    <div className={`relative transition-all duration-300 transform ${selectedTemplate === 'dhre' ? 'scale-105' : 'hover:scale-102'}`}>
                      <TemplateCard
                        title="DHRE Brand guidelines"
                        subtitle="Executive Workshop Brief"
                        customPreview={
                          <ResponsiveSlideWrapper className={`h-full ${selectedTemplate === 'dhre' ? 'bg-slate-900/50' : 'bg-slate-900'}`}>
                            <DHRESlide data={DHRE_DEFAULT_DATA} />
                          </ResponsiveSlideWrapper>
                        }
                        tag="Brand"
                        tagBg="bg-amber-50"
                        tagColor="text-amber-700"
                        onClick={() => setSelectedTemplate('dhre')}
                      />
                      {selectedTemplate === 'dhre' && (
                        <div className="absolute -top-3 -right-3 w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg border-2 border-white z-20">
                          <Check size={16} className="text-white" />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="w-full max-w-md flex flex-col items-center gap-4">
                    <button
                      onClick={() => selectedTemplate && handleGenerate(selectedTemplate)}
                      disabled={!selectedTemplate || status === GenerationStatus.LOADING}
                      className={`w-full bg-[#1D4ED8] text-white py-4 rounded-[16px] text-xl font-bold flex items-center justify-center gap-3 transition-all duration-300 shadow-xl shadow-blue-500/20 active:scale-95 ${
                        !selectedTemplate || status === GenerationStatus.LOADING ? 'opacity-50 grayscale cursor-not-allowed' : 'hover:bg-blue-600 hover:shadow-blue-500/40'
                      }`}
                    >
                      {status === GenerationStatus.LOADING ? "Processing..." : (
                        <>
                          Continue <ArrowRight size={20} />
                        </>
                      )}
                    </button>
                    {!selectedTemplate && (
                      <p className="text-slate-400 font-medium animate-pulse">Select a template to continue</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            // Placeholder for other modes if/when implemented
            <div className="text-center py-20">
              <h3 className="text-xl text-slate-400">Mode content coming soon...</h3>
              <button onClick={() => setSelectedMode(null)} className="mt-4 text-indigo-600 hover:underline">Go Back</button>
            </div>
          )}
        </div>
      </div>

      {/* Floating Action Button (FAB) for Export - Fixed position on screen */}
      {
        status === GenerationStatus.SUCCESS && result && (
          <button
            onClick={() => exportToPPT(result)}
            className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-full shadow-2xl hover:bg-indigo-700 transition-all hover:scale-105 animate-fade-in-up"
            title="Export to PowerPoint"
            style={{ boxShadow: '0 8px 20px -5px rgba(79, 70, 229, 0.4)' }}
          >
            <Download size={18} />
            <span className="font-semibold text-sm">Export PPT</span>
          </button>
        )
      }
    </div>
  );
};
