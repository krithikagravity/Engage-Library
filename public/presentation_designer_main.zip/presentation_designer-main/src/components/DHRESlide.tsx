import React from "react";
import { DHREData } from "../types";
import { DraggableElement } from "./DraggableElement";
import { DubaiHoldingLogo } from "./DubaiHoldingLogo";

export const DHRESlide: React.FC<{
    data: DHREData;
    onUpdate?: (data: DHREData) => void;
}> = ({ data, onUpdate }) => {
    if (!data) return null;

    const handleBlur = (field: keyof DHREData, value: string) => {
        if (onUpdate) {
            onUpdate({ ...data, [field]: value });
        }
    };

    const handleDragStop = (id: string, x: number, y: number) => {
        if (onUpdate) {
            const newPositions = { ...(data.positions || {}) };
            newPositions[id] = { x, y };
            onUpdate({ ...data, positions: newPositions });
        }
    };

    const getPosition = (id: string) => {
        return data.positions?.[id] || { x: 0, y: 0 };
    };

    const Wrapper: React.FC<{
        id: string;
        className?: string;
        children: React.ReactNode;
    }> = ({ id, className, children }) => {
        const pos = getPosition(id);
        if (!onUpdate) {
            return (
                <div
                    className={`relative ${className}`}
                    style={{ transform: `translate(${pos.x}px, ${pos.y}px)` }}
                >
                    {children}
                </div>
            );
        }
        return (
            <DraggableElement
                id={id}
                position={pos}
                onStop={handleDragStop}
                className={className}
            >
                {children}
            </DraggableElement>
        );
    };

    return (
        <div className="w-full h-full relative overflow-hidden font-sans bg-slate-900">
            {/* Background Image */}
            <img
                src="/dhre-final.jpg"
                alt="Background"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none z-0 scale-[1.35] -translate-y-24"
            />

            {/* Overlay for better text readability if needed, though image seems dark enough in parts. 
          Let's add a subtle gradient from top left if needed, or stick to raw image as requested. 
          The reference shows clear text on image. */}

            {/* Content Container */}
            <div className="relative z-10 w-full h-full flex flex-col p-16">

                {/* Logo Area (Top Left) */}
                <Wrapper id="logo" className="mb-20 -mt-6 -ml-6">
                    <DubaiHoldingLogo className="w-32 drop-shadow-md text-white" />
                </Wrapper>

                {/* Main Content Area with Vertical Bar */}
                <div className="flex flex-row items-start -mt-4">
                    {/* Vertical Bar */}
                    <Wrapper id="vertical-bar" className="mr-6">
                        <div className="w-1 h-32 bg-white/90"></div>
                    </Wrapper>

                    <div className="flex flex-col">
                        <Wrapper id="headline">
                            <h1
                                className="text-6xl font-medium text-white mb-2 leading-tight drop-shadow-lg outline-none max-w-4xl"
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("headline", e.currentTarget.textContent || "")
                                }
                            >
                                {data.headline || "Executive Workshop Brief"}
                            </h1>
                        </Wrapper>

                        <Wrapper id="subheadline">
                            <p
                                className="text-3xl text-white/80 font-normal outline-none max-w-3xl"
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("subheadline", e.currentTarget.textContent || "")
                                }
                            >
                                {data.subheadline || "Understanding the strategic environment"}
                            </p>
                        </Wrapper>
                    </div>
                </div>
            </div>
        </div>
    );
};
