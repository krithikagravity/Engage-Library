import React from "react";
import { ArtsyData } from "../types";
import {
    Monitor,
    Image as ImageIcon,
    TrendingUp,
    Cpu,
    Layers,
} from "lucide-react";
import { DraggableElement } from "./DraggableElement";

// --- Dark Artsy Slide Component ---
export const DarkArtsySlide: React.FC<{
    data: ArtsyData;
    onUpdate?: (data: ArtsyData) => void;
}> = ({ data, onUpdate }) => {
    if (!data) return null;

    // Import DraggableElement (assuming it's in the same directory or imported at top)
    // I will assume I need to handle import separately as before or I can try to add it here if I rewrite top.
    // Actually, I can just use the same pattern as GravitySlide: add the logic and wrappers.

    const getIcon = (name: string) => {
        const n = name.toLowerCase();
        if (n.includes("design") || n.includes("monitor")) return Monitor;
        if (n.includes("illustration") || n.includes("image")) return ImageIcon;
        if (n.includes("strategy") || n.includes("trending")) return TrendingUp;
        if (n.includes("tech") || n.includes("cpu")) return Cpu;
        return Layers;
    };

    const handleBlur = (field: keyof ArtsyData, value: string) => {
        if (onUpdate) {
            onUpdate({ ...data, [field]: value });
        }
    };

    const handleItemBlur = (
        index: number,
        field: "title" | "icon",
        value: string
    ) => {
        if (onUpdate) {
            const newItems = [...data.items];
            newItems[index] = { ...newItems[index], [field]: value };
            onUpdate({ ...data, items: newItems });
        }
    };

    const handleDragStop = (id: string, x: number, y: number) => {
        if (onUpdate) {
            const newPositions = { ...(data.positions || {}) };
            newPositions[id] = { x, y };
            onUpdate({ ...data, positions: newPositions });
        }
    };

    const getPosition = (id: string) => {
        return data.positions?.[id] || { x: 0, y: 0 };
    };

    const Wrapper: React.FC<{ id: string, className?: string, children: React.ReactNode }> = ({ id, className, children }) => {
        const pos = getPosition(id);
        if (!onUpdate) {
            return (
                <div
                    className={`relative ${className}`}
                    style={{ transform: `translate(${pos.x}px, ${pos.y}px)` }}
                >
                    {children}
                </div>
            );
        }
        return (
            <DraggableElement id={id} position={pos} onStop={handleDragStop} className={className}>
                {children}
            </DraggableElement>
        );
    };

    return (
        <div className="w-full h-full bg-[#111111] relative overflow-hidden flex items-center justify-center font-sans text-white">
            {/* Background Noise Texture (simulated) */}
            <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
                }}
            ></div>

            {/* Blue Glow Blur */}
            <div className="absolute top-[-20%] left-[20%] w-[800px] h-[600px] bg-[#1d4ed8] rounded-full blur-[140px] opacity-60 pointer-events-none mix-blend-screen"></div>

            {/* Main Container */}
            <div className="flex w-full h-full p-12 items-center relative z-10 pointer-events-none">

                {/* Left Content Box */}
                <div className="flex-1 max-w-4xl relative">
                    {/* The Box Border - Adjusted padding to reduce top space */}
                    <div className="border border-white/90 px-10 pb-10 pt-8 relative bg-black/10 backdrop-blur-sm pointer-events-auto">
                        {/* Top Star Decoration - Positioned exactly on the line */}
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white z-20 bg-[#111111] rounded-full p-1">
                            <div className="relative">
                                <svg
                                    width="60"
                                    height="60"
                                    viewBox="0 0 24 24"
                                    fill="white"
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="relative z-10"
                                >
                                    <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                                </svg>
                                {/* Glow behind star */}
                                <div className="absolute inset-0 bg-blue-500 blur-xl opacity-50"></div>
                            </div>
                        </div>
                        {/* Smaller Star */}
                        <div className="absolute -top-12 left-[60%] text-white opacity-80">
                            <svg
                                width="30"
                                height="30"
                                viewBox="0 0 24 24"
                                fill="white"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                            </svg>
                        </div>

                        <Wrapper id="headline">
                            <h1
                                className="text-[38px] font-bold text-[#38bdf8] mb-4 leading-tight drop-shadow-md outline-none"
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("headline", e.currentTarget.textContent || "")
                                }
                            >
                                {data.headline || "Content Generated..."}
                            </h1>
                        </Wrapper>

                        <Wrapper id="subheadline">
                            <p
                                className="text-[22px] text-white font-normal leading-relaxed mb-6 opacity-90 outline-none"
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("subheadline", e.currentTarget.textContent || "")
                                }
                            >
                                {data.subheadline}
                            </p>
                        </Wrapper>

                        {/* Footer - Only show if we have a footer string */}
                        {data.footer && (
                            <Wrapper id="footer">
                                <p
                                    className="text-[22px] text-white font-normal leading-relaxed opacity-90 outline-none"
                                    contentEditable={!!onUpdate}
                                    suppressContentEditableWarning
                                    onBlur={(e) =>
                                        handleBlur("footer", e.currentTarget.textContent || "")
                                    }
                                >
                                    {data.footer}
                                </p>
                            </Wrapper>
                        )}
                    </div>
                </div>

                {/* Right Menu (Orbits) - Only show if we have items */}
                {data.items && data.items.length > 0 && (
                    <div className="w-64 flex flex-col justify-center items-center gap-6 ml-12 relative h-full pointer-events-none">
                        {data.items.map((item, idx) => {
                            const Icon = getIcon(item.icon);
                            return (
                                <Wrapper key={idx} id={`item-${idx}`} className="pointer-events-auto w-full">
                                    <div
                                        className="relative w-full flex flex-col items-center justify-center group h-32"
                                    >
                                        {/* Orbit Ellipse */}
                                        <div className="absolute inset-0 border border-dashed border-[#38bdf8]/30 rounded-[100%] w-full h-full transform rotate-[-5deg] group-hover:border-[#38bdf8] transition-colors duration-300"></div>

                                        {/* Icon & Label */}
                                        <div className="flex flex-col items-center gap-3 z-10 transform group-hover:scale-110 transition-transform duration-300">
                                            <div className="bg-white/5 p-2 rounded-lg backdrop-blur-md border border-white/20 shadow-lg">
                                                <Icon size={24} className="text-white" />
                                            </div>
                                            <span
                                                className="text-[#38bdf8] font-bold text-[10px] tracking-[0.2em] uppercase outline-none"
                                                contentEditable={!!onUpdate}
                                                suppressContentEditableWarning
                                                onBlur={(e) =>
                                                    handleItemBlur(
                                                        idx,
                                                        "title",
                                                        e.currentTarget.textContent || ""
                                                    )
                                                }
                                            >
                                                {item.title}
                                            </span>
                                        </div>
                                    </div>
                                </Wrapper>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};
