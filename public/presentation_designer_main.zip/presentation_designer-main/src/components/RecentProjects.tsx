import React, { useState } from "react";
import {
  ArrowLeft,
  Search,
  Monitor,
  LayoutGrid,
  Smartphone,
  Globe,
} from "lucide-react";

interface RecentProjectsProps {
  onBack: () => void;
}

interface Project {
  id: number;
  title: string;
  description: string;
  type: "Web" | "Dashboard" | "Mobile";
  time: string;
  icon: React.ReactNode;
  iconBg: string;
  iconColor: string;
  tagBg: string;
  tagColor: string;
}

export const RecentProjects: React.FC<RecentProjectsProps> = ({ onBack }) => {
  const [activeFilter, setActiveFilter] = useState("All");

  const projects: Project[] = [
    {
      id: 1,
      title: "E-commerce Website",
      description: "Modern online shopping platform",
      type: "Web",
      time: "2 hours ago",
      icon: <Monitor size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 2,
      title: "Analytics Dashboard",
      description: "Data visualization and metrics",
      type: "Dashboard",
      time: "Yesterday",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 3,
      title: "Fitness Tracking App",
      description: "Health and workout tracker",
      type: "Mobile",
      time: "3 days ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
    {
      id: 4,
      title: "Portfolio Site",
      description: "Personal portfolio website",
      type: "Web",
      time: "1 week ago",
      icon: <Monitor size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 5,
      title: "Admin Panel",
      description: "Content management system",
      type: "Dashboard",
      time: "2 weeks ago",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 6,
      title: "Social Media App",
      description: "Social networking platform",
      type: "Mobile",
      time: "3 weeks ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
    {
      id: 7,
      title: "Corporate Portal",
      description: "Internal employee intranet",
      type: "Web",
      time: "1 month ago",
      icon: <Globe size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 8,
      title: "Inventory System",
      description: "Stock management dashboard",
      type: "Dashboard",
      time: "1 month ago",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 9,
      title: "Travel Companion",
      description: "Trip planning application",
      type: "Mobile",
      time: "2 months ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
    {
      id: 10,
      title: "Blog Platform",
      description: "Content publishing engine",
      type: "Web",
      time: "2 months ago",
      icon: <Monitor size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 11,
      title: "Sales CRM",
      description: "Customer relationship manager",
      type: "Dashboard",
      time: "2 months ago",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 12,
      title: "Food Delivery",
      description: "Ordering and tracking app",
      type: "Mobile",
      time: "3 months ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
    {
      id: 13,
      title: "Product Landing Page",
      description: "High conversion marketing page",
      type: "Web",
      time: "3 months ago",
      icon: <Globe size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 14,
      title: "HR System",
      description: "Employee management portal",
      type: "Dashboard",
      time: "4 months ago",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 15,
      title: "Meditation App",
      description: "Wellness and mindfulness",
      type: "Mobile",
      time: "4 months ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
    {
      id: 16,
      title: "Documentation Site",
      description: "Technical docs knowledge base",
      type: "Web",
      time: "5 months ago",
      icon: <Monitor size={24} />,
      iconBg: "bg-cyan-100",
      iconColor: "text-cyan-600",
      tagBg: "bg-cyan-50",
      tagColor: "text-cyan-700",
    },
    {
      id: 17,
      title: "Project Management",
      description: "Task tracking dashboard",
      type: "Dashboard",
      time: "6 months ago",
      icon: <LayoutGrid size={24} />,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      tagBg: "bg-yellow-50",
      tagColor: "text-yellow-700",
    },
    {
      id: 18,
      title: "E-wallet App",
      description: "Digital payment solution",
      type: "Mobile",
      time: "6 months ago",
      icon: <Smartphone size={24} />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-500",
      tagBg: "bg-pink-50",
      tagColor: "text-pink-700",
    },
  ];

  // Limit 'All' view to 4 items, but show all items for specific filters
  const filteredProjects =
    activeFilter === "All"
      ? projects.slice(0, 4)
      : projects.filter((p) => p.type === activeFilter);

  return (
    <div className="flex-1 bg-[#FDFCFD] overflow-y-auto">
      <div className="max-w-7xl mx-auto px-10 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-2 animate-fade-in-up">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-700"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">
              Recent Projects
            </h1>
            <p className="text-slate-500 mt-1">
              All your recent work in one place
            </p>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-8 mb-10 animate-fade-in-up delay-100">
          <div className="relative w-full md:w-96">
            <Search
              className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              size={18}
            />
            <input
              type="text"
              placeholder="Search projects..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all shadow-sm"
            />
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            <button
              onClick={() => setActiveFilter("All")}
              className={`px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeFilter === "All"
                  ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md shadow-blue-500/20"
                  : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              All
            </button>
            <button
              onClick={() => setActiveFilter("Web")}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeFilter === "Web"
                  ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md"
                  : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              <Globe size={16} />
              Web
            </button>
            <button
              onClick={() => setActiveFilter("Dashboard")}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeFilter === "Dashboard"
                  ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md"
                  : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              <LayoutGrid size={16} />
              Dashboard
            </button>
            <button
              onClick={() => setActiveFilter("Mobile")}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeFilter === "Mobile"
                  ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md"
                  : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              <Smartphone size={16} />
              Mobile
            </button>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in-up delay-200">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-6">
                <div
                  className={`w-14 h-14 rounded-2xl ${project.iconBg} flex items-center justify-center ${project.iconColor} transition-transform group-hover:scale-110 duration-300`}
                >
                  {project.icon}
                </div>
                <span className="text-xs font-medium text-slate-400">
                  {project.time}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
                {project.title}
              </h3>
              <p className="text-slate-500 text-sm mb-6 leading-relaxed">
                {project.description}
              </p>

              <div className="flex items-center">
                <span
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold ${project.tagBg} ${project.tagColor}`}
                >
                  {project.type} Project
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
