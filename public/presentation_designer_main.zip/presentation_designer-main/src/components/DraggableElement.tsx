import React, { useRef } from "react";
import Draggable from "react-draggable";
import { GripVertical } from "lucide-react";

interface DraggableElementProps {
    id: string;
    position: { x: number; y: number };
    onStop: (id: string, x: number, y: number) => void;
    children: React.ReactNode;
    className?: string;
    isEditable?: boolean;
}

export const DraggableElement: React.FC<DraggableElementProps> = ({
    id,
    position,
    onStop,
    children,
    className = "",
    isEditable = false,
}) => {
    const nodeRef = useRef(null);
    const [currentPos, setCurrentPos] = React.useState(position);

    // Sync local state with prop when it changes (e.g. external update or slide switch)
    React.useEffect(() => {
        setCurrentPos(position);
    }, [position.x, position.y]);

    const handleDrag = (_e: any, data: { x: number; y: number }) => {
        setCurrentPos({ x: data.x, y: data.y });
    };

    const handleStop = (_e: any, data: { x: number; y: number }) => {
        setCurrentPos({ x: data.x, y: data.y });
        onStop(id, data.x, data.y);
    };

    return (
        <Draggable
            nodeRef={nodeRef}
            position={currentPos}
            onDrag={handleDrag}
            onStop={handleStop}
            handle=".drag-handle"
            cancel="[contenteditable]"
        >
            <div
                ref={nodeRef}
                className={`relative group hover:ring-1 hover:ring-indigo-500/50 hover:bg-slate-500/5 p-1 rounded transition-shadow ${className}`}
                style={{ zIndex: 10 }}
            >
                {/* Drag Handle - visible on hover */}
                <div className="drag-handle absolute -top-3 -left-3 p-1 bg-white shadow-md rounded-full cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition-opacity z-50 border border-slate-200">
                    <GripVertical size={14} className="text-slate-500" />
                </div>
                {children}
            </div>
        </Draggable>
    );
};
