import React, { useState } from "react";
import {
  Folder,
  Plus,
  User,
  ChevronLeft,
  ChevronRight,
  Hexagon,
  Crown,
  Settings,
  LogOut,
} from "lucide-react";

interface SidebarProps {
  currentView: "home" | "recent";
  onNavigate: (view: "home" | "recent") => void;
  isCollapsed: boolean;
  toggleSidebar: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  isCollapsed,
  toggleSidebar,
}) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <div
      className={`${isCollapsed ? "w-20" : "w-72"
        } bg-white border-r border-slate-200 text-slate-500 flex flex-col h-full relative flex-shrink-0 z-20 transition-all duration-300 ease-in-out`}
    >
      {/* Logo Section */}
      <div
        className={`p-8 flex items-center ${isCollapsed ? "justify-center" : "space-x-4"
          }`}
      >
        <div className="relative w-8 h-8 flex items-center justify-center flex-shrink-0 group cursor-pointer">
          <div className="absolute inset-0 bg-indigo-500 rounded-full opacity-0 group-hover:opacity-10 blur-md transition-opacity"></div>
          <Hexagon className="relative z-10 w-6 h-6 text-indigo-600 fill-current opacity-90" />
        </div>

        <div
          className={`transition-all duration-200 overflow-hidden ${isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"
            }`}
        >
          <h1 className="text-xl font-medium text-slate-800 tracking-tight whitespace-nowrap">
            Gravity AI
          </h1>
        </div>
      </div>

      {/* Collapse Toggle */}
      <button
        onClick={toggleSidebar}
        className="absolute -right-3 top-10 bg-white border border-slate-200 rounded-full p-1 text-slate-400 hover:text-indigo-600 hover:border-indigo-200 transition-all z-50 shadow-sm"
      >
        {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-8 space-y-2">
        <button
          onClick={() => onNavigate("home")}
          title={isCollapsed ? "Create new" : ""}
          className={`w-full flex items-center ${isCollapsed ? "justify-center px-0" : "space-x-3 px-4"
            } py-3.5 rounded-xl transition-all duration-300 group ${currentView === "home"
              ? "bg-indigo-50 text-indigo-700"
              : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
            }`}
        >
          <Plus
            size={18}
            className={`flex-shrink-0 ${currentView === "home"
                ? "text-indigo-600"
                : "text-slate-400 group-hover:text-slate-600"
              }`}
          />
          <span
            className={`font-medium text-sm tracking-wide whitespace-nowrap transition-all duration-200 overflow-hidden ${isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"
              }`}
          >
            Create Project
          </span>
        </button>

        <button
          onClick={() => onNavigate("recent")}
          title={isCollapsed ? "Recent" : ""}
          className={`w-full flex items-center ${isCollapsed ? "justify-center px-0" : "space-x-3 px-4"
            } py-3.5 rounded-xl transition-all duration-300 group ${currentView === "recent"
              ? "bg-indigo-50 text-indigo-700"
              : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
            }`}
        >
          <Folder
            size={18}
            className={`flex-shrink-0 ${currentView === "recent"
                ? "text-indigo-600"
                : "text-slate-400 group-hover:text-slate-600"
              }`}
          />
          <span
            className={`font-medium text-sm tracking-wide whitespace-nowrap transition-all duration-200 overflow-hidden ${isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"
              }`}
          >
            All Projects
          </span>
        </button>
      </nav>

      {/* Profile Section */}
      <div className="p-4 mt-auto">
        {/* Animated Popover Menu */}
        <div
          className={`flex flex-col space-y-1 mb-2 overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] ${isProfileOpen && !isCollapsed
              ? "max-h-[300px] opacity-100 translate-y-0"
              : "max-h-0 opacity-0 translate-y-4"
            }`}
        >
          <button className="w-full flex items-center space-x-3 hover:bg-slate-50 text-slate-500 hover:text-slate-900 px-4 py-2.5 rounded-lg transition-colors duration-200">
            <Crown size={16} className="text-amber-500 flex-shrink-0" />
            <span className="font-medium text-xs whitespace-nowrap">
              Upgrade Plan
            </span>
          </button>

          <button className="w-full flex items-center space-x-3 hover:bg-slate-50 text-slate-500 hover:text-slate-900 px-4 py-2.5 rounded-lg transition-colors duration-200">
            <Settings size={16} className="text-slate-400 flex-shrink-0" />
            <span className="font-medium text-xs whitespace-nowrap">
              Settings
            </span>
          </button>

          <button className="w-full flex items-center space-x-3 hover:bg-slate-50 text-slate-500 hover:text-slate-900 px-4 py-2.5 rounded-lg transition-colors duration-200">
            <LogOut size={16} className="text-slate-400 flex-shrink-0" />
            <span className="font-medium text-xs whitespace-nowrap">
              Sign Out
            </span>
          </button>
        </div>

        {/* Toggle Button */}
        <button
          onClick={() => !isCollapsed && setIsProfileOpen(!isProfileOpen)}
          title={isCollapsed ? "Profile" : ""}
          className={`w-full flex items-center ${isCollapsed ? "justify-center px-0" : "space-x-3 px-4"
            } py-3 rounded-xl transition-all duration-200 border ${isProfileOpen && !isCollapsed
              ? "bg-slate-50 border-slate-200"
              : "border-transparent hover:bg-slate-50"
            }`}
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 p-[1px]">
            <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
              <User size={14} className="text-slate-700" />
            </div>
          </div>
          <div
            className={`text-left transition-all duration-200 overflow-hidden ${isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"
              }`}
          >
            <p className="text-sm text-slate-800 font-semibold leading-none">
              Hannah Mariam{" "}
            </p>
            <p className="text-[10px] text-slate-500 mt-1">Pro Account</p>
          </div>
        </button>
      </div>
    </div>
  );
};
