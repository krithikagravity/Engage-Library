import React from "react";
import { GravityData } from "../types";
import {
    Settings,
    User,
    Database,
    Eye,
    PieChart,
    Box,
    Cpu,
    Globe,
    Zap,
    Shield,
    Layers,
    GitCommit,
    Puzzle,
    Share2,
    Gift,
} from "lucide-react";
import { DraggableElement } from "./DraggableElement";

// --- Custom Component for Gravity Slide Layout ---
export const GravitySlide: React.FC<{
    data: GravityData;
    onUpdate?: (data: GravityData) => void;
}> = ({ data, onUpdate }) => {
    if (!data) return null;

    // Import DraggableElement here (inside file for now or ensure it is imported at top)
    // Since I cannot change top imports easily with this tool without rewriting file, 
    // I will assume I need to import it. 
    // Wait, I should add the import at the top first or in the same step if possible.
    // I will rewrite the whole component interaction to include DraggableElement logic.

    // Robust helper to strip ALL inline styles and spans from PPT-sourced HTML to prevent garbage leakage
    const cleanHtml = (html: string | undefined): string => {
        if (!html) return "";
        
        let sanitized = html;
        // 1. Remove all style attributes entirely (including malformed ones with spaces)
        sanitized = sanitized.replace(/style\s*=\s*["'][^"']*["']/gi, "");
        // 2. Remove all class attributes entirely
        sanitized = sanitized.replace(/class\s*=\s*["'][^"']*["']/gi, "");
        // 3. Remove opening/closing span tags
        sanitized = sanitized.replace(/<span[^>]*>/gi, "").replace(/<\/span>/gi, "");
        
        // 4. Force strip any residual CSS property names if they leak as raw text
        const propertiesToStrip = ["font-size", "font-family", "line-height", "color", "margin", "padding", "text-align", "background"];
        propertiesToStrip.forEach(p => {
            const regex = new RegExp(p + '\\s*:\\s*[^;"]+;?', 'gi');
            sanitized = sanitized.replace(regex, "");
        });

        // 5. Final cleanup of any stray fragments like "> or ;
        sanitized = sanitized.replace(/["']?>/g, "").replace(/;(?!\s*\w)/g, "").replace(/["']\s*>/g, "");
        
        return sanitized.trim();
    };

    // Helper for dynamic font scaling in Process layout
    const getProcessFontSize = (steps: any[]) => {
        // Strip HTML tags for an accurate plain-text measurement
        const plainText = steps.reduce((acc, step) => {
            const title = (step.title || "").replace(/<[^>]*>/g, "");
            const desc = (step.description || "").replace(/<[^>]*>/g, "");
            return acc + title.length + desc.length;
        }, 0);

        if (plainText > 1500) return { title: "text-xs", desc: "text-[11px]", lh: "leading-tight", gap: "4" };
        if (plainText > 1000) return { title: "text-sm", desc: "text-[13px]", lh: "leading-snug", gap: "6" };
        if (plainText > 500) return { title: "text-base", desc: "text-[16px]", lh: "leading-normal", gap: "8" };
        if (plainText > 250) return { title: "text-lg", desc: "text-[19px]", lh: "leading-relaxed", gap: "12" };
        
        // Ultra-high impact for sparse content
        return { title: "text-xl", desc: "text-[23px]", lh: "leading-loose", gap: "16" };
    };

    // Helper to dynamically split continuous text into balanced columns for templates
    const getDerivedColumns = (text: string, numCols: number) => {
        if (!text) return Array(numCols).fill({title: "", description: ""});
        const cleanTxt = cleanHtml(text);
        let segments = cleanTxt.split(/<br\s*\/?>|\n/).map(l => l.trim()).filter(l => l.length > 0);
        
        if (segments.length > 0 && segments.length < numCols) {
            const words = cleanTxt.replace(/<br\s*\/?>|\n/g, ' ').split(/\s+/).filter(w => w.length > 0);
            const chunkSize = Math.ceil(words.length / numCols);
            segments = [];
            for (let i = 0; i < numCols; i++) {
                segments.push(words.slice(i * chunkSize, (i + 1) * chunkSize).join(' '));
            }
        }
        
        const cols = [];
        const chunk = Math.ceil(segments.length / numCols);
        for (let i = 0; i < numCols; i++) {
            const block = segments.slice(i * chunk, (i + 1) * chunk);
            if (block.length > 0) cols.push({ title: block[0] || "", description: block.slice(1).join(' ') || "" });
            else cols.push({ title: "", description: "" });
        }
        return cols;
    };

    // Extract clean lines for safe mapping
    const extractLines = (text: string | undefined) => {
        if (!text) return [];
        return text.split(/<br\s*\/?>|\n/).map(l => l.trim()).filter(l => l.length > 0);
    };

    // Safely fill sidebar with only the first introductory line to ensure no bullet points are swallowed
    const getSidebarText = (text: string | undefined) => {
        const lines = extractLines(text);
        if (lines.length === 0) return "";
        return lines[0];
    };

    const getRemainingLines = (text: string | undefined) => {
        const lines = extractLines(text);
        if (lines.length <= 1) return [];
        return lines.slice(1);
    };

    const getMainColumns = (text: string | undefined, numCols: number) => {
        const remaining = getRemainingLines(text);
        if (remaining.length === 0) return Array(numCols).fill({title: "", description: ""});
        
        // Allocate ALL remaining lines to the columns so nothing is lost
        const colLines = remaining;
        
        const cols = [];
        let remainingItems = colLines.length;
        let remainingCols = numCols;
        let start = 0;
        
        for (let i = 0; i < numCols; i++) {
            const chunk = remainingItems > 0 ? Math.ceil(remainingItems / remainingCols) : 0;
            const block = colLines.slice(start, start + chunk);
            
            cols.push({ title: block[0] || "", description: block.slice(1).join('<br/>') || "" });
            
            start += chunk;
            remainingItems -= chunk;
            remainingCols--;
        }
        return cols;
    };

    // Helper to map icon strings to Lucide components
    const getIcon = (name: string | undefined) => {
        if (!name) return <Layers size={32} className="text-white" />;

        const iconMap: any = {
            settings: Settings,
            user: User,
            database: Database,
            eye: Eye,
            activity: PieChart,
            box: Box,
            cpu: Cpu,
            globe: Globe,
            zap: Zap,
            shield: Shield,
        };
        const IconComponent = iconMap[name.toLowerCase()] || Layers;
        return <IconComponent size={32} className="text-white" />;
    };

    const handleBlur = (field: keyof GravityData, value: string) => {
        if (onUpdate) {
            onUpdate({ ...data, [field]: value });
        }
    };

    const handlePillarBlur = (
        index: number,
        field: "title" | "description",
        value: string
    ) => {
        if (onUpdate) {
            const newPillars = [...(data.pillars || [])];
            newPillars[index] = { ...newPillars[index], [field]: value };
            onUpdate({ ...data, pillars: newPillars });
        }
    };

    const handleListBlur = (listName: keyof GravityData, index: number, value: string) => {
        if (!onUpdate) return;
        const currentList = [...(data[listName] as string[] || [])];
        currentList[index] = value;
        onUpdate({ ...data, [listName]: currentList });
    };

    const handleComplexListBlur = (listName: keyof GravityData, index: number, field: string, value: string) => {
        if (!onUpdate) return;
        const currentList = [...(data[listName] as any[] || [])];
        currentList[index] = { ...currentList[index], [field]: value };
        onUpdate({ ...data, [listName]: currentList });
    };

    const handleLabelBlur = (key: string, value: string) => {
        if (!onUpdate) return;
        const newLabels = { ...(data.customLabels || {}) };
        newLabels[key] = value;
        onUpdate({ ...data, customLabels: newLabels });
    };

    const isMapped = !!data.thesis || (data.pillars && data.pillars.length > 0) || (data.title && data.title !== "Title");

    const getLabel = (key: string, defaultLabel: string) => {
        if (data.customLabels && data.customLabels[key] !== undefined) {
             return data.customLabels[key];
        }
        return isMapped ? "" : defaultLabel;
    };

    const handleDragStop = (id: string, x: number, y: number) => {
        if (onUpdate) {
            const newPositions = { ...(data.positions || {}) };
            newPositions[id] = { x, y };
            onUpdate({ ...data, positions: newPositions });
        }
    };

    const getPosition = (id: string) => {
        return data.positions?.[id] || { x: 0, y: 0 };
    };

    // Helper component to conditionally wrap with Draggable
    // If onUpdate is present, we assume edit mode -> Draggable
    // If not, we assume preview -> Static (but we need to respect positions!)
    const Wrapper: React.FC<{ id: string, className?: string, children: React.ReactNode }> = ({ id, className, children }) => {
        const pos = getPosition(id);

        // If no update handler, render absolute with stored position (preview mode)
        if (!onUpdate) {
            return (
                <div
                    className={`relative ${className}`}
                    style={{
                        transform: `translate(${pos.x}px, ${pos.y}px)`,
                        // We need to ensure it doesn't break flow if it was originally static.
                        // But wait, 'react-draggable' uses transform: translate.
                        // So originally static elements will now be relative/absolute.
                        // To support "move elements", they likely need to pop out of document flow 
                        // OR we just use transform on top of their static position.
                        // Let's use transform on top of static position for now.
                    }}
                >
                    {children}
                </div>
            );
        }

        // Edit mode
        return (
            <DraggableElement id={id} position={pos} onStop={handleDragStop} className={className}>
                {children}
            </DraggableElement>
        );
    };

    // Note: DraggableElement import is missing in this file context, I need to add it.
    // I will use replace_file_content to add import and update component.

    const renderDTO = () => (
        <div className="bg-white flex w-full h-full font-sans overflow-hidden">
            {/* Sidebar */}
            <div className="w-1/3 bg-[#F8FAFC] border-r border-[#E2E8F0] p-8 flex flex-col">
                <h1 className="text-3xl font-bold text-[#48A3C6] mb-8">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        onBlur={e => handleBlur('sidebarTitle', e.currentTarget.innerHTML || "")} 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: data.sidebarTitle || data.title || (isMapped ? "" : "Digital Transformation Office") }}
                    />
                </h1>
                <h2 className="text-[#1E40AF] font-bold text-lg mb-2">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_problem', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('dto_lbl_problem', "Problem Addressed")}
                    </span>
                </h2>
                <p className="text-slate-900 font-bold mb-4">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: cleanHtml(data.problemAddressed || (isMapped ? getSidebarText(data.thesis) : data.thesis)) || "" }}
                    />
                </p>
                <p className="text-slate-600 text-sm mb-6 flex-1">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_subproblem', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('dto_lbl_subproblem', "The Digital Transformation Office helps them quickly identify gaps and align their operations.")}
                    </span>
                </p>
                
                <h2 className="text-[#1E40AF] font-bold text-lg mb-1">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_buyer', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('dto_lbl_buyer', "Key Buyer:")}
                    </span>
                </h2>
                <p className="text-[#48A3C6] mb-6">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        onBlur={e => handleBlur('keyBuyer', e.currentTarget.innerHTML || "")} 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: data.keyBuyer || (isMapped ? "" : "Executive Transformation Leader") }}
                    ></span>
                </p>

                <h2 className="text-[#1E40AF] font-bold text-lg mb-4">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_questions', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('dto_lbl_questions', "Qualifying Questions")}
                    </span>
                </h2>
                <ul className="list-disc pl-5 text-sm text-slate-700 space-y-3">
                    {((Array.isArray(data.qualifyingQuestions) && data.qualifyingQuestions.length > 0 ? data.qualifyingQuestions : null) || (isMapped ? ["", "", "", ""] : ["Is the client under pressure to deliver measurable improvements in efficiency or effectiveness across the business?", "Is the client required to lead a multi-year transformation to modernise the operating model?", "Are capability, service, or transformation registers currently fragmented or manually managed?", "Does the client need visibility into progress across multiple business units or strategic priorities?"])).map((q, i) => (
                        q ? (
                        <li key={i}>
                            <span 
                                contentEditable={!!onUpdate} 
                                suppressContentEditableWarning 
                                onBlur={e => handleListBlur('qualifyingQuestions', i, e.currentTarget.innerHTML || "")} 
                                className="outline-none block min-h-[1em]"
                                dangerouslySetInnerHTML={{ __html: q || "" }}
                            ></span>
                        </li>
                        ) : null
                    ))}
                </ul>
            </div>
            {/* Main Content */}
            <div className="w-2/3 flex flex-col items-center">
                 {/* Header */}
                 <div className="w-full bg-[#1E3A8A] text-white p-6 flex justify-between items-center h-24">
                     <h2 className="text-2xl font-bold max-w-xl flex items-center">
                         <span 
                             contentEditable={!!onUpdate} 
                             suppressContentEditableWarning 
                             onBlur={e => handleBlur('mainHeader', e.currentTarget.innerHTML || "")} 
                             className="outline-none block min-h-[1em]"
                             dangerouslySetInnerHTML={{ __html: cleanHtml(data.mainHeader || data.title) || "" }}
                         />
                     </h2>
                     <div className="text-4xl font-extrabold tracking-tight text-white">gravity<span className="text-white">one</span></div>
                 </div>
                 <div className="p-8 flex-1 w-full flex flex-col">
                     <p className="text-[#1E40AF] text-center text-lg mb-6">
                         <span 
                            contentEditable={!!onUpdate} 
                            suppressContentEditableWarning 
                            onBlur={e => handleBlur('subHeader', e.currentTarget.innerHTML || "")} 
                            className="outline-none block min-h-[1em]"
                            dangerouslySetInnerHTML={{ __html: data.subHeader || data.summary || (isMapped ? "" : "Visualise, assess, and align the business to deliver transformation, evaluate capability maturity and shape the future operating model with confidence.") }}
                         ></span>
                     </p>
                     
                     {/* Images Row */}
                     <div className="flex justify-between gap-4 mb-6">
                         {((Array.isArray(data.images) ? data.images : null) || [
                             { title: isMapped ? "" : "Strategic Transformation Roadmaps", url: "" },
                             { title: isMapped ? "" : "Interactive Transformation Agendas", url: "" },
                             { title: isMapped ? "" : "Digital Operating Models", url: "" }
                         ]).map((imgItem: any, i: number) => {
                             // Handle legacy string data
                             const image = typeof imgItem === 'string' ? { title: imgItem, url: "" } : imgItem;
                             return (
                             <div key={i} className="flex-1 flex flex-col items-center relative group">
                                 <h3 className="text-[#48A3C6] font-medium text-sm mb-2 text-center h-10 w-full flex items-center justify-center">
                                     <span 
                                         contentEditable={!!onUpdate} 
                                         suppressContentEditableWarning 
                                         onBlur={e => handleComplexListBlur('images', i, 'title', e.currentTarget.innerHTML || "")} 
                                         className="outline-none block min-h-[1em]"
                                         dangerouslySetInnerHTML={{ __html: image.title || "" }}
                                     ></span>
                                 </h3>
                                 <div className="w-full h-32 bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-400 relative overflow-hidden">
                                     {image?.src 
                                       ? <img src={image.src} style={{width:"100%", height:"100%", objectFit:"cover"}} />
                                       : <span>Click to upload image</span>
                                     }
                                     {/* Hidden file input layered on top */}
                                     {onUpdate && (
                                         <input 
                                             type="file" 
                                             accept="image/*"
                                             className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                             onChange={(e) => {
                                                 const file = e.target.files?.[0];
                                                 if (file) {
                                                     const reader = new FileReader();
                                                     reader.onload = (event) => {
                                                         const newUrl = event.target?.result as string;
                                                         
                                                         // Normalize current images array in case they are strings
                                                         const currentImages = ((Array.isArray(data.images) ? data.images : null) || [
                                                             { title: "Strategic Transformation Roadmaps", url: "" },
                                                             { title: "Interactive Transformation Agendas", url: "" },
                                                             { title: "Digital Operating Models", url: "" }
                                                         ]).map((item: any) => typeof item === 'string' ? { title: item, url: "" } : item);
                                                         
                                                         const newImages = [...currentImages];
                                                         newImages[i] = { ...newImages[i], url: newUrl };
                                                         onUpdate({ ...data, images: newImages });
                                                     };
                                                     reader.readAsDataURL(file);
                                                 }
                                             }}
                                         />
                                     )}
                                 </div>
                             </div>
                         )})}
                     </div>

                     {/* Bottom boxes */}
                     <div className="flex gap-4 flex-1">
                         <div className="w-2/3 bg-[#F1F5F9] border border-slate-200 flex flex-col">
                             <div className="bg-[#E2E8F0] text-[#1E40AF] font-bold text-center py-2">
                                 <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_value', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                     {getLabel('dto_lbl_value', "Value To Customer")}
                                 </span>
                             </div>
                             <div className="p-4">
                                 <p className="text-[#1E40AF] mb-4">
                                     <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_value_sub', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                         {getLabel('dto_lbl_value_sub', "When executives use this product they are able to...")}
                                     </span>
                                 </p>
                                 <div className="flex gap-4">
                                     {((Array.isArray(data.valueToCustomer) && data.valueToCustomer.length > 0 ? data.valueToCustomer : null) || (isMapped && data.thesis ? getMainColumns(data.thesis, 4) : null) || (Array.isArray(data.pillars) && data.pillars.length > 0 ? data.pillars : null) || (isMapped ? [{title: "", description: ""}, {title: "", description: ""}, {title: "", description: ""}, {title: "", description: ""}] : [
                                         {title: "Communicate the transformation journey with clarity", description: "using Strategic Transformation Roadmaps to express the current state..."},
                                         {title: "Design and manage the Target-State Operating Model", description: "with Digital Operating Models that map enterprise capabilities..."},
                                         {title: "Track transformation progress toward readiness goals", description: "through Interactive Transformation Agendas..."}
                                     ])).slice(0, 4).map((v: any, i: number) => (
                                         <div key={i} className="flex-1">
                                             <h4 className="font-bold text-sm mb-2">
                                                 <span 
                                                     contentEditable={!!onUpdate} 
                                                     suppressContentEditableWarning 
                                                     onBlur={e => handleComplexListBlur('valueToCustomer', i, 'title', e.currentTarget.innerHTML || "")} 
                                                     className="outline-none block min-h-[1em]"
                                                     dangerouslySetInnerHTML={{ __html: cleanHtml(v?.title) || "" }}
                                                 ></span>
                                             </h4>
                                             <p className="text-xs text-slate-600">
                                                 <span 
                                                     contentEditable={!!onUpdate} 
                                                     suppressContentEditableWarning 
                                                     onBlur={e => handleComplexListBlur('valueToCustomer', i, 'description', e.currentTarget.innerHTML || "")} 
                                                     className="outline-none block min-h-[1em]"
                                                     dangerouslySetInnerHTML={{ __html: cleanHtml(v?.description) || "" }}
                                                 ></span>
                                             </p>
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         </div>
                         <div className="w-1/3 bg-[#F1F5F9] border border-slate-200 flex flex-col">
                             <div className="bg-[#E2E8F0] text-[#1E40AF] font-bold text-center py-2">
                                 <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('dto_lbl_usecases', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                     {getLabel('dto_lbl_usecases', "Key Use Cases")}
                                 </span>
                             </div>
                             <ul className="list-disc pl-8 pr-4 py-4 text-xs space-y-4 text-slate-800">
                                 {((Array.isArray(data.keyUseCases) && data.keyUseCases.length > 0 ? data.keyUseCases : null) || (isMapped && data.thesis ? (typeof data.thesis === 'string' ? data.thesis.split('. ').slice(1, 4) : []) : null) || (Array.isArray(data.pillars) && data.pillars.length > 0 ? data.pillars.filter((p: any) => !!p.title).map((p: any) => p.title) : null) || (isMapped ? [] : ["Capability maturity assessments", "Target Operating Model Design", "Transformation (Optimisation) Planning", "Executive reporting on transformation status and gaps"])).slice(0, 4).map((uc: any, i: number) => (
                                     uc ? (
                                     <li key={i}>
                                         <span 
                                             contentEditable={!!onUpdate} 
                                             suppressContentEditableWarning 
                                             onBlur={e => handleListBlur('keyUseCases', i, e.currentTarget.innerHTML || "")} 
                                             className="outline-none block min-h-[1em]"
                                             dangerouslySetInnerHTML={{ __html: cleanHtml(uc) || "" }}
                                         ></span>
                                     </li>
                                     ) : null
                                 ))}
                             </ul>
                         </div>
                     </div>
                 </div>
            </div>
        </div>
    );

    const renderLandscape = () => (
        <div className="bg-white flex w-full h-full font-sans overflow-hidden">
            {/* Sidebar */}
            <div className="w-1/4 bg-[#FEF9C3] border-r border-[#E2E8F0] p-8 flex flex-col">
                <h1 className="text-3xl font-bold text-[#A16207] mb-8">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        onBlur={e => handleBlur('sidebarTitle', e.currentTarget.innerHTML || "")} 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: data.sidebarTitle || data.title || (isMapped ? "" : "Strategic Landscape Visualisation") }}
                    />
                </h1>
                <h2 className="text-[#1E40AF] font-bold text-lg mb-2">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_problem', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('land_lbl_problem', "Problem Address")}
                    </span>
                </h2>
                <p className="text-slate-900 mb-6 flex-1">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: cleanHtml(data.problemAddressed || (isMapped ? getSidebarText(data.thesis) : data.thesis)) || "" }}
                    />
                </p>
                
                <h2 className="text-[#1E40AF] font-bold text-lg mb-1">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_buyer', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('land_lbl_buyer', "Key Buyer:")}
                    </span>
                </h2>
                <p className="text-[#1E40AF] mb-6">
                    <span 
                        contentEditable={!!onUpdate} 
                        suppressContentEditableWarning 
                        onBlur={e => handleBlur('keyBuyer', e.currentTarget.innerHTML || "")} 
                        className="outline-none block min-h-[1em]"
                        dangerouslySetInnerHTML={{ __html: data.keyBuyer || (isMapped ? "" : "Executive Business Leader") }}
                    ></span>
                </p>

                <h2 className="text-[#1E40AF] font-bold text-lg mb-4">
                    <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_questions', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                        {getLabel('land_lbl_questions', "Qualifying Questions")}
                    </span>
                </h2>
                <ul className="list-disc pl-5 text-sm text-slate-700 space-y-3">
                    {((data.qualifyingQuestions && data.qualifyingQuestions.length > 0 ? data.qualifyingQuestions : null) || (isMapped ? ["", "", "", ""] : ["Does the client occupy a position of executive leadership and have decision-making power?", "Is the client required to orchestrate a strategic outcome across a large stakeholder group?", "Is the communication problem 'time-sensitive'?", "Does the client have authority over discretionary budgets of $80K?"])).map((q, i) => (
                        q ? (
                        <li key={i}>
                            <span 
                                contentEditable={!!onUpdate} 
                                suppressContentEditableWarning 
                                onBlur={e => handleListBlur('qualifyingQuestions', i, e.currentTarget.innerHTML || "")} 
                                className="outline-none block min-h-[1em]"
                                dangerouslySetInnerHTML={{ __html: q || "" }}
                            ></span>
                        </li>
                        ) : null
                    ))}
                </ul>
            </div>
            {/* Main Content */}
            <div className="w-3/4 flex flex-col items-center">
                 {/* Header */}
                 <div className="w-full bg-[#1E3A8A] text-white p-6 flex justify-between items-center h-24">
                     <h2 className="text-2xl font-bold flex items-center">
                         <span 
                             contentEditable={!!onUpdate} 
                             suppressContentEditableWarning 
                             onBlur={e => handleBlur('mainHeader', e.currentTarget.innerHTML || "")} 
                             className="outline-none block min-h-[1em]"
                             dangerouslySetInnerHTML={{ __html: cleanHtml(data.mainHeader || data.title) || "" }}
                         />
                     </h2>
                     <div className="text-4xl font-extrabold tracking-tight text-white">gravity<span className="text-white">one</span></div>
                 </div>
                 <div className="p-8 flex-1 w-full flex flex-col">
                     <p className="text-[#1E40AF] text-center text-lg mb-6">
                         <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleBlur('subHeader', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                             {data.subHeader || data.summary || (isMapped ? "" : "Simple Strategic Communication visualisations for Executive Stakeholders")}
                         </span>
                     </p>
                     
                     {/* Layered Images */}
                     <div className="relative w-full h-64 mb-6 bg-slate-100 flex items-center justify-center border border-slate-300 overflow-hidden">
                         {(() => {
                           const image = (data.images && typeof data.images[0] !== 'string') ? (data.images[0] as any) : null;
                           return image?.src 
                             ? <img src={image.src} style={{width:"100%", height:"100%", objectFit:"cover"}} />
                             : <span>Click to upload image</span>;
                         })()}
                         {onUpdate && (
                             <input 
                                 type="file" 
                                 accept="image/*"
                                 className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                 onChange={(e) => {
                                     const file = e.target.files?.[0];
                                     if (file) {
                                         const reader = new FileReader();
                                         reader.onload = (event) => {
                                             const newUrl = event.target?.result as string;
                                             const currentImages = ((Array.isArray(data.images) ? data.images : null) || [{title: 'Landscape', url: ''}]).map((item: any) => typeof item === 'string' ? { title: item, url: "" } : item);
                                             const newImages = [...currentImages];
                                             newImages[0] = { ...newImages[0], url: newUrl };
                                             onUpdate({ ...data, images: newImages });
                                         };
                                         reader.readAsDataURL(file);
                                     }
                                 }}
                             />
                         )}
                     </div>

                     {/* Bottom boxes */}
                     <div className="flex gap-4 flex-1">
                         <div className="w-2/3 bg-[#F1F5F9] border border-slate-200 flex flex-col">
                             <div className="bg-[#E2E8F0] text-[#1E40AF] font-bold text-center py-2">
                                 <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_value', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                     {getLabel('land_lbl_value', "Value To Customer")}
                                 </span>
                             </div>
                             <div className="p-4">
                                 <p className="text-[#1E40AF] mb-4">
                                     <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_value_sub', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                         {getLabel('land_lbl_value_sub', "When executives use this product they are able to...")}
                                     </span>
                                 </p>
                                 <div className="flex gap-4">
                                     {((Array.isArray(data.valueToCustomer) && data.valueToCustomer.length > 0 ? data.valueToCustomer : null) || (isMapped && data.thesis ? getMainColumns(data.thesis, 3) : null) || (Array.isArray(data.pillars) && data.pillars.length > 0 ? data.pillars : null) || (isMapped ? [{title: "", description: ""}, {title: "", description: ""}, {title: "", description: ""}] : [
                                         {title: "Align Leadership Around a Unified Strategic Narrative", description: "Establish a shared understanding..."},
                                         {title: "Accelerate Strategic Decision-Making", description: "Reduce ambiguity and confusion..."},
                                         {title: "Drive Stakeholder Engagement and Buy-In", description: "Help executive leaders communicate compelling 'why-now' narratives..."}
                                     ])).slice(0, 3).map((v: any, i: number) => (
                                         <div key={i} className="flex-1">
                                             <h4 className="font-bold text-sm mb-2">
                                                 <span 
                                                     contentEditable={!!onUpdate} 
                                                     suppressContentEditableWarning 
                                                     onBlur={e => handleComplexListBlur('valueToCustomer', i, 'title', e.currentTarget.innerHTML || "")} 
                                                     className="outline-none block min-h-[1em]"
                                                     dangerouslySetInnerHTML={{ __html: cleanHtml(v?.title) || "" }}
                                                 ></span>
                                             </h4>
                                             <p className="text-xs text-slate-600">
                                                 <span 
                                                     contentEditable={!!onUpdate} 
                                                     suppressContentEditableWarning 
                                                     onBlur={e => handleComplexListBlur('valueToCustomer', i, 'description', e.currentTarget.innerHTML || "")} 
                                                     className="outline-none block min-h-[1em]"
                                                     dangerouslySetInnerHTML={{ __html: cleanHtml(v?.description) || "" }}
                                                 ></span>
                                             </p>
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         </div>
                         <div className="w-1/3 bg-[#F1F5F9] border border-slate-200 flex flex-col">
                             <div className="bg-[#E2E8F0] text-[#1E40AF] font-bold text-center py-2">
                                 <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('land_lbl_usecases', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                     {getLabel('land_lbl_usecases', "Key Use Cases")}
                                 </span>
                             </div>
                             <ul className="list-disc pl-8 pr-4 py-4 text-xs space-y-4 text-slate-800">
                                 {((Array.isArray(data.keyUseCases) && data.keyUseCases.length > 0 ? data.keyUseCases : null) || (isMapped && data.thesis ? (typeof data.thesis === 'string' ? data.thesis.split('. ').slice(1, 4) : []) : null) || (Array.isArray(data.pillars) && data.pillars.length > 0 ? data.pillars.filter((p: any) => !!p.title).map((p: any) => p.title) : null) || (isMapped ? [] : ["Strategic Business Ecosystem Visualisation for industry domains", "Visualise Comprehensive Strategy Documents (static & interactive)", "Strategic Business Operating Models", "Strategic implementation Roadmaps"])).slice(0, 4).map((uc: any, i: number) => (
                                     uc ? (
                                     <li key={i}>
                                         <span 
                                             contentEditable={!!onUpdate} 
                                             suppressContentEditableWarning 
                                             onBlur={e => handleListBlur('keyUseCases', i, e.currentTarget.innerHTML || "")} 
                                             className="outline-none block min-h-[1em]"
                                             dangerouslySetInnerHTML={{ __html: cleanHtml(uc) || "" }}
                                         ></span>
                                     </li>
                                     ) : null
                                 ))}
                             </ul>
                         </div>
                     </div>
                 </div>
            </div>
        </div>
    );

    const renderProcess = () => {
        // Dynamically route fallback text into structural columns if hot-swapped
        let derivedSteps: any = (Array.isArray(data.processSteps) && data.processSteps.length > 0) ? data.processSteps : null;
        let hideThesis = false;
        let processIntroText = data.subHeader || data.thesis || "";

        // Force split from thesis/subHeader if we don't have explicit processSteps
        if (!derivedSteps && processIntroText) {
            if (isMapped) {
                // Perfect line-by-line PPT mapping (exactly like DTO)
                processIntroText = getSidebarText(data.thesis);
                derivedSteps = getMainColumns(data.thesis, 4);
                // We do NOT hide the thesis because processIntroText now correctly holds only the first few sentences
            } else {
                // Legacy word-split logic for manually typed continuous paragraphs
                const rawText = processIntroText;
                const textToSplit = cleanHtml(rawText);
                let totalSegments = textToSplit.split(/<br\s*\/?>|\n/).map(l => l.trim()).filter(l => l.length > 0);
                
                if (totalSegments.length > 0 && totalSegments.length < 4) {
                     const words = textToSplit.replace(/<br\s*\/?>|\n/g, ' ').split(/\s+/).filter(w => w.length > 0);
                     if (words.length > 15) {
                        const chunkSize = Math.ceil(words.length / 4);
                        totalSegments = [];
                        for (let i = 0; i < 4; i++) {
                            totalSegments.push(words.slice(i * chunkSize, (i + 1) * chunkSize).join(' '));
                        }
                     }
                }
                
                if (totalSegments.length > 0) {
                    derivedSteps = [];
                    let remainingItems = totalSegments.length;
                    let remainingCols = 4;
                    let start = 0;
                    for (let i = 0; i < 4; i++) {
                         const chunk = remainingItems > 0 ? Math.ceil(remainingItems / remainingCols) : 0;
                         const block = totalSegments.slice(start, start + chunk);
                         if (block.length === 1 && totalSegments.length === 4) {
                             derivedSteps.push({ title: "", description: block[0] });
                         } else if (block.length > 0) {
                             derivedSteps.push({ title: block[0], description: block.slice(1).join('<br/>') });
                         } else {
                             derivedSteps.push({ title: "", description: "" });
                         }
                         start += chunk;
                         remainingItems -= chunk;
                         remainingCols--;
                    }
                }
                
                if (derivedSteps && derivedSteps.length > 0) {
                    hideThesis = true;
                }
            }
        }
        
        // If we have columns (either pre-existing or derived), hide the main thesis box to avoid redundancy
        if (derivedSteps && derivedSteps.length > 0) {
            hideThesis = true;
        }

        const stepsToRender = derivedSteps || [
             {title: "Baseline & assess current state", description: "Map existing processes and systems.\n\nIdentify pain points: manual reporting...\n\nEstablish baseline metrics reporting time, adoption..."},
             {title: "Create the change plan", description: "Define a clear change vision...\n\nIdentify impacted stakeholders...\n\nOutline communication, training, and support activities..."},
             {title: "Engage & enable key stakeholders", description: "Communicate vision, benefits...\n\nDeliver tailored training, user guides...\n\nAppoint change champions to drive engagement..."},
             {title: "Track & realize benefits", description: "Monitor adoption and usage across all levels.\n\nMeasure improvements in reporting, data quality...\n\nUse feedback and success stories for continuous improvement..."}
        ];

        const fontSizes = getProcessFontSize(stepsToRender);

        return (
        <div className="bg-white flex flex-col w-full h-full font-sans overflow-hidden">
            {/* Header */}
            <div className="w-full bg-gradient-to-r from-[#170B49] to-[#2610A3] text-white p-6 flex justify-between items-start h-24 relative">
                <div className="flex items-start gap-4 z-10">
                    <div className="w-1 h-12 bg-[#FBBF24]"></div>
                    <div>
                        <p className="text-slate-300">
                            <span contentEditable={!!onUpdate} suppressContentEditableWarning onBlur={e => handleLabelBlur('process_lbl_approach', e.currentTarget.textContent || "")} className="outline-none block min-h-[1em]">
                                {getLabel('process_lbl_approach', 'Our approach')}
                            </span>
                        </p>
                        <h1 className="text-3xl font-bold flex items-center">
                            <span 
                                contentEditable={!!onUpdate} 
                                suppressContentEditableWarning 
                                onBlur={e => handleBlur('mainHeader', e.currentTarget.innerHTML || "")} 
                                className="outline-none block min-h-[1em]"
                                dangerouslySetInnerHTML={{ __html: data.mainHeader || data.title || (isMapped ? "" : "4. Change & Benefits Realization") }}
                            />
                        </h1>
                    </div>
                </div>
                <div className="text-4xl font-extrabold tracking-tight z-10 w-48 text-right text-white">gravity<span className="text-white">one</span></div>
                {/* Visual gradient overlay to match image */}
                <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-[#3B1DD8] to-transparent pointer-events-none opacity-50"></div>
            </div>
            
            {/* Main Text Content Fallback */}
            {!hideThesis && processIntroText && (
                <div className="w-full px-16 pt-5 pb-2 text-center flex-shrink-0">
                    <p className="text-[#1E40AF] text-[15px] max-w-4xl mx-auto whitespace-pre-line leading-relaxed relative z-10 bg-white/40 backdrop-blur-sm px-4 py-2 mb-2 rounded-xl shadow-sm border border-blue-50/50">
                        <span 
                            contentEditable={!!onUpdate} 
                            suppressContentEditableWarning 
                            onBlur={e => handleBlur('subHeader', e.currentTarget.innerHTML || "")} 
                            className="outline-none block min-h-[1em]"
                            dangerouslySetInnerHTML={{ __html: processIntroText }}
                        />
                    </p>
                </div>
            )}

            {/* Process Steps */}
            <div className={`flex-1 flex flex-col justify-start pt-${fontSizes.gap} px-16 relative overflow-visible`}>
                 {/* Segmented connect arrow traversing the icons */}
                 <div className="absolute top-[68px] left-16 right-16 h-3.5 flex z-0 overflow-hidden">
                     <div className="flex-1 h-full bg-[#BCCBE5] opacity-80"></div>
                     <div className="flex-1 h-full bg-[#91ADDB] opacity-85"></div>
                     <div className="flex-1 h-full bg-[#6489C9] opacity-90"></div>
                     <div className="flex-1 h-full bg-[#1E3A8A] relative">
                         {/* Arrow Head */}
                         <div className="absolute -right-3 top-[-3.5px] w-0 h-0 border-t-[10px] border-t-transparent border-l-[20px] border-l-[#1E3A8A] border-b-[10px] border-b-transparent"></div>
                     </div>
                 </div>

                 <div className="flex justify-between relative z-10 mb-2 pt-2">
                     {stepsToRender.map((step: any, i: number) => {
                         const IconObj = [GitCommit, Puzzle, Share2, Gift][i % 4];
                         const colors = ['#C8D4F0', '#9AAEE2', '#6B8BDF', '#1E3A8A'];
                         const color = colors[i % 4];
                         
                         return (
                         <div key={i} className="flex-1 px-3 flex flex-col relative h-full">
                             {/* Clean Thick Border Rings Overlapping Arrow */}
                             <div 
                                className="w-[110px] h-[110px] rounded-full border-[12px] mx-auto mb-2 flex items-center justify-center relative z-20 shadow-sm" 
                                style={{ borderColor: color, color: color, backgroundColor: 'white' }}
                             >
                                 <IconObj size={36} strokeWidth={1.5} className="z-10" />
                             </div>
                             
                             {/* Restored Grey Text Box under circles */}
                             <div className="bg-[#F8FAFC] w-full flex-1 flex flex-col items-center justify-center pt-8 px-5 pb-5 -mt-10 rounded-xl border border-slate-200/60 shadow-sm relative z-10 text-center">
                                 <h3 className={`${fontSizes.title} font-bold text-[#1E3A8A] mb-2 whitespace-pre-line leading-tight w-full`}>
                                     <span 
                                         contentEditable={!!onUpdate} 
                                         suppressContentEditableWarning 
                                         onBlur={e => handleComplexListBlur('processSteps', i, 'title', e.currentTarget.innerHTML || "")} 
                                         className="outline-none block min-h-[1em]"
                                         dangerouslySetInnerHTML={{ __html: cleanHtml(step.title) }}
                                     />
                                 </h3>
                                 <p className={`${fontSizes.desc} text-slate-600 whitespace-pre-line ${fontSizes.lh}`}>
                                     <span 
                                         contentEditable={!!onUpdate} 
                                         suppressContentEditableWarning 
                                         onBlur={e => handleComplexListBlur('processSteps', i, 'description', e.currentTarget.innerHTML || "")} 
                                         className="outline-none block min-h-[1em]"
                                         dangerouslySetInnerHTML={{ __html: cleanHtml(step.description) }}
                                     />
                                 </p>
                             </div>
                         </div>
                     )})}
                 </div>
            </div>
        </div>
        );
    };

    if (data.layout === 'dto') return renderDTO();
    if (data.layout === 'landscape') return renderLandscape();
    if (data.layout === 'process') return renderProcess();

    return (
        <div className="bg-white relative overflow-hidden flex flex-col w-full h-full border border-slate-100">
            {/* PADDING CONTAINER */}
            <div className="p-16 h-full flex flex-col relative z-10 font-sans">
                {/* Decorative Background Curves (Right Top) - Only show if NOT in clean mode (i.e. has pillars) */}
                {data.pillars && data.pillars.length > 0 && (
                    <>
                        <div className="absolute top-[-10%] right-[-5%] w-[800px] h-[800px] rounded-full border border-slate-200/50 pointer-events-none"></div>
                        <div className="absolute top-[-7%] right-[-3%] w-[780px] h-[780px] rounded-full border border-slate-200/50 pointer-events-none"></div>
                        <div className="absolute top-[-4%] right-[-1%] w-[760px] h-[760px] rounded-full border border-slate-200/50 pointer-events-none"></div>

                        {/* Decorative Background Curves (Bottom Left) */}
                        <div className="absolute bottom-[-35%] left-[-15%] w-[1200px] h-[600px] border-t border-slate-200/60 rounded-[100%] pointer-events-none -rotate-6"></div>
                        <div className="absolute bottom-[-32%] left-[-15%] w-[1200px] h-[600px] border-t border-slate-200/60 rounded-[100%] pointer-events-none -rotate-6"></div>
                        <div className="absolute bottom-[-29%] left-[-15%] w-[1200px] h-[600px] border-t border-slate-200/60 rounded-[100%] pointer-events-none -rotate-6"></div>
                        <div className="absolute bottom-[-26%] left-[-15%] w-[1200px] h-[600px] border-t border-slate-200/60 rounded-[100%] pointer-events-none -rotate-6"></div>
                        <div className="absolute bottom-[-23%] left-[-15%] w-[1200px] h-[600px] border-t border-slate-200/60 rounded-[100%] pointer-events-none -rotate-6"></div>
                    </>
                )}

                {/* Header */}
                <div className="flex justify-between items-start mb-14 relative z-10 pointer-events-none">
                    <div className="flex items-center gap-6 pointer-events-auto">
                        <Wrapper id="brand-bar">
                            <div className="w-3.5 h-16 bg-[#2655CE] rounded-sm"></div>
                        </Wrapper>

                        <Wrapper id="main-heading">
                            {/* Conditional Rendering: If we use specific "Is/Isn't" structure vs Simple Title */}
                            {data.antithesis ? (
                                <h1 className="text-[44px] font-bold text-slate-900 tracking-tight leading-tight flex items-baseline gap-2">
                                    What{" "}
                                    <span className="relative inline-block mx-1">
                                        <span
                                            className="relative z-10 outline-none"
                                            contentEditable={!!onUpdate}
                                            suppressContentEditableWarning
                                            onBlur={(e) =>
                                                handleBlur("title", e.currentTarget.textContent || "")
                                            }
                                        >
                                            {data.title}
                                        </span>
                                        <svg
                                            className="absolute w-full h-3 bottom-0 left-0 text-red-400 opacity-90"
                                            viewBox="0 0 100 10"
                                            preserveAspectRatio="none"
                                        >
                                            <path
                                                d="M0 5 Q 5 10 10 5 T 20 5 T 30 5 T 40 5 T 50 5 T 60 5 T 70 5 T 80 5 T 90 5 T 100 5"
                                                stroke="currentColor"
                                                strokeWidth="2.5"
                                                fill="none"
                                            />
                                        </svg>
                                    </span>{" "}
                                    <span
                                        contentEditable={!!onUpdate}
                                        suppressContentEditableWarning
                                        onBlur={(e) =>
                                            handleBlur("isHeading", e.currentTarget.innerHTML || "")
                                        }
                                        className="outline-none inline-block min-w-[20px]"
                                        dangerouslySetInnerHTML={{ __html: data.isHeading || "" }}
                                    ></span>{" "}
                                    — and{" "}
                                    <span className="relative inline-block mx-1">
                                        <span
                                            contentEditable={!!onUpdate}
                                            suppressContentEditableWarning
                                            onBlur={(e) =>
                                                handleBlur("isntHeading", e.currentTarget.innerHTML || "")
                                            }
                                            className="outline-none inline-block min-w-[20px]"
                                            dangerouslySetInnerHTML={{ __html: data.isntHeading || "" }}
                                        ></span>
                                        <div className="absolute w-full h-[2px] bottom-1 left-0 border-b-2 border-slate-900 border-dashed"></div>
                                    </span>
                                </h1>
                            ) : (
                                <h1
                                    className="text-[56px] font-bold text-slate-900 tracking-tight leading-tight outline-none"
                                    contentEditable={!!onUpdate}
                                    suppressContentEditableWarning
                                    onBlur={(e) =>
                                        handleBlur("title", e.currentTarget.innerHTML || "")
                                    }
                                    dangerouslySetInnerHTML={{ __html: data.title }}
                                >
                                </h1>
                            )}
                        </Wrapper>
                    </div>
                    <Wrapper id="logo-right" className="pointer-events-auto mt-1 text-right">
                        {/* Wrapped div to ensure block context for transform */}
                        <div>
                            <h2 className="text-4xl font-extrabold tracking-tight text-slate-900">
                                gravity<span className="text-[#2655CE]">one</span>
                            </h2>
                        </div>
                    </Wrapper>
                </div>

                {/* Intro Text / Main Body */}
                <Wrapper id="intro-text" className="mb-20 relative z-10 max-w-5xl pl-10 space-y-4 pointer-events-auto">
                    <div>
                        {data.antithesis ? (
                            <>
                                <p className="text-[26px] text-slate-800 font-light">
                                    <span className="relative inline-block font-normal">
                                        <span
                                            className="relative z-10 outline-none block min-h-[1em]"
                                            contentEditable={!!onUpdate}
                                            suppressContentEditableWarning
                                            onBlur={(e) =>
                                                handleBlur("title", e.currentTarget.innerHTML || "")
                                            }
                                            dangerouslySetInnerHTML={{ __html: data.title || "" }}
                                        ></span>
                                        <svg
                                            className="absolute w-full h-2 bottom-0 left-0 text-red-400"
                                            viewBox="0 0 100 10"
                                            preserveAspectRatio="none"
                                        >
                                            <path
                                                d="M0 5 Q 5 10 10 5 T 20 5 T 30 5 T 40 5 T 50 5 T 60 5 T 70 5 T 80 5 T 90 5 T 100 5"
                                                stroke="currentColor"
                                                strokeWidth="2"
                                                fill="none"
                                            />
                                        </svg>
                                    </span>{" "}
                                    isn't{" "}
                                    <span
                                        contentEditable={!!onUpdate}
                                        suppressContentEditableWarning
                                        onBlur={(e) =>
                                            handleBlur("antithesis", e.currentTarget.innerHTML || "")
                                        }
                                        className="outline-none inline-block min-w-[20px]"
                                        dangerouslySetInnerHTML={{ __html: data.antithesis || "" }}
                                    ></span>
                                    .
                                </p>
                                <p className="text-[26px] text-slate-900 font-normal">
                                    <span className="relative inline-block border-b-2 border-slate-800 border-dashed pb-0.5">
                                        It's
                                    </span>{" "}
                                    <span
                                        contentEditable={!!onUpdate}
                                        suppressContentEditableWarning
                                        onBlur={(e) =>
                                            handleBlur("thesis", e.currentTarget.innerHTML || "")
                                        }
                                        className="outline-none inline-block min-w-[20px]"
                                        dangerouslySetInnerHTML={{ __html: data.thesis || "" }}
                                    ></span>
                                </p>
                            </>
                        ) : (
                            <p
                                className="text-[26px] text-slate-900 font-normal leading-relaxed whitespace-pre-wrap outline-none"
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("thesis", e.currentTarget.innerHTML || "")
                                }
                                dangerouslySetInnerHTML={{ __html: data.thesis || "" }}
                            >
                            </p>
                        )}
                    </div>
                </Wrapper>

                {/* Pillars Grid - Only render if pillars exist and this isn't a mapped PPT slide */}
                {Array.isArray(data.pillars) && data.pillars.length > 0 && !isMapped && (
                    <div className="grid grid-cols-4 gap-8 mb-auto relative z-10 px-6 pointer-events-none">
                        {data.pillars.map((pillar, index) => (
                            <Wrapper key={index} id={`pillar-${index}`} className="pointer-events-auto">
                                <div
                                    className="flex flex-col items-center text-center group"
                                >
                                    {/* 3D Illustration Placeholder */}
                                    <div className="relative w-48 h-40 mb-2 transform transition-transform duration-500 group-hover:-translate-y-2">
                                        {/* Platform Base (Isometric) */}
                                        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-32 h-20 bg-[#BFDBFE] rotate-45 skew-x-12 rounded-xl z-10"></div>
                                        <div className="absolute bottom-4 left-[24%] w-16 h-20 bg-[#93C5FD] skew-y-12 z-0 rounded-bl-xl"></div>
                                        <div className="absolute bottom-4 right-[24%] w-16 h-20 bg-[#60A5FA] -skew-y-12 z-0 rounded-br-xl"></div>

                                        {/* Floating Circle with Icon */}
                                        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-20 bg-gradient-to-b from-[#818CF8] to-[#6366F1] rounded-full flex items-center justify-center shadow-lg shadow-indigo-500/30 z-20 ring-4 ring-white/80">
                                            {getIcon(pillar.icon)}
                                        </div>

                                        {/* Floating particles/stars */}
                                        <div className="absolute top-0 right-8 text-blue-300 animate-pulse">
                                            ✦
                                        </div>
                                        <div className="absolute top-10 left-6 text-blue-300 text-xs">
                                            ✦
                                        </div>
                                    </div>

                                    <div className="w-12 h-1.5 bg-[#FBBF24] mb-5 rounded-full"></div>
                                    <h3
                                        className="text-[#1E40AF] font-bold text-[19px] leading-tight mb-2 px-1 outline-none"
                                        contentEditable={!!onUpdate}
                                        suppressContentEditableWarning
                                        onBlur={(e) =>
                                            handlePillarBlur(index, "title", e.currentTarget.innerHTML || "")
                                        }
                                        dangerouslySetInnerHTML={{ __html: pillar.title || "" }}
                                    ></h3>
                                    <p
                                        className="text-slate-600 text-[15px] leading-relaxed px-2 font-medium outline-none"
                                        contentEditable={!!onUpdate}
                                        suppressContentEditableWarning
                                        onBlur={(e) =>
                                            handlePillarBlur(
                                                index,
                                                "description",
                                                e.currentTarget.innerHTML || ""
                                            )
                                        }
                                        dangerouslySetInnerHTML={{ __html: pillar.description || "" }}
                                    ></p>
                                </div>
                            </Wrapper>
                        ))}
                    </div>
                )}

                {/* Footer - Only show if pillars exist (Clean Mode check) */}
                {Array.isArray(data.pillars) && data.pillars.length > 0 && (
                    <Wrapper id="footer" className="mt-4 pt-8 border-t border-slate-200 text-center relative z-10 pointer-events-auto">
                        <p className="text-[#1E3A8A] font-semibold text-[22px] italic tracking-wide">
                            <span className="not-italic font-bold">In short:</span>{" "}
                            <span
                                contentEditable={!!onUpdate}
                                suppressContentEditableWarning
                                onBlur={(e) =>
                                    handleBlur("summary", e.currentTarget.innerHTML || "")
                                }
                                className="outline-none"
                                dangerouslySetInnerHTML={{ __html: data.summary || "" }}
                            ></span>
                        </p>
                    </Wrapper>
                )}

                <div className="absolute bottom-5 right-10 text-[10px] text-slate-400 font-bold tracking-[0.2em] uppercase">
                    Confidential | Commercial In Confidence
                </div>
            </div>
        </div>
    );
};
