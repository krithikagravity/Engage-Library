import React from 'react';
import { LucideIcon, ArrowRight } from 'lucide-react';

interface ModeCardProps {
    title: string;
    description: string;
    icon: LucideIcon;
    modeId: string;
    onClick: (modeId: string) => void;
    badge?: string;
    isLocked?: boolean;
}

export const ModeCard: React.FC<ModeCardProps> = ({
    title,
    description,
    icon: Icon,
    modeId,
    onClick,
    badge,
    isLocked = false,
}) => {
    return (
        <div
            onClick={() => !isLocked && onClick(modeId)}
            className={`group relative flex flex-col p-6 rounded-2xl border transition-all duration-300 h-full ${isLocked
                ? 'bg-slate-900/5 border-slate-200 opacity-60 cursor-not-allowed'
                : 'bg-white border-slate-200 hover:border-indigo-500/50 hover:shadow-xl hover:shadow-indigo-500/10 cursor-pointer'
                }`}
        >
            <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-xl ${isLocked ? 'bg-slate-100 text-slate-400' : 'bg-slate-50 text-indigo-600 group-hover:bg-indigo-50 group-hover:text-indigo-700 transition-colors'}`}>
                    <Icon size={24} />
                </div>
                {badge && (
                    <span className="px-2 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-semibold uppercase tracking-wider">
                        {badge}
                    </span>
                )}
            </div>

            <h3 className={`text-lg font-semibold mb-2 ${isLocked ? 'text-slate-400' : 'text-slate-800'}`}>
                {title}
            </h3>

            <p className={`text-sm leading-relaxed mb-8 flex-1 ${isLocked ? 'text-slate-400' : 'text-slate-500'}`}>
                {description}
            </p>

            {!isLocked && (
                <div className="flex items-center text-sm font-medium text-indigo-600 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <span>Launch</span>
                    <ArrowRight size={16} className="ml-2" />
                </div>
            )}
        </div>
    );
};
