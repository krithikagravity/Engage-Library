import React from "react";
import { LucideIcon, ArrowRight } from "lucide-react";

interface TemplateCardProps {
  title: string;
  subtitle: string;
  icon?: LucideIcon;
  iconBg?: string;
  iconColor?: string;
  image?: string;
  customPreview?: React.ReactNode;
  tag: string;
  tagBg: string;
  tagColor: string;
  onClick: () => void;
}

export const TemplateCard: React.FC<TemplateCardProps> = ({
  title,
  subtitle,
  icon: Icon,
  iconBg,
  iconColor,
  image,
  customPreview,
  tag,
  tagBg,
  tagColor,
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer group flex flex-col h-full overflow-hidden"
    >
      {customPreview ? (
        <div className="w-full h-48 relative overflow-hidden bg-slate-50 border-b border-slate-100">
          {customPreview}
          <div className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-semibold tracking-wide bg-white/90 backdrop-blur-sm shadow-sm text-slate-800 z-10">
            {tag}
          </div>
        </div>
      ) : image ? (
        <div className="w-full h-48 relative overflow-hidden bg-slate-100">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-semibold tracking-wide bg-white/90 backdrop-blur-sm shadow-sm text-slate-800">
            {tag}
          </div>
        </div>
      ) : (
        <div className="p-6 pb-0 flex justify-between items-start">
          <div
            className={`p-3.5 rounded-xl ${iconBg} ${iconColor} transition-transform group-hover:scale-110 duration-300`}
          >
            {Icon && <Icon size={24} strokeWidth={1.5} />}
          </div>
          <div
            className={`px-3 py-1 rounded-full text-xs font-semibold tracking-wide ${tagBg} ${tagColor}`}
          >
            {tag}
          </div>
        </div>
      )}

      <div className="p-6 mt-auto">
        <h3 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">
          {title}
        </h3>
        <p className="text-slate-500 text-sm leading-relaxed mb-4">
          {subtitle}
        </p>

        <div className="flex items-center text-indigo-600 font-medium text-sm opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
          Use Template <ArrowRight size={16} className="ml-1" />
        </div>
      </div>
    </div>
  );
};
