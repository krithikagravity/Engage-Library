import React, { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle, AlertTriangle, XCircle, ArrowRight, Upload, FileText, Loader2, ShieldCheck } from 'lucide-react';
import { parseDocument, DocumentAnalysisResult } from '../utils/documentParser';

interface BrandConsistencyCheckModeProps {
    onBack: () => void;
}

interface Issue {
    id: string;
    type: 'error' | 'warning' | 'pass';
    title: string;
    message: string;
    action: string;
}

export const BrandConsistencyCheckMode: React.FC<BrandConsistencyCheckModeProps> = ({ onBack }) => {
    const [step, setStep] = useState<'upload' | 'analyzing' | 'results'>('upload');
    const [progress, setProgress] = useState(0);
    const [statusText, setStatusText] = useState('Initializing scan...');
    const [activeTab, setActiveTab] = useState<'flagged' | 'comparison'>('flagged');
    const [analysisData, setAnalysisData] = useState<DocumentAnalysisResult | null>(null);
    const [issues, setIssues] = useState<Issue[]>([]);

    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const generateIssues = (data: DocumentAnalysisResult): Issue[] => {
        const newIssues: Issue[] = [];
        const textLower = data.text.toLowerCase();
        const fonts = data.detectedFonts.map(f => f.toLowerCase());

        // 1. Typography Check
        const hasBrandFonts = fonts.some(f => f.includes('montserrat') || f.includes('inter') || f.includes('helvetica'));
        const hasSystemFonts = fonts.some(f => f.includes('arial') || f.includes('calibri') || f.includes('times'));

        if (hasSystemFonts) {
            newIssues.push({
                id: '1',
                type: 'error',
                title: 'Typography Violation',
                message: `Detected system fonts (${data.detectedFonts.filter(f => /arial|calibri|times/i.test(f)).join(', ')}). Primary headers must use Montserrat, Helvetica Neue, or Inter.`,
                action: 'Update all slide titles to Montserrat Bold (Uppercase) and body to Inter Regular.'
            });
        } else if (hasBrandFonts) {
            newIssues.push({
                id: '1',
                type: 'pass',
                title: 'Typography',
                message: 'Correct brand fonts (Montserrat/Inter/Helvetica) detected.',
                action: ''
            });
        } else if (fonts.length === 0) {
            newIssues.push({
                id: '1',
                type: 'warning',
                title: 'Typography Check',
                message: 'No font metadata found. This may be a plain text file or an older format. Ensure visual inspection.',
                action: 'Manual verification recommended.'
            });
        } else {
            newIssues.push({
                id: '1',
                type: 'warning',
                title: 'Typography Check',
                message: `Could not definitively verify brand fonts. Detected: ${data.detectedFonts.slice(0, 3).join(', ')}... Ensure Montserrat/Inter are used.`,
                action: 'Manual verification recommended.'
            });
        }

        // 2. Color Palette (Simulated/Manual as we can't extract colors yet)
        newIssues.push({
            id: '2',
            type: 'warning',
            title: 'Color Palette Verification',
            message: 'Automated color extraction is limited. Please manually verify Primary Dark (#0E1A2B) and Primary Blue (#1F3C88).',
            action: 'Ensure no generic blues (#0000FF) or grays are used.'
        });

        // 3. Brand Assets (Logo Check via text)
        if (textLower.includes('gravityone') || textLower.includes('gravity one')) {
            newIssues.push({
                id: '3',
                type: 'pass',
                title: 'Brand Assets',
                message: 'Brand name "GravityOne" detected in document.',
                action: ''
            });
        } else {
            newIssues.push({
                id: '3',
                type: 'error',
                title: 'Missing Brand Assets',
                message: 'Brand name "GravityOne" not found in text content. Logo or Brand Name missing.',
                action: 'Insert GravityOne logo and ensure brand name is mentioned.'
            });
        }

        // 4. Tone of Voice
        const strategicKeywords = ['strategic', 'transformational', 'global', 'intelligent', 'authoritative', 'growth', 'data'];
        const weakKeywords = ['maybe', 'perhaps', 'failed', 'sorry', 'hope'];

        const foundStrategic = strategicKeywords.filter(k => textLower.includes(k));
        const foundWeak = weakKeywords.filter(k => textLower.includes(k));

        if (foundWeak.length > 0) {
            newIssues.push({
                id: '4',
                type: 'warning',
                title: 'Tone of Voice',
                message: `Detected weak language: "${foundWeak.join(', ')}". Brand personality requires "Strategic, Authoritative, & Transformational".`,
                action: 'Rewrite using active, decisive executive language.'
            });
        } else if (foundStrategic.length >= 2) {
            newIssues.push({
                id: '4',
                type: 'pass',
                title: 'Tone of Voice',
                message: 'Content usage reflects Strategic and Authoritative tone.',
                action: ''
            });
        } else {
            newIssues.push({
                id: '4',
                type: 'warning',
                title: 'Tone of Voice',
                message: 'Tone appears neutral. Consider adding more strategic terminology (e.g., "Transformation", "Global", "Growth").',
                action: 'Enhance executive summary with power words.'
            });
        }

        // 5. Slide Count
        if (data.pageCount > 0) {
            if (data.pageCount > 25) {
                newIssues.push({
                    id: '5',
                    type: 'warning',
                    title: 'Slide Count',
                    message: `Document length (${data.pageCount} pages) exceeds recommended executive summary length.`,
                    action: 'Condense content to < 20 slides.'
                });
            } else {
                newIssues.push({
                    id: '5',
                    type: 'pass',
                    title: 'Slide Count',
                    message: `Deck length (${data.pageCount} pages) is within the optimal range.`,
                    action: ''
                });
            }
        } else {
            // If we couldn't detect pages (e.g. text file or weird DOCX), ignore or warn gently
            newIssues.push({
                id: '5',
                type: 'warning',
                title: 'Slide Count',
                message: 'Could not automatically determine page/slide count.',
                action: 'Manual check: Ensure deck is under 20 slides.'
            });
        }

        return newIssues;
    };

    const handleFileUpload = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setStep('analyzing');
            setProgress(0);

            try {
                // Start progress simulation
                const interval = setInterval(() => {
                    setProgress(prev => Math.min(prev + 5, 90));
                }, 200);

                // Perform actual analysis
                setStatusText('Extracting document content...');
                const result = await parseDocument(file);

                setStatusText('Analyzing against GravityOne guidelines...');
                const generatedIssues = generateIssues(result);

                setAnalysisData(result);
                setIssues(generatedIssues);

                clearInterval(interval);
                setProgress(100);
                setTimeout(() => setStep('results'), 500);

            } catch (error: any) {
                console.error("Analysis failed:", error);
                setStatusText(`Analysis failed: ${error.message || 'Unknown error'}`);
                // Handle error state appropriately in UI if needed
            }
        }
    };



    return (
        <div className="w-full h-full flex flex-col bg-transparent text-slate-900 relative z-50 overflow-hidden font-sans">

            {/* Header - Back Button Only */}
            <div className="flex items-center px-8 py-6 relative z-10 w-full max-w-7xl mx-auto">
                <button
                    onClick={onBack}
                    className="p-2 rounded-lg hover:bg-white/50 transition-colors border border-transparent hover:border-white/50 group text-slate-600 hover:text-slate-900 bg-white/30 backdrop-blur-sm shadow-sm"
                >
                    <ArrowLeft size={20} />
                </button>
            </div>

            {/* Stepper (Visible in all steps) */}
            <div className="w-full max-w-2xl mx-auto mb-12 relative z-10">
                <div className="flex items-center justify-between relative">
                    {/* Connecting Line */}
                    <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -z-10 w-full" />

                    {/* Step 1: Upload */}
                    <div className={`flex flex-col items-center gap-2 bg-transparent`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${step === 'upload' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 ring-4 ring-white' :
                            'bg-indigo-600 text-white'
                            }`}>
                            {step === 'upload' ? '1' : <CheckCircle size={16} />}
                        </div>
                        <span className={`text-xs font-semibold uppercase tracking-wider ${step === 'upload' ? 'text-indigo-600' : 'text-slate-500'
                            }`}>Upload</span>
                    </div>

                    {/* Step 2: Analyze */}
                    <div className={`flex flex-col items-center gap-2 bg-transparent`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${step === 'analyzing' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 ring-4 ring-white' :
                            step === 'results' ? 'bg-indigo-600 text-white' :
                                'bg-slate-200 text-slate-500'
                            }`}>
                            {step === 'results' ? <CheckCircle size={16} /> : '2'}
                        </div>
                        <span className={`text-xs font-semibold uppercase tracking-wider ${step === 'analyzing' ? 'text-indigo-600' : 'text-slate-500'
                            }`}>Analyze</span>
                    </div>

                    {/* Step 3: Results */}
                    <div className={`flex flex-col items-center gap-2 bg-transparent`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${step === 'results' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 ring-4 ring-white' :
                            'bg-slate-200 text-slate-500'
                            }`}>
                            3
                        </div>
                        <span className={`text-xs font-semibold uppercase tracking-wider ${step === 'results' ? 'text-indigo-600' : 'text-slate-500'
                            }`}>Results</span>
                    </div>
                </div>
            </div>

            {/* Main Content Areas */}
            <div className="flex-1 overflow-y-auto custom-scrollbar relative z-10 w-full max-w-5xl mx-auto px-8 pb-12">

                {/* STEP 1: UPLOAD */}
                {step === 'upload' && (
                    <div className="flex flex-col items-center justify-center h-full min-h-[400px] animate-fade-in-up">
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            className="hidden"
                            accept=".pdf,.pptx,.key,.docx"
                        />
                        <div
                            className="w-full max-w-2xl bg-white/60 backdrop-blur-md rounded-3xl border-2 border-dashed border-indigo-200 p-12 flex flex-col items-center justify-center text-center hover:border-indigo-400 hover:bg-white/80 transition-all cursor-pointer group shadow-xl"
                            onClick={handleFileUpload}
                        >
                            <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Upload size={32} className="text-indigo-600" />
                            </div>
                            <h2 className="text-2xl font-bold text-slate-800 mb-2">Upload your presentation</h2>
                            <p className="text-slate-500 mb-8 max-w-md">
                                Drag and drop your PDF, PPTX, DOCX, or Keynote file here to evaluate brand consistency.
                            </p>
                            <button className="bg-indigo-600 text-white px-8 py-3 rounded-full font-medium hover:bg-indigo-700 transition-colors shadow-lg hover:shadow-indigo-500/30">
                                Select File
                            </button>
                            <p className="text-xs text-slate-400 mt-6 uppercase tracking-wider font-semibold">
                                Supported formats: PDF, PPTX, KEY, DOCX
                            </p>
                        </div>
                    </div>
                )}

                {/* STEP 2: ANALYZING */}
                {step === 'analyzing' && (
                    <div className="flex flex-col items-center justify-center h-full min-h-[400px] animate-fade-in">
                        <div className="w-full max-w-xl text-center">
                            <div className="mb-8 relative">
                                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto shadow-xl ring-4 ring-indigo-50 animate-pulse">
                                    <ShieldCheck size={40} className="text-indigo-600" />
                                </div>
                                {/* Spinning ring */}
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-24 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                            </div>

                            <h2 className="text-2xl font-bold text-slate-800 mb-2">Evaluating Brand Alignment</h2>
                            <p className="text-slate-500 mb-8 font-medium animate-pulse">{statusText}</p>

                            {/* Progress Bar */}
                            <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden shadow-inner">
                                <div
                                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300 ease-out rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]"
                                    style={{ width: `${progress}%` }}
                                ></div>
                            </div>
                            <div className="flex justify-between mt-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                                <span>Scanning...</span>
                                <span>{progress}% complete</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* STEP 3: RESULTS */}
                {step === 'results' && (
                    <div className="animate-fade-in w-full">
                        {/* Stats & Score */}
                        <div className="flex items-center gap-16 mb-12 bg-white rounded-2xl p-8 border border-slate-100 shadow-sm">
                            {/* Circular Score */}
                            <div className="relative w-40 h-40 flex items-center justify-center">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle
                                        cx="80"
                                        cy="80"
                                        r="70"
                                        stroke="#ec4899" // Pink-500 background ring opacity
                                        strokeOpacity="0.1"
                                        strokeWidth="12"
                                        fill="transparent"
                                    />
                                    <circle
                                        cx="80"
                                        cy="80"
                                        r="70"
                                        stroke={issues.filter(i => i.type === 'pass').length / issues.length > 0.7 ? "#10b981" : "#ec4899"} // Green if > 70%, Pink otherwise
                                        strokeWidth="12"
                                        fill="transparent"
                                        strokeDasharray={439.82}
                                        strokeDashoffset={439.82 * (1 - (issues.filter(i => i.type === 'pass').length / Math.max(issues.length, 1)))}
                                        strokeLinecap="round"
                                    />
                                </svg>
                                <div className="absolute inset-0 flex flex-col items-center justify-center">
                                    <span className="text-5xl font-bold text-slate-800 tracking-tight">
                                        {Math.round((issues.filter(i => i.type === 'pass').length / Math.max(issues.length, 1)) * 100)}%
                                    </span>
                                    <span className="text-[10px] text-pink-500 uppercase tracking-widest font-bold mt-2">Brand Score</span>
                                </div>
                            </div>

                            {/* Issue Breakdown */}
                            <div className="space-y-4">
                                <div className="flex items-center gap-4 group cursor-default">
                                    <div className="p-2 rounded-lg bg-red-50 text-red-600 border border-red-100 group-hover:border-red-200 transition-colors">
                                        <XCircle size={20} />
                                    </div>
                                    <div>
                                        <span className="text-2xl font-bold text-slate-800 block leading-none mb-1">
                                            {issues.filter(i => i.type === 'error').length}
                                        </span>
                                        <span className="text-slate-500 text-xs uppercase tracking-wide font-medium">Critical Issues</span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 group cursor-default">
                                    <div className="p-2 rounded-lg bg-amber-50 text-amber-600 border border-amber-100 group-hover:border-amber-200 transition-colors">
                                        <AlertTriangle size={20} />
                                    </div>
                                    <div>
                                        <span className="text-2xl font-bold text-slate-800 block leading-none mb-1">
                                            {issues.filter(i => i.type === 'warning').length}
                                        </span>
                                        <span className="text-slate-500 text-xs uppercase tracking-wide font-medium">Warnings</span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 group cursor-default">
                                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100 group-hover:border-emerald-200 transition-colors">
                                        <CheckCircle size={20} />
                                    </div>
                                    <div>
                                        <span className="text-2xl font-bold text-slate-800 block leading-none mb-1">
                                            {issues.filter(i => i.type === 'pass').length}
                                        </span>
                                        <span className="text-slate-500 text-xs uppercase tracking-wide font-medium">Passed</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Tabs */}
                        <div className="flex items-center gap-6 mb-8 border-b border-slate-200 pb-1">
                            <button
                                onClick={() => setActiveTab('flagged')}
                                className={`px-4 py-3 text-sm font-medium flex items-center gap-2 transition-all relative ${activeTab === 'flagged'
                                    ? 'text-indigo-600'
                                    : 'text-slate-500 hover:text-slate-800'
                                    }`}
                            >
                                Flagged Issues
                                {activeTab === 'flagged' && (
                                    <div className="absolute bottom-[-5px] left-0 right-0 h-0.5 bg-indigo-600 rounded-t-full"></div>
                                )}
                            </button>
                            <button
                                onClick={() => setActiveTab('comparison')}
                                className={`px-4 py-3 text-sm font-medium flex items-center gap-2 transition-all relative ${activeTab === 'comparison'
                                    ? 'text-indigo-600'
                                    : 'text-slate-500 hover:text-slate-800'
                                    }`}
                            >
                                Side-by-Side Comparison
                                {activeTab === 'comparison' && (
                                    <div className="absolute bottom-[-5px] left-0 right-0 h-0.5 bg-indigo-600 rounded-t-full"></div>
                                )}
                            </button>
                        </div>

                        {/* Issues List */}
                        <div className="space-y-4 pb-20">
                            {issues.map((issue) => (
                                <div
                                    key={issue.id}
                                    className="group relative bg-white border border-slate-200 rounded-xl p-6 transition-all hover:shadow-lg hover:border-slate-300 overflow-hidden"
                                >
                                    {/* Left Accent Border */}
                                    <div className={`absolute left-0 top-0 bottom-0 w-1 ${issue.type === 'error' ? 'bg-red-500' :
                                        issue.type === 'warning' ? 'bg-amber-500' :
                                            'bg-emerald-500'
                                        }`}></div>

                                    <div className="flex items-start justify-between mb-3 pl-4">
                                        <div className="flex items-center gap-3">
                                            {issue.type === 'error' && (
                                                <div className="p-1.5 rounded-md bg-red-50 text-red-600">
                                                    <XCircle size={18} />
                                                </div>
                                            )}
                                            {issue.type === 'warning' && (
                                                <div className="p-1.5 rounded-md bg-amber-50 text-amber-600">
                                                    <AlertTriangle size={18} />
                                                </div>
                                            )}
                                            {issue.type === 'pass' && (
                                                <div className="p-1.5 rounded-md bg-emerald-50 text-emerald-600">
                                                    <CheckCircle size={18} />
                                                </div>
                                            )}
                                            <h3 className="font-semibold text-slate-800 text-lg tracking-tight">
                                                {issue.title}
                                            </h3>
                                        </div>
                                        <span className={`text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider border ${issue.type === 'error' ? 'bg-red-50 border-red-100 text-red-600' :
                                            issue.type === 'warning' ? 'bg-amber-50 border-amber-100 text-amber-600' :
                                                'bg-emerald-50 border-emerald-100 text-emerald-600'
                                            }`}>
                                            {issue.type.toUpperCase()}
                                        </span>
                                    </div>

                                    <p className="text-slate-600 text-sm mb-4 pl-[3.25rem] leading-relaxed">
                                        {issue.message}
                                    </p>

                                    {issue.action && (
                                        <div className="ml-[3.25rem] flex items-center gap-3 text-sm font-medium p-3 rounded-lg bg-slate-50 border border-slate-100 mt-2 group-hover:bg-slate-100 transition-colors">
                                            <span className={`flex-shrink-0 ${issue.type === 'error' ? 'text-red-500' :
                                                issue.type === 'warning' ? 'text-amber-500' : 'text-emerald-500'
                                                }`}>
                                                <ArrowRight size={16} />
                                            </span>
                                            <span className="text-slate-700">
                                                <span className="text-slate-400 mr-2 uppercase text-[10px] font-bold tracking-wider">Solution:</span>
                                                {issue.action}
                                            </span>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>

                        {/* Footer Actions */}
                        <div className="flex justify-center pb-12">
                            <button className="bg-white hover:bg-slate-50 text-slate-600 px-8 py-3 rounded-full text-sm font-medium border border-slate-200 transition-colors shadow-sm hover:shadow-md" onClick={() => setStep('upload')}>
                                Check Another Document
                            </button>
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
};
