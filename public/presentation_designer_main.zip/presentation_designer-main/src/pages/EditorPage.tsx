import React, { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { GravityData, ArtsyData, DHREData } from "../types";
import { GravitySlide } from "../components/GravitySlide";
import { DarkArtsySlide } from "../components/DarkArtsySlide";
import { DHRESlide } from "../components/DHRESlide";
import { ResponsiveSlideWrapper } from "../components/ResponsiveSlideWrapper";
import {
    GRAVITY_DEFAULT_DATA,
    ARTSY_DEFAULT_DATA,
    DHRE_DEFAULT_DATA,
} from "../utils/templates";
import { Plus, ChevronLeft, Trash2, Copy, Download } from "lucide-react";
import { exportToPPT } from "../utils/pptExporter";

export const EditorPage: React.FC = () => {
    const { type } = useParams<{ type: string }>();
    const navigate = useNavigate();
    const location = useLocation();

    const [slides, setSlides] = useState<(GravityData | ArtsyData | DHREData)[]>([]);
    const [activeSlideIndex, setActiveSlideIndex] = useState(0);

    useEffect(() => {
        // Check if we have initial data passed from generation
        const initialData = location.state?.initialData;

        if (initialData) {
            if (Array.isArray(initialData)) {
                setSlides(initialData);
            } else {
                setSlides([initialData]);
            }
        } else {
            // Initialize with default if no generated data
            if (type === "gravity") {
                setSlides([GRAVITY_DEFAULT_DATA]);
            } else if (type === "artsy") {
                setSlides([ARTSY_DEFAULT_DATA]);
            } else if (type === "dhre") {
                setSlides([DHRE_DEFAULT_DATA]);
            }
        }
    }, [type, location.state]);

    const handleUpdateSlide = (updatedData: GravityData | ArtsyData | DHREData) => {
        const newSlides = [...slides];
        newSlides[activeSlideIndex] = updatedData;
        setSlides(newSlides);
    };

    const handleAddSlide = () => {
        if (type === "gravity") {
            // Deep copy default data
            const newSlide = JSON.parse(JSON.stringify(GRAVITY_DEFAULT_DATA));
            setSlides([...slides, newSlide]);
            setActiveSlideIndex(slides.length);
        } else if (type === "artsy") {
            const newSlide = JSON.parse(JSON.stringify(ARTSY_DEFAULT_DATA));
            setSlides([...slides, newSlide]);
            setActiveSlideIndex(slides.length);
        } else if (type === "dhre") {
            const newSlide = JSON.parse(JSON.stringify(DHRE_DEFAULT_DATA));
            setSlides([...slides, newSlide]);
            setActiveSlideIndex(slides.length);
        }
    };

    const handleDuplicateSlide = (e: React.MouseEvent, index: number) => {
        e.stopPropagation();
        const slideToDuplicate = slides[index];
        const newSlide = JSON.parse(JSON.stringify(slideToDuplicate));
        const newSlides = [...slides];
        newSlides.splice(index + 1, 0, newSlide);
        setSlides(newSlides);
        setActiveSlideIndex(index + 1);
    };

    const handleDeleteSlide = (e: React.MouseEvent, index: number) => {
        e.stopPropagation();
        if (slides.length <= 1) return; // Prevent deleting the last slide

        const newSlides = slides.filter((_, i) => i !== index);
        setSlides(newSlides);

        // Adjust active index
        if (activeSlideIndex >= index && activeSlideIndex > 0) {
            setActiveSlideIndex(activeSlideIndex - 1);
        }
    };

    // Prepare data for export
    const handleExport = () => {
        const result = {
            type: type === "gravity" ? "gravity-layout" : type === "artsy" ? "artsy-layout" : "dhre-layout",
            content: slides,
        };
        // @ts-ignore
        exportToPPT(result);
    };

    if (slides.length === 0) return <div>Loading...</div>;

    return (
        <div className="flex h-screen w-full flex-1 bg-[#F3F5F9] overflow-hidden text-slate-900">
            {/* Sidebar - Thumbnails */}
            <div className="w-64 bg-white border-r border-slate-200 flex flex-col z-10">
                <div className="p-4 border-b border-slate-100 flex items-center gap-2">
                    <button
                        onClick={() => navigate("/")}
                        className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition-colors"
                        title="Back to Home"
                    >
                        <ChevronLeft size={20} />
                    </button>
                    <span className="font-semibold text-slate-800">
                        {type === "gravity" ? "Gravity Deck" : type === "artsy" ? "Artsy Deck" : "DHRE Deck"}
                    </span>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {slides.map((slide, index) => (
                        <div
                            key={index}
                            onClick={() => setActiveSlideIndex(index)}
                            className={`relative group cursor-pointer transition-all duration-200 ${activeSlideIndex === index
                                ? "ring-2 ring-indigo-500 shadow-md"
                                : "hover:ring-2 hover:ring-indigo-200 hover:shadow-sm"
                                } rounded-lg overflow-hidden bg-slate-100 aspect-video`}
                        >
                            {/* Tiny Preview (Scaled down heavily) */}
                            <div className="absolute inset-0 pointer-events-none transform scale-[0.2] origin-top-left w-[500%] h-[500%]">
                                {type === "gravity" ? (
                                    <GravitySlide data={slide as GravityData} />
                                ) : type === "artsy" ? (
                                    <DarkArtsySlide data={slide as ArtsyData} />
                                ) : (
                                    <DHRESlide data={slide as DHREData} />
                                )}
                            </div>

                            {/* Hover Controls */}
                            <div className="absolute top-2 right-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                    onClick={(e) => handleDuplicateSlide(e, index)}
                                    className="bg-white/90 p-1.5 rounded-md text-slate-600 hover:text-indigo-600 shadow-sm backdrop-blur-sm"
                                    title="Duplicate"
                                >
                                    <Copy size={12} />
                                </button>
                                {slides.length > 1 && (
                                    <button
                                        onClick={(e) => handleDeleteSlide(e, index)}
                                        className="bg-white/90 p-1.5 rounded-md text-slate-600 hover:text-red-600 shadow-sm backdrop-blur-sm"
                                        title="Delete"
                                    >
                                        <Trash2 size={12} />
                                    </button>
                                )}
                            </div>

                            <div className="absolute bottom-1 left-2 bg-black/50 text-white text-[10px] px-1.5 rounded">
                                {index + 1}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="p-4 border-t border-slate-200">
                    <button
                        onClick={handleAddSlide}
                        className="w-full py-2.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-lg flex items-center justify-center gap-2 font-medium transition-colors"
                    >
                        <Plus size={18} />
                        New Slide
                    </button>
                </div>
            </div>

            {/* Main Canvas */}
            <div className="flex-1 overflow-hidden flex flex-col relative">
                {/* Slide Controls Top Bar */}
                <div className="min-h-[8rem] bg-slate-50 border-b border-slate-200 flex items-center px-6 justify-between flex-shrink-0 z-10 shadow-inner overflow-x-auto">
                    <div className="flex items-center gap-4 py-2">
                        {type === "gravity" && (
                            <div className="flex items-center gap-6">
                                <label className="text-sm font-semibold text-slate-600 whitespace-nowrap uppercase tracking-wider">Slide Layouts:</label>
                                <div className="flex gap-4">
                                {[
                                    { id: 'default', label: 'Builder' },
                                    { id: 'dto', label: 'DTO' },
                                    { id: 'landscape', label: 'Landscape' },
                                    { id: 'process', label: 'Process' }
                                ].map(template => {
                                    const isActive = ((slides[activeSlideIndex] as GravityData).layout || 'default') === template.id;
                                    return (
                                        <div
                                            key={template.id}
                                            onClick={() => {
                                                handleUpdateSlide({
                                                    ...slides[activeSlideIndex],
                                                    layout: template.id as any
                                                } as GravityData);
                                            }}
                                            className="relative flex flex-col items-center gap-1.5 cursor-pointer group"
                                        >
                                            <div className={`w-40 aspect-video relative rounded-md overflow-hidden transition-all duration-200 ${
                                                isActive 
                                                    ? 'ring-2 ring-indigo-600 shadow-md scale-105' 
                                                    : 'border border-slate-300 shadow-sm hover:border-indigo-400 hover:shadow-md'
                                            }`}>
                                                <div className="absolute inset-0 pointer-events-none transform scale-[0.05] origin-top-left w-[2000%] h-[2000%] bg-white">
                                                    <GravitySlide data={{
                                                        ...(slides[activeSlideIndex] as GravityData),
                                                        layout: template.id as any,
                                                        images: undefined // Prevent user images from displaying in layout gallery thumbnails
                                                    }} />
                                                </div>
                                            </div>
                                            <span className={`text-[10px] font-bold uppercase tracking-wider transition-colors ${isActive ? 'text-indigo-700' : 'text-slate-400 group-hover:text-slate-600'}`}>
                                                {template.label}
                                            </span>
                                        </div>
                                    );
                                })}
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                <div className="flex-1 p-8 overflow-auto flex items-center justify-center bg-slate-100/50">
                    <div className="w-full max-w-6xl shadow-2xl rounded-xl overflow-hidden border border-slate-200/60 bg-white">
                        <ResponsiveSlideWrapper>
                            {type === "gravity" ? (
                                <GravitySlide
                                    data={slides[activeSlideIndex] as GravityData}
                                    onUpdate={handleUpdateSlide}
                                />
                            ) : type === "artsy" ? (
                                <DarkArtsySlide
                                    data={slides[activeSlideIndex] as ArtsyData}
                                    onUpdate={handleUpdateSlide}
                                />
                            ) : (
                                <DHRESlide
                                    data={slides[activeSlideIndex] as DHREData}
                                    onUpdate={handleUpdateSlide}
                                />
                            )}
                        </ResponsiveSlideWrapper>
                    </div>
                </div>

                {/* Floating Export Button */}
                <button
                    onClick={handleExport}
                    className="absolute bottom-8 right-8 z-50 flex items-center gap-2 bg-indigo-600 text-white px-6 py-4 rounded-full shadow-2xl hover:bg-indigo-700 transition-all hover:scale-105 animate-fade-in-up"
                    title="Export Deck to PowerPoint"
                    style={{ boxShadow: '0 10px 25px -5px rgba(79, 70, 229, 0.4)' }}
                >
                    <Download size={24} />
                    <span className="font-semibold text-base">Export Deck</span>
                </button>
            </div>
        </div>
    );
};
