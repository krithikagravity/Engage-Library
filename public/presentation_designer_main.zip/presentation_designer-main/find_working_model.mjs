
import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.REACT_APP_GEMINI_API_KEY || "AIzaSyBBpNiXimH6v9oYdulyo4q2h-xsBqXtgQw";
const ai = new GoogleGenAI({ apiKey });

async function findWorkingModel() {
    console.log("Fetching model list...");
    try {
        const response = await ai.models.list();
        const allModels = response.models || [];

        // Filter for generation-capable models
        const candidates = allModels.filter(m =>
            m.supportedActions &&
            m.supportedActions.includes("generateContent")
        );

        console.log(`Found ${candidates.length} candidates.`);

        for (const model of candidates) {
            console.log(`Testing ${model.name}...`);
            try {
                const result = await ai.models.generateContent({
                    model: model.name,
                    contents: "Hello",
                });
                if (result.text) {
                    console.log(`\n!!! SUCCESS !!!\nWorking Model Found: ${model.name}\n`);
                    return; // Stop matching
                }
            } catch (error) {
                console.log(`Failed (${model.name}): ${error.status || error.message}`);
            }
        }
        console.log("No working models found.");

    } catch (e) {
        console.error("List failed:", e);
    }
}

findWorkingModel();
