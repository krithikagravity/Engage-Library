
const { exec } = require('child_process');

const urlBase = "https://image.pollinations.ai/prompt/";

const prompts = [
    "healthcare",
    "hospital",
    "digital_ecosystem",
    "isometric_city",
    "AI_driven",
    "Al_driven", // Testing for typo
    "system_map"
];

const runCurl = (prompt) => {
    const url = `${urlBase}${prompt}`;
    return new Promise((resolve) => {
        const cmd = `curl -I -L --user-agent "Mozilla/5.0" "${url}"`;
        exec(cmd, (error, stdout, stderr) => {
            const statusMatch = stdout.match(/HTTP\/[122\.]+\s+(\d{3})/);
            resolve({ prompt, status: statusMatch ? statusMatch[1] : "ERR" });
        });
    });
};

async function run() {
    console.log("Testing keywords...");
    for (const p of prompts) {
        const result = await runCurl(p);
        console.log(`[${result.status}] ${result.prompt}`);
    }
}

run();
