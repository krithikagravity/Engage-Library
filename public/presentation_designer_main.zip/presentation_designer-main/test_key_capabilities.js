
const { GoogleGenAI } = require("@google/genai");

// The key the user wants to use
const apiKey = "AIzaSyDST8Kds1S0KzrXrXfKR0d-5e-JjeSNmwg";
const ai = new GoogleGenAI({ apiKey });

const modelsToTest = ["gemini-pro", "gemini-1.0-pro", "gemini-1.5-flash", "gemini-1.5-pro"];

async function testModels() {
    console.log(`Testing API Key: ${apiKey.substring(0, 10)}...`);

    for (const modelName of modelsToTest) {
        console.log(`\n--- Testing ${modelName} ---`);
        try {
            const response = await ai.models.generateContent({
                model: modelName,
                contents: "Hello",
            });
            console.log(`SUCCESS: ${modelName}`);
            console.log(response.text ? "Has Response Text" : "Empty Response");
        } catch (error) {
            console.log(`FAILED: ${modelName}`);
            console.log(`Error: ${error.message}`);
        }
    }
}

testModels();
