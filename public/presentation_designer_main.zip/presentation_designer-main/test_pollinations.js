
const https = require('https');

async function testPollinations() {
    const prompt = "Create a JSON object for a presentation slide about 'Future of AI'. Returning ONLY raw JSON. Fields: title, thesis, summary.";
    const url = `https://text.pollinations.ai/${encodeURIComponent(prompt)}`;

    console.log("Fetching from:", url);

    https.get(url, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
            console.log("Response:", data);
        });
    }).on('error', (err) => {
        console.error("Error:", err.message);
    });
}

testPollinations();
