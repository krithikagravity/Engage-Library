
const prompt = "AI-driven national healthcare ecosystem connecting hospitals, insurers, regulators, and citizens";

const extractKeywords = (text) => {
    const stopWords = ['a', 'an', 'the', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'and', 'or', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might', 'must', 'driven', 'based', 'connecting'];

    // Improved regex: replace non-word chars with SPACE to separate hyphenated words
    return text.toLowerCase()
        .replace(/[^\w\s]/g, ' ')
        .split(/\s+/)
        .filter(word => word.length > 3 && !stopWords.includes(word))
        .slice(0, 3)
        .join(',');
};

const keywords = extractKeywords(prompt);
const stockUrl = `https://loremflickr.com/1280/720/${keywords}?lock=123`;

console.log("Extracted Keywords:", keywords);
console.log("Stock URL:", stockUrl);
