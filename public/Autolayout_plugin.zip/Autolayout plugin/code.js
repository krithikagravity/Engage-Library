// ─── Engage Library – Autolayout Plugin ──────────────────────────────────────
// Replicates Figma's native Shift+A behaviour.
// Select one or more frames and run the plugin to apply optimal auto-layout.

const ICON_THRESHOLD = 32;

function isIcon(node) {
  if (node.type === 'VECTOR' || node.type === 'BOOLEAN_OPERATION') return true;
  if (node.width <= ICON_THRESHOLD && node.height <= ICON_THRESHOLD) return true;
  if ('children' in node && node.children.length > 0) {
    const allVector = node.children.every(c =>
      ['VECTOR','BOOLEAN_OPERATION','ELLIPSE','RECTANGLE','LINE','STAR','POLYGON'].includes(c.type)
    );
    if (allVector) return true;
  }
  return false;
}

/**
 * Replicates Figma's native Shift+A on a FrameNode.
 * Reads current child positions and sets layoutMode / spacing / padding / alignment
 * so items remain exactly where they are after auto layout is enabled.
 */
function applyAutoLayoutNative(frame) {
  const children = [...frame.children].filter(c => 'x' in c);
  if (children.length === 0) return;

  const items = children.map(c => ({
    node: c, x: c.x, y: c.y, w: c.width, h: c.height
  }));

  if (items.length === 1) {
    const it = items[0];
    try {
      frame.layoutMode = 'HORIZONTAL';
      frame.paddingLeft   = Math.max(0, Math.round(it.x));
      frame.paddingTop    = Math.max(0, Math.round(it.y));
      frame.paddingRight  = Math.max(0, Math.round(frame.width  - it.x - it.w));
      frame.paddingBottom = Math.max(0, Math.round(frame.height - it.y - it.h));
      frame.itemSpacing = 0;
      frame.primaryAxisSizingMode = 'FIXED';
      frame.counterAxisSizingMode = 'FIXED';
    } catch (e) { console.warn('AutoLayout single child failed:', e.message); }
    return;
  }

  // ── Direction ─────────────────────────────────────────────────────────────
  const xs = items.map(i => i.x), ys = items.map(i => i.y);
  const xSpread = Math.max(...xs) - Math.min(...xs);
  const ySpread = Math.max(...ys) - Math.min(...ys);
  const direction = xSpread >= ySpread ? 'HORIZONTAL' : 'VERTICAL';

  // ── Sort by primary axis ──────────────────────────────────────────────────
  const sorted = [...items].sort((a, b) =>
    direction === 'HORIZONTAL' ? a.x - b.x : a.y - b.y
  );

  // ── Gaps between adjacent items ───────────────────────────────────────────
  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1], curr = sorted[i];
    const gap = direction === 'HORIZONTAL'
      ? curr.x - (prev.x + prev.w)
      : curr.y - (prev.y + prev.h);
    if (gap >= -1) gaps.push(Math.max(0, gap));
  }

  // ── Spacing mode ──────────────────────────────────────────────────────────
  let primaryAxisAlignItems = 'MIN';
  let itemSpacing = 0;
  if (gaps.length > 0) {
    const minG = Math.min(...gaps), maxG = Math.max(...gaps);
    const avgG = Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length);
    if (maxG - minG > 2) {
      primaryAxisAlignItems = 'SPACE_BETWEEN';
      itemSpacing = 0;
    } else {
      itemSpacing = avgG;
    }
  }

  // ── Padding ───────────────────────────────────────────────────────────────
  const paddingLeft   = Math.max(0, Math.round(Math.min(...items.map(i => i.x))));
  const paddingTop    = Math.max(0, Math.round(Math.min(...items.map(i => i.y))));
  const paddingRight  = Math.max(0, Math.round(frame.width  - Math.max(...items.map(i => i.x + i.w))));
  const paddingBottom = Math.max(0, Math.round(frame.height - Math.max(...items.map(i => i.y + i.h))));

  // ── Counter-axis alignment ─────────────────────────────────────────────────
  let counterAxisAlignItems = 'MIN';
  if (direction === 'HORIZONTAL') {
    const centers  = items.map(i => i.y + i.h / 2);
    const bottoms  = items.map(i => i.y + i.h);
    const varCtr   = Math.max(...centers) - Math.min(...centers);
    const varTop   = Math.max(...ys) - Math.min(...ys);
    const varBot   = Math.max(...bottoms) - Math.min(...bottoms);
    if      (varCtr <= 2)                    counterAxisAlignItems = 'CENTER';
    else if (varBot <= 2 && varBot < varTop) counterAxisAlignItems = 'MAX';
  } else {
    const centers  = items.map(i => i.x + i.w / 2);
    const rights   = items.map(i => i.x + i.w);
    const varCtr   = Math.max(...centers) - Math.min(...centers);
    const varLeft  = Math.max(...xs) - Math.min(...xs);
    const varRight = Math.max(...rights) - Math.min(...rights);
    if      (varCtr <= 2)                      counterAxisAlignItems = 'CENTER';
    else if (varRight <= 2 && varRight < varLeft) counterAxisAlignItems = 'MAX';
  }

  // ── Apply ─────────────────────────────────────────────────────────────────
  try {
    const w = frame.width, h = frame.height;
    frame.layoutMode              = direction;
    frame.itemSpacing             = itemSpacing;
    frame.primaryAxisAlignItems   = primaryAxisAlignItems;
    frame.counterAxisAlignItems   = counterAxisAlignItems;
    frame.paddingLeft             = paddingLeft;
    frame.paddingTop              = paddingTop;
    frame.paddingRight            = paddingRight;
    frame.paddingBottom           = paddingBottom;
    frame.primaryAxisSizingMode   = 'FIXED';
    frame.counterAxisSizingMode   = 'FIXED';
    frame.resize(w, h);
  } catch (e) {
    console.warn('AutoLayout failed on', frame.name, e.message);
    try { frame.layoutMode = 'NONE'; } catch (_) {}
  }
}

// ─── Main entry point ─────────────────────────────────────────────────────────
(function main() {
  const selection = figma.currentPage.selection;

  if (selection.length === 0) {
    figma.notify('⚠️ Select a frame first, then run the plugin.', { error: true });
    figma.closePlugin();
    return;
  }

  if (selection.length === 1) {
    const node = selection[0];
    if (!('layoutMode' in node)) {
      figma.notify('⚠️ Selected element cannot have auto layout.', { error: true });
      figma.closePlugin();
      return;
    }
    if (isIcon(node)) {
      figma.notify('⚠️ Icon detected — skipping.', { error: true });
      figma.closePlugin();
      return;
    }
    applyAutoLayoutNative(node);
    figma.notify('✅ Auto layout applied!');
    figma.closePlugin();
    return;
  }

  // Multiple frames selected — wrap in a new auto-layout container
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const node of selection) {
    const b = node.absoluteBoundingBox;
    if (b) {
      minX = Math.min(minX, b.x);     minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.width); maxY = Math.max(maxY, b.y + b.height);
    }
  }

  if (minX === Infinity) {
    figma.notify('⚠️ Could not read bounds.', { error: true });
    figma.closePlugin();
    return;
  }

  const parent = selection[0].parent || figma.currentPage;
  const parentAbsBox = (parent !== figma.currentPage && 'absoluteBoundingBox' in parent)
    ? parent.absoluteBoundingBox : { x: 0, y: 0 };

  const frame = figma.createFrame();
  frame.resize(maxX - minX, maxY - minY);
  frame.name = 'Auto Layout Frame';
  frame.fills = [];
  frame.clipsContent = false;
  parent.appendChild(frame);
  frame.x = minX - parentAbsBox.x;
  frame.y = minY - parentAbsBox.y;

  for (const node of selection) {
    frame.appendChild(node);
  }

  applyAutoLayoutNative(frame);
  figma.currentPage.selection = [frame];
  figma.notify('✅ Auto layout applied!');
  figma.closePlugin();
})();
