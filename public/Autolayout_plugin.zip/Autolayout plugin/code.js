const ICON_THRESHOLD = 32;

function isIcon(node) {
  if (node.type === 'VECTOR' || node.type === 'BOOLEAN_OPERATION') return true;
  if (node.width <= ICON_THRESHOLD && node.height <= ICON_THRESHOLD) return true;
  if ('children' in node && node.children.length > 0) {
    const allVector = node.children.every(c =>
      ['VECTOR','BOOLEAN_OPERATION','ELLIPSE','RECTANGLE','LINE','STAR','POLYGON'].includes(c.type)
    );
    if (allVector) return true;
  }
  return false;
}

function applyAutoLayout(node, depth = 0) {
  if (depth > 30) return;
  if (!('children' in node)) return;
  if (node.type === 'GROUP') return;
  if (isIcon(node)) return;

  // Recurse children first (bottom up)
  for (const child of node.children) {
    applyAutoLayout(child, depth + 1);
  }

  const children = [...node.children];
  if (children.length < 2) return;

  // Skip if any child is absolutely positioned way outside
  const validChildren = children.filter(c => 
    c.x >= -10 && c.y >= -10 &&
    c.x < node.width + 10 &&
    c.y < node.height + 10
  );
  if (validChildren.length < 2) return;

  // 1. OVERLAP DETECTION
  for (let i = 0; i < validChildren.length; i++) {
    for (let j = i + 1; j < validChildren.length; j++) {
      const a = validChildren[i];
      const b = validChildren[j];
      const overlapX = Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x));
      const overlapY = Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
      const overlapArea = overlapX * overlapY;
      if (overlapArea > 0) {
        const smallerArea = Math.min(a.width * a.height, b.width * b.height);
        if (smallerArea > 0 && overlapArea / smallerArea > 0.20) return;
      }
    }
  }

  // 2. GRID DETECTION
  const uniqueY = [];
  const uniqueX = [];
  for (const c of validChildren) {
    if (!uniqueY.some(y => Math.abs(y - c.y) < 5)) uniqueY.push(c.y);
    if (!uniqueX.some(x => Math.abs(x - c.x) < 5)) uniqueX.push(c.x);
  }
  if (uniqueY.length >= 2 && uniqueX.length >= 2) return;

  // Detect direction
  const yValues = validChildren.map(c => c.y);
  const xValues = validChildren.map(c => c.x);
  const ySpread = Math.max(...yValues) - Math.min(...yValues);
  const xSpread = Math.max(...xValues) - Math.min(...xValues);
  const direction = xSpread > ySpread ? 'HORIZONTAL' : 'VERTICAL';

  // 3. ALIGNMENT DETECTION
  let counterAxisAlignItems = 'MIN';
  if (direction === 'HORIZONTAL') {
    const centers = validChildren.map(c => c.y + c.height / 2);
    const ends = validChildren.map(c => c.y + c.height);
    const varCenters = Math.max(...centers) - Math.min(...centers);
    const varEnds = Math.max(...ends) - Math.min(...ends);
    const varMins = Math.max(...yValues) - Math.min(...yValues);
    if (varCenters < 5 && varCenters < varMins) counterAxisAlignItems = 'CENTER';
    else if (varEnds < 5 && varEnds < varMins) counterAxisAlignItems = 'MAX';
  } else {
    const centers = validChildren.map(c => c.x + c.width / 2);
    const ends = validChildren.map(c => c.x + c.width);
    const varCenters = Math.max(...centers) - Math.min(...centers);
    const varEnds = Math.max(...ends) - Math.min(...ends);
    const varMins = Math.max(...xValues) - Math.min(...xValues);
    if (varCenters < 5 && varCenters < varMins) counterAxisAlignItems = 'CENTER';
    else if (varEnds < 5 && varEnds < varMins) counterAxisAlignItems = 'MAX';
  }

  // Sort children by position
  const sorted = [...validChildren].sort((a, b) =>
    direction === 'HORIZONTAL' ? a.x - b.x : a.y - b.y
  );

  // 4. CALCULATE GAPS & UNEVEN GAP HANDLING
  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    const curr = sorted[i];
    const gap = direction === 'HORIZONTAL'
      ? curr.x - (prev.x + prev.width)
      : curr.y - (prev.y + prev.height);
    if (gap >= 0 && gap < 200) gaps.push(gap);
  }
  
  let primaryAxisAlignItems = 'MIN';
  let itemSpacing = 0;
  
  if (gaps.length > 0) {
    const maxGap = Math.max(...gaps);
    const minGap = Math.min(...gaps);
    if (maxGap - minGap > 10) {
      primaryAxisAlignItems = 'SPACE_BETWEEN';
    } else {
      itemSpacing = Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length);
    }
  }

  // Calculate padding
  const paddingLeft = Math.max(0, Math.round(Math.min(...xValues)));
  const paddingTop = Math.max(0, Math.round(Math.min(...yValues)));
  const paddingRight = Math.max(0, Math.round(
    node.width - Math.max(...validChildren.map(c => c.x + c.width))
  ));
  const paddingBottom = Math.max(0, Math.round(
    node.height - Math.max(...validChildren.map(c => c.y + c.height))
  ));

  try {
    // Save dimensions BEFORE applying auto layout
    const w = node.width;
    const h = node.height;

    node.layoutMode = direction;
    node.itemSpacing = itemSpacing;
    node.primaryAxisAlignItems = primaryAxisAlignItems;
    node.counterAxisAlignItems = counterAxisAlignItems;
    node.paddingLeft = paddingLeft;
    node.paddingTop = paddingTop;
    node.paddingRight = paddingRight;
    node.paddingBottom = paddingBottom;

    // Keep FIXED sizing to preserve original dimensions
    node.primaryAxisSizingMode = 'FIXED';
    node.counterAxisSizingMode = 'FIXED';

    // Restore dimensions after auto layout changes them
    node.resize(w, h);

  } catch (e) {
    console.warn('Skipped:', node.name, e.message);
    try { node.layoutMode = 'NONE'; } catch (err) {}
  }
}

const selection = figma.currentPage.selection;
if (selection.length === 0) {
  figma.notify('⚠️ Select a frame first', { error: true });
  figma.closePlugin();
} else {
  for (const node of selection) {
    applyAutoLayout(node);
  }
  figma.notify('✅ Auto layout applied!');
  figma.closePlugin();
}
