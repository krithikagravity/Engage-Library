# ApplyAutoLayout — Figma Plugin

A Figma plugin that automatically applies auto layout to frames pasted from the **Copy to Figma** Chrome extension.

---

## How to Run

1. Open Figma and go to the file where you pasted your captured frames
2. Go to **Menu → Plugins → Development → Import plugin from manifest**
3. Select the `manifest.json` file from this folder
4. Select one or more frames on your canvas
5. Run the plugin via **Menu → Plugins → ApplyAutoLayout**
6. Auto layout will be applied to the selected frames and all nested children

---

## Requirements

- Figma desktop app or browser (figma.com)
- At least one frame selected before running the plugin

---

## Notes

- Works best on simple layouts like navbars, card lists, and sidebars
- Complex or overlapping layouts (modals, badges, grids) may not apply perfectly
- Does not modify your layout visually — it preserves original dimensions
